"""Package a complete, terminal study; never publish a selected conformer subset."""
from pathlib import Path
import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
import zipfile

HERE=Path(__file__).resolve().parent
METAG=HERE.parents[1]
read=lambda path:json.loads(Path(path).read_text())
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    status=read(HERE/'current_status.json')
    assert status['complete_pool_ready'] and status['verified_pairs']==103 and not status['invalid_pairs']
    assert not status['claims']
    for host, evidence in status['current_host_evidence'].items():
        assert not evidence.get('observation_failed'),host
        assert not any(row['owned_live'] for row in evidence['processes']),host
    subprocess.run([sys.executable,str(HERE/'analyze.py')],check=True,capture_output=True,text=True)
    result=read(HERE/'ensemble_results.json')
    destination=METAG/'benchmark/nicotinamide_ensemble_validation'
    assert not destination.exists(),'Preserve an existing published packet; inspect before replacing it.'
    destination.mkdir()
    files=set(read(HERE/'study_manifest.json')['files_sha256'])
    files.update(['study_manifest.json','analysis_freeze.json','analyze.py','uma_replay.json',
        'launch_manifest_original.json','launch_manifest_four_workers.json','launch_manifest.json',
        'runtime_start.json','execution_amendment.json','parallel_execution_amendment.json',
        'budget_guard.py','budget_stop_fallback.py','budget_supervisor_audit.json',
        'budget_guard_owner.json','budget_stop_fallback_owner.json','budget_guard_status.json',
        'README.md','current_status.json','publish.py'])
    for directory in ['points','attempts','workers','bridges','budget_fallback_initial']:
        files.update(str(path.relative_to(HERE)) for path in (HERE/directory).rglob('*')
                     if path.is_file() and '__pycache__' not in path.parts)
    with zipfile.ZipFile(destination/'calculation_records.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for name in sorted(files):archive.write(HERE/name,name)
    shutil.copy2(HERE/'ensemble_results.json',destination/'ensemble_results.json')
    shutil.copy2(METAG/'benchmark/nicotinamide_ensemble.py',destination/'nicotinamide_ensemble.py')
    arms=result['arms'];macro={'neGeometryN':'103','neNewN':'94',
        'nePrimary':f"{result['primary_DFT_SMD_ensemble_contrast_kj']:.2f}",
        'neUMAALPB':f"{arms['full|UMA|ALPB']['exchange_kj']:.2f}",
        'neDFTALPB':f"{arms['full|DFT|ALPB']['exchange_kj']:.2f}",
        'neUMASMD':f"{arms['full|UMA|SMD']['exchange_kj']:.2f}",
        'neDFTSMD':f"{arms['full|DFT|SMD']['exchange_kj']:.2f}",
        'neDeltaUMAALPB':f"{result['full_minus_restricted_kj']['UMA|ALPB']:.2f}",
        'neDeltaDFTALPB':f"{result['full_minus_restricted_kj']['DFT|ALPB']:.2f}",
        'neDeltaUMASMD':f"{result['full_minus_restricted_kj']['UMA|SMD']:.2f}",
        'neElectronic':f"{result['factorial_contrasts']['full']['electronic_at_ALPB_kj']:.2f}",
        'neSolvent':f"{result['factorial_contrasts']['full']['solvent_at_UMA_kj']:.2f}"}
    (destination/'nicotinamide_ensemble_numbers.tex').write_text('% Complete retained fixed-geometry ensembles; no experimental accuracy claim.\n'+
        ''.join('\\newcommand{\\'+k+'}{'+v+'}\n' for k,v in macro.items()))
    (destination/'README.md').write_text('''# Complete retained nicotinamide ensembles

All 103 originally retained geometries are included: 41/55 full oxidized/reduced
cofactor minima and 3/4 small-core minima. Nine exact earlier gas/SMD pairs are
reused; 94 new pairs extend the same numerical recipe. Every arm retains the
original gas geometry and RRHO correction. Full reference charges are +1/0 with
protonated phosphate groups. These are not biochemical protonation ensembles.

The exchange is full oxidized + core reduced -> full reduced + core oxidized.
It conserves atoms, charge and molecular count. All four electronic/solvent arms
are reported, including their complete conformer weights and components. No
failed or missing conformer is dropped. The frozen analysis predates the new
DFT outputs; the old nine-point results were already known. Its primary contrast
is the full minus restricted DFT/SMD exchange. The 5 kJ/mol descriptive threshold
measures intervention magnitude, not experimental accuracy or a promotion gate.

Replay the complete numerical evidence with standard-library Python:

```bash
python nicotinamide_ensemble.py .
```

The archive includes immutable scientific inputs, original source records, point
results/SCF logs, numerical fixtures, architecture bridges, producer/ownership
records, frozen analysis and resource-only amendments. Source paths and launcher
settings preserve provenance; they are not portable launch commands. The auditor
reads the archive without extracting or accessing those absolute paths. Independent
50-digit partitions use DFT/SMD water totals directly. This checks saved values,
not recomputation of SCF or an electronic ground-state/stability proof.

Recomputation requires the declared UMA producer and PySCF/GPU4PySCF environment.
The original two-worker plan was enlarged to seven H100 workers under a 30 GPU-hour
ceiling; scientific inputs, tolerances, one-attempt rule and analysis stayed fixed.
Missing-state, aqueous sampling, protonation, Mg binding, ionic-strength and model
errors remain unvalidated. No independent experimental label is added, no empirical
offset is fitted, and no production reference policy is adopted by this control.
''')
    manifest={'files':{str(path.relative_to(destination)):sha(path) for path in destination.iterdir() if path.is_file()},
        'scope':'Complete fixed-geometry component/ensemble sensitivity; no experimental accuracy or production adoption.'}
    (destination/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    spec=importlib.util.spec_from_file_location('portable_cofactor_audit',destination/'nicotinamide_ensemble.py')
    auditor=importlib.util.module_from_spec(spec);spec.loader.exec_module(auditor)
    report=auditor.audit(destination)
    (HERE/'portable_audit_receipt.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
