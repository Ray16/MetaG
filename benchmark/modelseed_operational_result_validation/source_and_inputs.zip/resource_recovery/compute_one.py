"""One isolated molecular attempt, or one owned compatibility check."""
from pathlib import Path
from dataclasses import asdict
import json
import math
import os
import sys
import time
import traceback

from common import HERE,read,write,owner,sha,check_freeze,XTB



def actual_implicit_record(directory,task,settings_key,producer):
    matches=[]
    for path in Path(directory).glob('*.json'):
        row=read(path)
        if row.get('smi')==task['smiles'] and row.get('q')==task['charge'] and row.get('method')=='implicit':
            matches.append((path,row))
    if len(matches)!=1:raise ValueError('Expected exactly one actual produced implicit record')
    path,row=matches[0]
    if row['settings'].get('spin',1)!=task['spin']:raise ValueError('Raw spin identity mismatch')
    if row['settings']['producer']!=producer:raise ValueError('Raw producer mismatch')
    if any(row['settings'].get(k)!=v for k,v in settings_key.items()):raise ValueError('Raw numerical settings mismatch')
    return path,row


def main():
    mode=sys.argv[1];worker=sys.argv[2]
    freeze=check_freeze();manifest=read(HERE/'launch_manifest.json')
    allocation=next(a for a in manifest['allocations'] if a['worker']==worker)
    assert owner()['cpus']==allocation['cpus'] and os.uname().nodename==allocation['host']
    assert os.environ.get('CUDA_VISIBLE_DEVICES')
    initialization_started=time.monotonic()
    import rdkit
    import torch
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    from metag.settings import Settings
    from metag.energetics.errors import SpeciesRearranged
    from metag.energetics.uma import load_uma,batched_energies
    from metag.energetics.backend import UMABackend
    from metag.energetics import species_cache
    settings=Settings(**read(HERE/'raw_settings.json'))
    assert asdict(settings)==read(HERE/'raw_settings.json')
    backend=UMABackend(load_uma(settings.model,profile='nitro'),settings,log=lambda x:print(x,flush=True))
    producer=backend.producer
    initialization_seconds=time.monotonic()-initialization_started
    assert producer['cacheable']
    expected=freeze['physical_model_identity']
    assert producer['model']['checkpoint_sha256']==expected['checkpoint_sha256']
    assert producer['model']['references_sha256']==expected['references_sha256']
    if mode=='startup':
        from ase import Atoms
        fixtures=read(HERE/'compatibility_fixtures.json')
        atoms=[Atoms(symbols=f['geometry']['symbols'],positions=f['geometry']['positions_angstrom'],
            info=dict(charge=f['geometry']['charge'],spin=f['geometry']['spin_multiplicity'])) for f in fixtures]
        energies=batched_energies(backend.pu,atoms)*96.485
        differences=[float(e)-f['electronic_kj'] for e,f in zip(energies,fixtures)]
        assert max(map(abs,differences))<=.001,differences
        write(HERE/'workers'/(worker+'.startup.json'),dict(status='passed',owner=owner(),
            producer=producer,runtime=backend.pu.metag_runtime_profile,
            point_energy_differences_kj=differences,maximum_point_tolerance_kj=.001,
            execution=backend.pu.execution_snapshot()))
        return
    startup=read(HERE/'workers'/(worker+'.startup.json'))
    assert producer==startup['producer'],'Producer changed after worker compatibility check'
    task=next(t for t in read(HERE/'tasks.json') if t['slot']==mode)
    result=dict(slot=mode,request=task,worker=worker,owner=owner(),producer=producer,
        protocol_sha256=sha(HERE/'protocol.json'),freeze_sha256=sha(HERE/'freeze.json'),model_initialization_seconds=initialization_seconds)
    started=time.monotonic()
    try:
        print('MOLECULE START',mode,task['charge'],task['spin'],task['smiles'],flush=True)
        warnings=[];diagnostics={}
        if task['kind']=='liquid_water':
            import numpy as np
            from ase import Atoms
            from metag.constants import R_KJ,LIQUID_WATER_CONC,WATER_DGSOLV_KJ
            from metag.energetics.thermal import water_geometry,uma_gibbs_corr
            from metag.symmetry import geometry_and_sigma
            symbols,coords=water_geometry(backend.pu)
            atoms=Atoms(symbols=list(symbols),positions=coords,info=dict(charge=0,spin=1))
            electronic=float(batched_energies(backend.pu,[atoms])[0])*96.485
            correction,info=uma_gibbs_corr(backend.pu,list(symbols),coords,0,hessian=settings.hessian,return_info=True)
            assert info['n_imag']==0
            geometry=dict(symbols=list(symbols),positions_angstrom=np.asarray(coords).tolist(),charge=0,spin_multiplicity=1)
            geometry['sha256']=__import__('hashlib').sha256(json.dumps(geometry,sort_keys=True,allow_nan=False).encode()).hexdigest()
            kind,symmetry=geometry_and_sigma(list(symbols),coords)
            concentration=float(R_KJ*298.15*np.log(LIQUID_WATER_CONC))
            value=float(electronic+WATER_DGSOLV_KJ+correction+concentration);sigma=0.
            record=dict(kind='liquid_water_reference',G=value,sigma=0.,producer=producer,settings=asdict(settings),geometry=geometry,
                electronic_kj=electronic,experimental_water_hydration_kj=WATER_DGSOLV_KJ,thermal_kj=correction,
                concentration_kj=concentration,thermodynamics=info['thermodynamics'],n_imag=info['n_imag'],geometry_kind=kind,symmetrynumber=symmetry)
            path=Path(os.environ['METAG_CACHE'])/'water_reference.json';write(path,record)
            result.update(status='molecular_record_complete',record_type='liquid_water_reference',energy_kj=value,
                sampling_sigma_kj=0.,cache_path=str(path),cache_sha256=sha(path),diagnostics=dict(method='liquid_water_reference'))
            return
        value,sigma=backend.species(task['charge'],task['smiles'],mode,warnings,diagnostics)
        result.update(energy_kj=value,sampling_sigma_kj=sigma,warnings=warnings,diagnostics=diagnostics)
        if value is None:
            result['status']='workflow_no_estimate'
        else:
            assert math.isfinite(value) and math.isfinite(sigma) and sigma>=0
            path,raw=actual_implicit_record(os.environ['METAG_CACHE'],task,settings.species_key(),producer)
            assert raw['G']==value and raw['sigma']==sigma
            assert raw['q']==task['charge'] and raw['smi']==task['smiles']
            assert raw['settings']['producer']==producer
            ensemble=raw['meta']['thermal']['ensemble']
            minima=ensemble['validated_minima']
            assert minima and ensemble['n_reference_thermal_approximation']==0
            assert all(m['geometry']['charge']==task['charge'] and
                m['geometry']['spin_multiplicity']==task['spin'] for m in minima)
            totals=[m['electronic_kj']+m['solvation_kj']+m['thermal_kj'] for m in minima]
            low=min(totals);rebuilt=low-2.4789*math.log(math.fsum(math.exp(-(v-low)/2.4789) for v in totals))
            assert abs(rebuilt-value)<1e-7
            result.update(status='molecular_record_complete',cache_path=str(path),cache_sha256=sha(path),
                n_validated_minima=len(minima),partition_reconstruction_error_kj=rebuilt-value)
    except SpeciesRearranged as error:
        result.update(status='workflow_no_estimate',energy_kj=None,sampling_sigma_kj=None,error=repr(error),reason='all sampled conformers failed molecular identity')
    except BaseException as error:
        result.update(status='execution_failure',error=repr(error),traceback=traceback.format_exc())
    finally:
        result.update(elapsed_seconds=time.monotonic()-started,execution=backend.pu.execution_snapshot())
        write(HERE/'results'/(mode+'.json'),result)
    print('MOLECULE TERMINAL',mode,result['status'],flush=True)
    if result['status']=='execution_failure':raise SystemExit(1)


if __name__=='__main__':main()
