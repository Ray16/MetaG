"""Provisional graph hypotheses for source triage; no predictions or label enrollment."""
from pathlib import Path
from collections import defaultdict
import csv,hashlib,json,sys
H=Path(__file__).resolve().parent;P=H.parents[1]
sys.path[:0]=[str(P/'src'),str(P)]
from rdkit import Chem,DataStructs,rdBase
from rdkit.Chem import rdFingerprintGenerator
from benchmark.benchmark_feasibility import family,equation,concrete,development_panel,reaction_key
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
queries={
 'hydantoin':'O=C1NCC(=O)N1',
 'ureidoacetic_acid':'NC(=O)NCC(=O)O',
 '5_phenylhydantoin_unresolved_stereo':'O=C1NC(=O)C(c2ccccc2)N1',
 'N_carbamoyl_phenylglycine_unresolved_stereo':'NC(=O)NC(c1ccccc1)C(=O)O',
 '5_6_dihydrouracil':'O=C1CCNC(=O)N1',
 '3_ureidopropanoic_acid':'NC(=O)NCCC(=O)O',
 'benzonitrile':'N#Cc1ccccc1',
 'benzyl_cyanide':'N#CCc1ccccc1',
 '3_phenylpropionitrile':'N#CCCc1ccccc1',
 '4_phenylbutyronitrile':'N#CCCCc1ccccc1',
 'alpha_methylbenzyl_cyanide_unresolved_stereo':'CC(C#N)c1ccccc1',
 'indole_3_acetonitrile':'N#CCc1c[nH]c2ccccc12'}
generator=rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048,includeChirality=True)
corpora={};input_paths=[]
for tag,name in [('public671','training671_structural.csv'),('author675','training675_structural.csv')]:
 p=P/'benchmark/feasibility_validation'/name;input_paths.append(p)
 with p.open(newline='') as f:rows=list(csv.DictReader(f))
 corpus={tier:defaultdict(list) for tier in ['exact','pool','broad']};unresolved=[];substructures=[]
 for i,row in enumerate(rows):
  try:parts=equation(row['reaction'])
  except ValueError as error:unresolved.append(dict(row=i,error=str(error)));continue
  for _,smi in parts:
   witness=dict(row=i,description=row['description'],target_type=row['type'],supplied_smiles=smi)
   try:
    info=family(smi)
    for tier in corpus:
     if not info['reservoir'] and info[tier] is not None:corpus[tier][info[tier]].append(witness)
    if info['issues']:unresolved.append(dict(witness,issues=info['issues']))
    mol=concrete(smi)
    for query,pattern in [('hydantoin_ring','O=C1NCC(=O)N1'),('nitrile_motif','[C]#[N]')]:
     if mol.HasSubstructMatch(Chem.MolFromSmarts(pattern)):substructures.append(dict(witness,motif=query))
   except (ValueError,RuntimeError) as error:unresolved.append(dict(witness,error=str(error)))
 keys=sorted(corpus['pool']);fps=[generator.GetFingerprint(concrete(s)) for s in keys];records=[]
 for name,smi in queries.items():
  info=family(smi);neighbors=[]
  if info['pool'] is not None:
   similarities=DataStructs.BulkTanimotoSimilarity(generator.GetFingerprint(concrete(info['pool'])),fps)
   for k in sorted(range(len(keys)),key=lambda k:(-similarities[k],keys[k]))[:3]:
    neighbors.append(dict(pool=keys[k],similarity=similarities[k],witnesses=corpus['pool'][keys[k]]))
  records.append(dict(name=name,supplied_graph_hypothesis=smi,family=info,
   exact_matches=corpus['exact'].get(info['exact'],[]),pool_matches=corpus['pool'].get(info['pool'],[]),
   broad_matches=corpus['broad'].get(info['broad'],[]),nearest_resolved_original_pool=neighbors,
   absence_certified=False,chemical_identity_source_verified=False))
 corpora[tag]=dict(input_sha256=sha(p),queries=records,unresolved_terms=unresolved,motif_witnesses=substructures,
  scope='All reaction AND formation targets; no target/family exclusions, fitting or prediction. Concrete known pools retained even when another term is unresolved. Unknown structures preclude certified absence.')
p=P/'benchmark/feasibility_validation/historical_inputs.json';input_paths.append(p)
reaction_keys,molecules,unknown=development_panel(p)
historical=[]
for name,smi in queries.items():
 info=family(smi);historical.append(dict(name=name,matches_bounded_historical_inventory={tier:info[tier] in molecules[tier] for tier in molecules},absence_certified=False))
report=dict(schema='metag-source-lead-structural-triage-v1',rdkit_version=rdBase.rdkitVersion,
 inputs={str(p.relative_to(P)):sha(p) for p in input_paths},source_sha256=sha(Path(__file__)),
 family_source_sha256=sha(P/'benchmark/benchmark_feasibility.py'),
 fingerprint=dict(kind='Morgan',radius=2,bits=2048,chirality=True),training=corpora,
 historical=dict(queries=historical,unresolved_terms=unknown,scope='Bounded 383 reaction-shaped inputs only; not a complete molecular-cache or historical-development exposure audit.'),
 candidates_are_provisional_graph_hypotheses=True,predictions_performed=False,experimental_references_admitted=0,
 scope='Conservative source triage only. These graphs are not experimentally authenticated species/state assignments. Missing stereochemistry is retained unresolved. This does not establish primary eligibility, measured-state identity, novelty, source independence or UMA pretraining novelty.')
(H/'structural_screen.json').write_text(json.dumps(report,indent=2)+'\n')
for tag,data in corpora.items():
 print(tag,'unresolved',len(data['unresolved_terms']))
 for r in data['queries']:
  print(r['name'],'broad_rows',sorted({w['row'] for w in r['broad_matches']}),'nearest',[(x['similarity'],x['pool']) for x in r['nearest_resolved_original_pool'][:1]])
 print('motifs',[(x['motif'],x['row'],x['description']) for x in data['motif_witnesses']])
