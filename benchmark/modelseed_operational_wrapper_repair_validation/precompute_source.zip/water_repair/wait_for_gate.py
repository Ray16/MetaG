"""One bounded water-repair reservation, waiting only on actual free H100 capacity."""
from pathlib import Path
import datetime,json,os,shutil,subprocess,time,uuid
from common import HERE,GATE,environment,read,write,owner,sha,check_freeze
PARENT=HERE.parent/'resource_recovery'

def same(row):
 try:
  fields=Path('/proc',str(row['pid']),'stat').read_text().rsplit(')',1)[1].split()
  return fields[19]==row['start_ticks'] and fields[0]!='Z'
 except FileNotFoundError:return False

def capacity():
 assert sorted(os.sched_getaffinity(0))==[374,375]
 assert max(os.getloadavg())+2<=os.cpu_count()
 for path in Path('/proc').glob('[0-9]*'):
  try:
   pid=int(path.name)
   if pid==os.getpid():continue
   fields=(path/'cmdline').read_bytes().split(b'\0')
   if not fields or b'python' not in Path(fields[0].decode()).name.encode():continue
   cpus=os.sched_getaffinity(pid)
   if len(cpus)<os.cpu_count():assert not cpus&{374,375},('CPU overlap',pid,cpus)
  except (FileNotFoundError,ProcessLookupError):continue
 assert not same(read(PARENT/'workers/worker1.owner.json'))
 assert not same(read(PARENT/'workers/worker1.predictor.json'))
 assert not same(read(PARENT/'workers/worker1.launcher.json'))

assert os.uname().nodename=='lambda13'
assert not (HERE/'wait_request.json').exists() and not (HERE/'launch_manifest.json').exists()
freeze=check_freeze();preflight=read(HERE/'node_preflight.json');assert preflight['status']=='passed'
protocol=read(HERE/'protocol.json');assert protocol['maximum_workers']==1
run=uuid.uuid4().hex;deadline=datetime.datetime.fromisoformat(protocol['common_deadline_utc']).timestamp()
write(HERE/'wait_request.json',dict(run_id=run,owner=owner(),protocol_sha256=sha(HERE/'protocol.json'),deadline_utc=protocol['common_deadline_utc']))
capacity()
while time.time()<deadline-80:
 try:
  text=subprocess.check_output([GATE,'list','--hosts','lambda13'],text=True,timeout=15)
  candidates=[int(l.split()[1]) for l in text.splitlines() if l.split()[0]=='lambda13']
 except (subprocess.TimeoutExpired,subprocess.CalledProcessError) as error:
  write(HERE/'waiting_status.json',dict(state='capacity_observation_unavailable',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),owner=owner(),error=repr(error)))
  time.sleep(5);continue
 if not candidates:
  write(HERE/'waiting_status.json',dict(state='waiting_for_free_H100',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),owner=owner()))
  time.sleep(10);continue
 capacity()
 gpus={int(x.split(',')[0]):x.split(',') for x in subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,memory.total','--format=csv,noheader'],text=True,timeout=15).splitlines()}
 candidates=[i for i in candidates if 'H100' in gpus[i][2] and int(gpus[i][3].strip().split()[0])>=80000]
 if not candidates:time.sleep(10);continue
 gpu=min(candidates);allocation=dict(worker='water',host='lambda13',gpu_index=gpu,gpu_uuid=gpus[gpu][1].strip(),cpus=[374,375])
 for name in ['claims','cache','results','logs','partial','workers']:(HERE/name).mkdir(exist_ok=False)
 manifest=dict(run_id=run,utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),deadline_utc=protocol['common_deadline_utc'],allocations=[allocation],expected_inputs=1,
 maximum_GPU_hours=8,shared_with_parent_and_initial_phases=True,maximum_concurrent_operational_workers=2,freeze_sha256=sha(HERE/'freeze.json'),launch_owner=owner())
 write(HERE/'launch_manifest.json',manifest)
 argv=[GATE,'run',str(gpu),'--label','metag_operational_water_wrapper_repair','--','/usr/bin/taskset','-c','374,375','/usr/bin/python3',str(HERE/'worker.py'),'water']
 with (HERE/'logs/water.launcher.log').open('x') as log:
  child=subprocess.Popen(argv,env=environment(),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 try:start=Path('/proc',str(child.pid),'stat').read_text().rsplit(')',1)[1].split()[19]
 except FileNotFoundError:start=None
 write(HERE/'workers/water.launcher.json',dict(host='lambda13',pid=child.pid,start_ticks=start,argv=argv,allocation=allocation))
 write(HERE/'waiting_status.json',dict(state='one_atomic_gate_launch_issued',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),owner=owner(),launcher_pid=child.pid,allocation=allocation))
 print('WATER_REPAIR_LAUNCH',gpu,child.pid,flush=True)
 break
else:
 write(HERE/'waiting_status.json',dict(state='common_deadline_no_capacity_no_attempt',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),owner=owner()))
