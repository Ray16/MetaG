"""Matched xTB total-energy solvent increment and its conservative gradient."""
from pathlib import Path
import json
import math
import os
import re
import subprocess
import tempfile
import time
import numpy as np

NUMBER=r'[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[EeDd][+-]?\d+)?'

def evaluate(symbols,positions,charge,protocol,raw_stream=None):
    positions=np.asarray(positions,dtype=float)
    assert positions.shape==(len(symbols),3) and np.isfinite(positions).all()
    energy={};gradients={};start=time.monotonic()
    env=dict(os.environ,OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',OMP_STACKSIZE='1G')
    for phase in ['gas','aqueous']:
        with tempfile.TemporaryDirectory(prefix='metag-aq-gradient-') as directory:
            d=Path(directory);xyz=str(len(symbols))+'\nconservative solvent increment\n'+''.join(symbol+' '+' '.join(format(float(x),'.17g') for x in row)+'\n' for symbol,row in zip(symbols,positions))
            (d/'input.xyz').write_text(xyz)
            argv=[protocol['xtb'],str(d/'input.xyz'),'--gfn','2','--chrg',str(int(charge)),'--uhf','0','--acc',str(protocol['xtb_accuracy']),'--norestart','--grad']
            if phase=='aqueous':
                (d/'solvent.in').write_text('$gbsa\n grid='+protocol['solvent_grid']+'\n$end\n')
                argv+=['--alpb','water','gsolv','--input',str(d/'solvent.in')]
            process=subprocess.Popen(argv,cwd=d,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            inherited_affinity=sorted(os.sched_getaffinity(process.pid))
            assert inherited_affinity==sorted(os.sched_getaffinity(0)), 'Native child affinity mismatch'
            try:stdout,stderr=process.communicate(timeout=120)
            finally:
                if process.poll() is None:process.kill();process.wait()
            record=dict(cpu_affinity=inherited_affinity,phase=phase,input_xyz=xyz,charge=int(charge),argv=argv,pid=process.pid,returncode=process.returncode,stdout=stdout,stderr=stderr)
            if (d/'gradient').exists():record['gradient_file']=(d/'gradient').read_text()
            if raw_stream is not None:raw_stream.write(json.dumps(record)+'\n');raw_stream.flush()
            if process.returncode:raise RuntimeError(f'xTB{phase}failed:{stderr[-400:]}')
            match=re.search(r'TOTAL ENERGY\s+('+NUMBER+r')\s+Eh',stdout)
            if not match or 'convergence criteria satisfied' not in stdout:
                raise RuntimeError('Missing converged xTB total energy')
            energy[phase]=float(match[1].replace('D','E'))
            lines=record['gradient_file'].splitlines()
            header=next(i for i,line in enumerate(lines) if 'cycle' in line.lower())
            match=re.search(r'SCF energy\s*=\s*('+NUMBER+')',lines[header])
            assert match and abs(float(match[1].replace('D','E'))-energy[phase])<=1e-8
            rows=[line.split() for line in lines[header+1:header+1+len(symbols)]]
            assert [r[3].capitalize() for r in rows]==symbols
            coordinate=np.array([[float(v.replace('D','E')) for v in r[:3]] for r in rows])*protocol['units']['Bohr_to_A']
            assert np.max(np.abs(coordinate-positions))<1e-8
            gradient=np.array([[float(v.replace('D','E')) for v in line.split()] for line in lines[header+1+len(symbols):header+1+2*len(symbols)]])
            assert gradient.shape==positions.shape and np.isfinite(gradient).all()
            gradients[phase]=gradient
    conversion=protocol['units']['Hartree_to_kj']/protocol['units']['eV_to_kj']
    delta=(energy['aqueous']-energy['gas'])*conversion
    force=-(gradients['aqueous']-gradients['gas'])*conversion/protocol['units']['Bohr_to_A']
    assert math.isfinite(delta) and np.isfinite(force).all()
    return dict(energy_eV=delta,forces_eV_A=force,gas_Eh=energy['gas'],aqueous_Eh=energy['aqueous'],elapsed_seconds=time.monotonic()-start)
