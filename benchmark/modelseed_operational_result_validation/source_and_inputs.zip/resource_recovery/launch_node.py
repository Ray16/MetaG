"""Final live-capacity checks and exactly two atomic, gate-owned worker launches."""
from pathlib import Path
import datetime
import json
import os
import shutil
import subprocess
import time
import uuid

from common import HERE,GATE,environment,write,read,owner,sha,check_freeze

assert os.uname().nodename=='lambda13'
assert not (HERE/'launch_manifest.json').exists(),'Inspect existing ownership; do not resubmit blindly'
freeze=check_freeze();p=read(HERE/'protocol.json');env=environment()
assert p['launch_allowed'] is True and p['study_kind']=='label-free-operational-probability-sample'
assert len(read(HERE/'tasks.json'))==115
allocations=[dict(worker='worker0',host='lambda13',gpu_index=6,cpus=[372,373]),
             dict(worker='worker1',host='lambda13',gpu_index=7,cpus=[374,375])]
all_cpus={c for a in allocations for c in a['cpus']}
assert len(all_cpus)==4 and all_cpus<=set(os.sched_getaffinity(0))
online=set()
for item in Path('/sys/devices/system/cpu/online').read_text().strip().split(','):
    fields=list(map(int,item.split('-')));online.update(range(fields[0],fields[-1]+1))
assert all_cpus<=online
assert max(os.getloadavg())+4<=len(online)
for path in Path('/proc').glob('[0-9]*'):
    try:
        if path.stat().st_uid!=os.getuid() or int(path.name)==os.getpid():continue
        cmd=(path/'cmdline').read_bytes().split(b'\0')
        if not cmd or b'python' not in Path(cmd[0].decode()).name.encode():continue
        cpus=set(os.sched_getaffinity(int(path.name)))
        if len(cpus)<os.cpu_count():assert not cpus&all_cpus,('External CPU contention',path.name,cpus)
    except (OSError,ProcessLookupError):continue
assert shutil.disk_usage('/tmp').free>10*1024**3
mem={line.split(':',1)[0]:int(line.split(':',1)[1].split()[0]) for line in Path('/proc/meminfo').read_text().splitlines()}
assert mem['MemAvailable']/1024>2*65536
gpus={int(x.split(',')[0]):x.split(',') for x in subprocess.check_output([
    'nvidia-smi','--query-gpu=index,uuid,name,memory.total','--format=csv,noheader'],text=True).splitlines()}
resident=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True)
for allocation in allocations:
    fields=gpus[allocation['gpu_index']];allocation['gpu_uuid']=fields[1].strip()
    assert allocation['gpu_uuid'] not in resident
    assert int(fields[3].strip().split()[0])>=80000 and 'H100' in fields[2]
for name in ['claims','cache','results','logs','partial','workers']:(HERE/name).mkdir(exist_ok=False)
now=datetime.datetime.now(datetime.timezone.utc)
original=read(HERE.parent/'launch_manifest.json')
assert now.timestamp()<datetime.datetime.fromisoformat(original['deadline_utc']).timestamp()-300
proof=read(HERE.parent/'post_stop_ownership_audit.json')
assert not proof['remaining_marked_predictors'] and not any(r['same_live_process'] for r in proof['ownership_checks'])
manifest=dict(run_id=uuid.uuid4().hex,utc=now.isoformat(),
    deadline_utc=original['deadline_utc'],
    allocations=allocations,expected_inputs=115,maximum_GPU_hours=8,freeze_sha256=sha(HERE/'freeze.json'),
    node_preflight_sha256=sha(HERE/'node_dependency_preflight.json'),native_threads=1,xtb_workers=1,
    launch_owner=owner(),initial_available_RAM_MiB=mem['MemAvailable']/1024)
write(HERE/'launch_manifest.json',manifest)
for i,allocation in enumerate(allocations):
    if i:time.sleep(15)
    cpu_text=','.join(map(str,allocation['cpus']))
    argv=[GATE,'run',str(allocation['gpu_index']),'--label','metag_modelseed_operational_recovery',
        '--','/usr/bin/taskset','-c',cpu_text,'/usr/bin/python3',str(HERE/'worker.py'),allocation['worker']]
    with (HERE/'logs'/(allocation['worker']+'.launcher.log')).open('x') as log:
        process=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=log,
            stderr=subprocess.STDOUT,start_new_session=True)
    try:start=Path(f'/proc/{process.pid}/stat').read_text().rsplit(')',1)[1].split()[19]
    except OSError:start=None
    write(HERE/'workers'/(allocation['worker']+'.launcher.json'),dict(pid=process.pid,
        host=os.uname().nodename,start_ticks=start,argv=argv,allocation=allocation))
    print('LAUNCHED',allocation['worker'],process.pid,allocation['gpu_uuid'],flush=True)
