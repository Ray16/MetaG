"""Two missing molecular parents, with the original physical producer and settings."""
from pathlib import Path
from dataclasses import asdict
import hashlib
import json
import math
import os
import shutil
import signal
import time
import traceback

HERE=Path(__file__).resolve().parent
OUT=HERE/'recovery_calculation'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,value):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(path)
def owner():
    return dict(host=os.uname().nodename,pid=os.getpid(),
        start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],
        affinity=sorted(os.sched_getaffinity(0)))
def stop(signum,frame):raise KeyboardInterrupt(f'worker signal {signum}')
for sig in [signal.SIGTERM,signal.SIGINT,signal.SIGALRM]:signal.signal(sig,stop)

def main():
    m=read(OUT/'launch_manifest.json');protocol=read(OUT/'protocol.json')
    for name,digest in m['files_sha256'].items():assert sha(HERE/name)==digest,name
    for name,digest in protocol['source_files_sha256'].items():
        assert sha(HERE/'recovery_source'/name)==digest,name
    assert sorted(os.sched_getaffinity(0))==m['cpus']
    assert os.environ.get('CUDA_VISIBLE_DEVICES') is not None
    write(OUT/'predictor_owner.json',owner())
    import rdkit  # match imported-module producer initialization of original ledger
    import torch
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    from metag.energetics.uma import load_uma
    from metag.energetics.backend import UMABackend
    from metag.energetics import species_cache as cache
    from metag.settings import Settings
    settings=Settings(**read(HERE/'raw_settings.json'))
    backend=UMABackend(load_uma(settings.model,profile='nitro'),settings,log=lambda s:print(s,flush=True))
    expected=read(HERE/'catalog.json')['producer']
    write(OUT/'producer_check.json',dict(expected=expected,actual=backend.producer,
        runtime=backend.pu.metag_runtime_profile,matched_except_source=all(expected.get(k)==v for k,v in backend.producer.items() if k!='source_sha256')))
    differences={k for k in set(backend.producer)|set(expected) if backend.producer.get(k)!=expected.get(k)}
    assert differences=={'source_sha256'},('Unexpected producer differences',differences)
    assert asdict(settings)==read(HERE/'raw_settings.json')
    status=dict(state='running',expected=len(protocol['tasks']),completed=[],failures=[])
    write(OUT/'status.json',status)
    for index,task in enumerate(protocol['tasks']):
        slot=task['slot'];claim=OUT/'claims'/slot;claim.mkdir();write(claim/'owner.json',owner())
        (OUT/'attempts'/slot).mkdir();write(OUT/'attempts'/slot/'owner.json',owner())
        started=time.monotonic();signal.alarm(protocol['per_task_seconds'])
        result=dict(slot=slot,request=task,protocol_sha256=sha(OUT/'protocol.json'),owner=owner())
        try:
            print('MOLECULE START',slot,task['smiles'],flush=True)
            warnings=[];detail={}
            energy,sigma=backend.species(task['charge'],task['smiles'],slot,warnings,detail)
            result.update(energy_kj=energy,sampling_sigma_kj=sigma,warnings=warnings,diagnostics=detail)
            if energy is None:
                result['status']='workflow_no_estimate'
            else:
                assert math.isfinite(energy) and math.isfinite(sigma) and sigma>=0
                key=dict(settings.species_key(),model=backend.model_name,producer=backend.producer)
                path=Path(cache._path(task['smiles'],task['charge'],'implicit',key)[0])
                raw=read(path);assert raw['G']==energy and raw['sigma']==sigma
                assert raw['q']==task['charge'] and raw['smi']==cache.canonical(task['smiles'])
                assert {k:v for k,v in raw['settings'].items() if k!='producer'}=={k:v for k,v in read(HERE/'catalog.json')['settings'].items() if k!='producer'}
                assert raw['settings']['producer']==backend.producer
                result.update(status='molecular_record_complete',cache_path=str(path),cache_sha256=sha(path))
                status['completed'].append(slot)
        except BaseException as error:
            result.update(status='execution_failure',error=str(error),traceback=traceback.format_exc())
            status['failures'].append(slot)
        finally:
            signal.alarm(0);result['elapsed_seconds']=time.monotonic()-started
            result['execution']=backend.pu.execution_snapshot()
            write(OUT/'results'/(slot+'.json'),result);shutil.rmtree(claim);write(OUT/'status.json',status)
        print('MOLECULE TERMINAL',slot,result['status'],flush=True)
    status['state']='complete' if len(status['completed'])==len(protocol['tasks']) else 'terminal_with_unavailable_parents'
    write(OUT/'status.json',status)

if __name__=='__main__':main()
