"""Replay native solvent derivatives and independent QR thermochemistry."""
from pathlib import Path
import gzip,hashlib,importlib.util,json,math,re,sys
import numpy as np
from ase import Atoms,units
from ase.thermochemistry import IdealGasThermo
from common import HERE,authenticate,read,sha,write

PARSER=HERE/'audit_alpb_forces.py' if (HERE/'audit_alpb_forces.py').exists() else HERE.parents[1]/'benchmark/audit_alpb_forces.py'
spec=importlib.util.spec_from_file_location('reference_cycle_native_parser',PARSER)
native=importlib.util.module_from_spec(spec);spec.loader.exec_module(native)

def pair(records,symbols,xyz,charge,protocol):
    assert len(records)==2 and [r['phase'] for r in records]==['gas','aqueous']
    config=dict(accuracy=protocol['xtb_accuracy'],sasa_grid=protocol['solvent_grid'],Bohr_to_A=protocol['units']['Bohr_to_A'])
    values=[];gradients=[]
    for r,phase in zip(records,[False,True]):
        m=re.search(r'TOTAL ENERGY\s+('+native.NUMBER+r')\s+Eh',r['stdout']);assert m
        e=float(m[1].replace('D','E'))
        header=re.search(r'SCF energy\s*=\s*('+native.NUMBER+')',r['gradient_file']);assert header
        assert abs(float(header[1].replace('D','E'))-e)<1e-8
        values.append(native.check_record(dict(r,solvent=phase,gradient_requested=True,energy_Eh=e),symbols,xyz,charge,phase,True,config))
        gradients.append(native.extract_gradient(r['gradient_file'],symbols,xyz,config))
    conversion=protocol['units']['Hartree_to_kj']/protocol['units']['eV_to_kj']
    return (values[1]-values[0])*conversion,-(gradients[1]-gradients[0])*conversion/protocol['units']['Bohr_to_A']

def QR_thermo(symbols,xyz,H,energy,protocol):
    atoms=Atoms(symbols,positions=xyz);m=atoms.get_masses();position=xyz-atoms.get_center_of_mass();v=[]
    for axis in range(3):
        a=np.zeros_like(xyz);a[:,axis]=1;v.append((a*np.sqrt(m)[:,None]).ravel())
    for axis in range(3):
        a=np.zeros(3);a[axis]=1;v.append((np.cross(a,position)*np.sqrt(m)[:,None]).ravel())
    matrix=np.array(v).T;assert np.linalg.matrix_rank(matrix)==6
    Q,_=np.linalg.qr(matrix,mode='complete');B=Q[:,6:];root_mass=np.repeat(np.sqrt(m),3)
    eigenvalues=np.linalg.eigvalsh(B.T@(H/np.outer(root_mass,root_mass))@B)
    quanta=units._hbar*1e10/np.sqrt(units._e*units._amu)*np.sqrt(abs(eigenvalues));cm2ev=1.23984e-4
    negatives=quanta[eigenvalues<0]/cm2ev;n_bad=int(np.sum(negatives>protocol['imaginary_mode_threshold_cm']))
    kept=np.sort(np.concatenate([quanta[eigenvalues>=0],quanta[(eigenvalues<0)&(quanta/cm2ev<=protocol['imaginary_mode_threshold_cm'])]]))
    kept=np.maximum(kept,protocol['frequency_floor_cm']*cm2ev)
    th=IdealGasThermo(vib_energies=kept,potentialenergy=energy,atoms=atoms,geometry='nonlinear',symmetrynumber=1,spin=0,vib_selection='all')
    correction=(th.get_gibbs_energy(temperature=298.15,pressure=101325,verbose=False)-energy)*protocol['units']['eV_to_kj']
    return float(correction),n_bad,negatives.tolist()

def main():
    if '--records-only' in sys.argv:
        for name,digest in read(HERE/'freeze.json')['files_sha256'].items():assert sha(HERE/name)==digest,name
        inputs,protocol=read(HERE/'geometry_inputs.json'),read(HERE/'protocol.json')
    else:inputs,protocol=authenticate()
    index=read(HERE/'retained_geometry_index.json');status=read(HERE/'molecular_status.json')
    assert status['state']=='complete' and len(status['optimized'])==48
    assert not status['optimizer_failures'] and not status['curvature_failures']
    output={};native_count=0;soft_negative=[]
    for slots in index.values():
        for slot in slots:
            directory=HERE/'curvature'/slot;r=read(directory/'result.json');assert r['passed']
            H_archive=np.load(directory/'electronic.npz',allow_pickle=False);H=H_archive['H_UMA'];force=H_archive['force_UMA_eV_A'];E=float(H_archive['energy_UMA_eV'])
            assert abs(E-r['UMA_energy_eV'])<1e-12
            assert sha(directory/'electronic.npz')==r['electronic_Hessian_sha256']
            assert sha(directory/'native.jsonl.gz')==r['native_records_sha256']
            with gzip.open(directory/'native.jsonl.gz','rt') as f:records=[json.loads(s) for s in f]
            xyz=np.array(r['positions_A']);n=xyz.size;cursor=0;rows=[]
            def consume(positions):
                nonlocal cursor,native_count
                value=pair(records[cursor:cursor+2],r['symbols'],positions,r['charge'],protocol);cursor+=2;native_count+=2;return value
            solvent,solvent_force=consume(xyz)
            assert abs(solvent-r['ALPB_delta_eV'])<1e-12
            total_force=force+(solvent_force if r['mode']=='aqueous' else 0.)
            assert np.linalg.norm(total_force,axis=1).max()<=protocol['fmax_eV_A']
            for saved in r['Hessian_steps']:
                step=saved['step_A'];combined=H
                if step is not None:
                    columns=[]
                    for column in range(n):
                        plus=xyz.copy();plus.flat[column]+=step;minus=xyz.copy();minus.flat[column]-=step
                        _,Fp=consume(plus);_,Fm=consume(minus);columns.append(-(Fp-Fm).ravel()/(2*step))
                    HS=np.column_stack(columns);asymmetry=float(abs(HS-HS.T).max());combined=H+.5*(HS+HS.T)
                    stored=np.load(directory/f'solvent_h{step:.4f}.npz',allow_pickle=False)
                    assert abs(stored['H_solvent_raw']-HS).max()<1e-12 and abs(stored['H_total']-combined).max()<1e-12
                    assert abs(asymmetry-saved['Hessian_asymmetry_eV_A2'])<1e-12 and asymmetry<=protocol['max_solvent_Hessian_asymmetry_eV_A2']
                correction,bad,negative=QR_thermo(r['symbols'],xyz,combined,E+solvent,protocol)
                assert abs(correction-saved['RRHO_kj'])<1e-6 and bad==saved['n_imag']==0
                rows.append(dict(step_A=step,RRHO_kj=correction,negative_frequencies_cm=negative))
            assert cursor==len(records)
            assert abs(rows[-1]['RRHO_kj']-r['RRHO_kj'])<1e-6
            assert len(rows)==1 or abs(rows[0]['RRHO_kj']-rows[1]['RRHO_kj'])<=protocol['RRHO_step_sensitivity_max_kj']
            if rows[-1]['negative_frequencies_cm']:soft_negative.append(slot)
            output[slot]=dict(steps=rows,complete_native_records=len(records))
    result=dict(passed=True,n_retained_geometries=len(output),native_executions_reconstructed=native_count,states=output,
        states_with_negative_modes_below_declared_threshold=soft_negative,
        scope='Independent native/QR numerical replay. Passing the50cm mode policy is not proof of strictly positive curvature, full conformer completeness or experimental accuracy.')
    write(HERE/'independent_audit.json',result);print(json.dumps({k:v for k,v in result.items() if k!='states'},indent=2))

if __name__=='__main__':main()
