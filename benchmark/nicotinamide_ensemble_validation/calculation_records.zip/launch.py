"""Freeze, replay UMA, and launch two bounded gate-owned H100 workers."""
from pathlib import Path
import argparse
import ast
import datetime
import json
import os
import shlex
import subprocess
import sys
import time
from control_common import HERE, authenticate, load_point, owner, sha, write

GATE = '/nfs/lambda_stor_01/homes/rzhu/bin/gpu_reserve'
HELPER = '/nfs/lambda_stor_01/homes/rzhu/.codex-personal/skills/lambda-fleet/scripts/preflight_node.py'
DFT_PYTHON = '/nfs/lambda_stor_01/homes/rzhu/miniforge3/envs/redox/bin/python'
UMA_PYTHON = '/nfs/lambda_stor_01/homes/rzhu/.cache/metag-environments/uma-nitro-20261023-645af7d/venv/bin/python'
DEPENDENCIES = HERE.parent / 'nicotinamide_reference_control_20261104_01'
CAPS = {key:'1' for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']}
environment = dict(os.environ, **CAPS, PYTHONDONTWRITEBYTECODE='1', HF_HUB_OFFLINE='1')
environment.pop('CUDA_VISIBLE_DEVICES', None)
parser = argparse.ArgumentParser()
parser.add_argument('stage', choices=['freeze','uma','dft'])
args = parser.parse_args()

if args.stage == 'freeze':
    assert not (HERE / 'study_manifest.json').exists()
    for path in HERE.glob('*.py'):ast.parse(path.read_text(), filename=str(path))
    names = [str(path.relative_to(HERE)) for path in HERE.rglob('*') if path.is_file()
        and (path.parent == HERE or path.parent.name in ['raw_records','reused_points'])
        and path.suffix in ['.py','.json','.log']]
    write(HERE / 'study_manifest.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        files_sha256={name:sha(HERE/name) for name in sorted(names)},
        scope='Immutable scientific inputs and producer code. Subsequent worker and progress records are separate.'))
    inputs, protocol = authenticate()
    assert sum(load_point(slot,inputs,protocol) is not None for slot in inputs['inputs']) == 9
    print('Frozen:103 geometries;9 reused;94 new gas/SMD pairs.', flush=True)
elif args.stage == 'uma':
    inputs, protocol = authenticate()
    assert not (HERE / 'uma_launcher_owner.json').exists()
    runtime_environment = dict(environment, PYTHONPATH=os.pathsep.join(
        [str(DEPENDENCIES/'uma_source/src'),str(DEPENDENCIES/'fairchem_sdk/src')]))
    argv = [sys.executable, HELPER, 'local', '--python', UMA_PYTHON, '--cpu-set', '27,28',
        '--min-available-ram-mib','131072','--module','torch','--module','ase',
        '--module','fairchem.core','--module','metag.energetics.uma',
        '--path',str(HERE/'geometry_inputs.json'),'--bin',GATE]
    result = subprocess.run(argv,env=runtime_environment,capture_output=True,text=True,timeout=60)
    (HERE/'uma_preflight.json').write_text(result.stdout)
    if result.returncode:raise RuntimeError(result.stdout+result.stderr)
    deps=json.loads((DEPENDENCIES/'dependency_sources.json').read_text())
    for name,digest in deps['files_sha256'].items():assert sha(DEPENDENCIES/name)==digest
    runtime = dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        deadline_utc=(datetime.datetime.now(datetime.timezone.utc)+datetime.timedelta(seconds=18000)).isoformat(),
        dependencies_root=str(DEPENDENCIES),dependency_manifest_sha256=sha(DEPENDENCIES/'dependency_sources.json'),
        uma_python=UMA_PYTHON,uma_cpu_set=[27,28],uma_host=os.uname().nodename,
        dft_python=DFT_PYTHON,study_manifest_sha256=sha(HERE/'study_manifest.json'))
    write(HERE/'runtime_start.json',runtime)
    argv=[GATE,'run','7','--label','metag_nicotinamide_ensemble_uma_replay','--',
        '/usr/bin/taskset','-c','27,28',UMA_PYTHON,str(HERE/'replay_uma.py')]
    with (HERE/'uma_launcher.log').open('x') as stream:
        process=subprocess.Popen(argv,env=runtime_environment,stdin=subprocess.DEVNULL,
            stdout=stream,stderr=subprocess.STDOUT,start_new_session=True)
    write(HERE/'uma_launcher_owner.json',dict(host=os.uname().nodename,pid=process.pid,
        start_ticks=Path(f'/proc/{process.pid}/stat').read_text().rsplit(')',1)[1].split()[19],argv=argv))
    print(process.pid,flush=True)
else:
    inputs,protocol=authenticate()
    assert not (HERE/'launch_manifest.json').exists(), 'Existing launch must be audited before any resume'
    runtime=json.loads((HERE/'runtime_start.json').read_text())
    replay=json.loads((HERE/'uma_replay.json').read_text())
    assert replay['passed'] and set(replay['rows'])==set(inputs['inputs'])
    assert all(row['passed'] and abs(row['difference_kj'])<=protocol['UMA_replay_max_difference_kj'] for row in replay['rows'].values())
    result=subprocess.run([sys.executable,HELPER,'lambda13','--python',DFT_PYTHON,
        '--cpu-set','8-15','--min-available-ram-mib','327680',
        '--module','numpy','--module','pyscf','--module','cupy','--module','gpu4pyscf.dft',
        '--module','gpu4pyscf.solvent','--module','ase','--bin',GATE,
        '--path',str(HERE/'geometry_inputs.json'),
        '--library-path',str(Path(DFT_PYTHON).parents[1]/'lib')],
        env=environment,capture_output=True,text=True,timeout=65)
    (HERE/'dft_final_preflight.json').write_text(result.stdout)
    if result.returncode:raise RuntimeError(result.stdout+result.stderr)
    workers={
        'h100_0':dict(host='lambda13',gpu_index=0,gpu_uuid='GPU-838cc0bc-258a-4ee0-c563-0a0bc74eab00',cpus=list(range(8,12)),architecture_bridge_slot='full_ox__minimum_031'),
        'h100_1':dict(host='lambda13',gpu_index=1,gpu_uuid='GPU-4fc09ffb-eb36-f2b3-e5ba-ff79cad8c60b',cpus=list(range(12,16)),architecture_bridge_slot='full_red__minimum_046')}
    by_family={family:sorted([key for key,item in inputs['inputs'].items() if item['family']==family],
        key=lambda key:(inputs['inputs'][key]['original_components_kj']['total_kj'],key))
        for family in inputs['family_counts']}
    order=[]
    for i in range(max(map(len,by_family.values()))):
        for family in ['full_ox','full_red','core_ox','core_red']:
            if i<len(by_family[family]):order.append(by_family[family][i])
    assert len(set(order))==len(order)==103
    launch=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        deadline_utc=runtime['deadline_utc'],dft_python=DFT_PYTHON,
        study_manifest_sha256=sha(HERE/'study_manifest.json'),workers=workers,
        queue_order=order,maximum_new_scientific_pairs=94,maximum_large_architecture_bridge_pairs=2,
        total_gpu_hour_ceiling=protocol['total_gpu_hour_ceiling'],native_thread_caps=CAPS,
        cpu_GPU_fixture='One independently reproduced CPU water fixture per H100 worker.')
    write(HERE/'launch_manifest.json',launch)
    commands=[]
    for key,worker in workers.items():
        argv=['env',*[f'{name}={value}' for name,value in CAPS.items()],
            'PYTHONDONTWRITEBYTECODE=1','LD_LIBRARY_PATH='+str(Path(DFT_PYTHON).parents[1]/'lib'),
            GATE,'run',str(worker['gpu_index']),'--label','metag_nicotinamide_ensemble_'+key,'--',
            '/usr/bin/taskset','-c',','.join(map(str,worker['cpus'])),DFT_PYTHON,str(HERE/'worker.py'),key]
        log=HERE/'workers'/(key+'.launcher.log')
        remote='nohup '+shlex.join(argv)+' >'+shlex.quote(str(log))+' 2>&1 < /dev/null &'
        result=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=8',worker['host'],remote],capture_output=True,text=True,timeout=20)
        write(HERE/'workers'/(key+'.submission.json'),dict(argv=argv,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
        result.check_returncode();commands.append(dict(worker=key,host=worker['host'],gpu=worker['gpu_index']))
        time.sleep(2)
    print(json.dumps(commands),flush=True)
