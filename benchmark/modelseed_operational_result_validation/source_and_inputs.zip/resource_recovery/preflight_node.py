"""Run the fleet helper locally on the candidate host with the actual environment."""
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from common import HERE,PYTHON,GATE,XTB,LIB,environment,write

assert os.uname().nodename=='lambda13'
helper='/nfs/lambda_stor_01/homes/rzhu/.codex-personal/skills/lambda-fleet/scripts/preflight_node.py'
reports=[];env=environment()
for worker,cpus in [('worker0',[372,373]),('worker1',[374,375])]:
    command=['/usr/bin/python3',helper,'local','--python',PYTHON,'--cpu-set',','.join(map(str,cpus)),
        '--min-available-ram-mib','65536','--library-path',LIB,'--bin',GATE,'--bin',XTB,
        '--path',str(HERE/'owned_source/src'),'--module','rdkit','--module','torch','--module','ase',
        '--module','fairchem.core','--module','metag.energetics.backend','--timeout','180']
    result=subprocess.run(command,env=env,capture_output=True,text=True,timeout=190)
    report=json.loads(result.stdout);write(HERE/(worker+'.dependency_preflight.json'),report)
    assert result.returncode==0 and report['ok'],(result.stdout,result.stderr)
    reports.append(dict(worker=worker,report=report))
version=subprocess.run([XTB,'--version'],env=env,capture_output=True,text=True,timeout=20)
assert version.returncode==0,(version.stdout,version.stderr)
probe=subprocess.run([PYTHON,'-c',
    'import json,metag,fairchem.core;print(json.dumps(dict(metag=metag.__file__,fairchem=fairchem.core.__file__)))'],
    env=env,capture_output=True,text=True,timeout=30)
assert probe.returncode==0,(probe.stdout,probe.stderr)
paths=json.loads(probe.stdout.strip().splitlines()[-1])
assert str(HERE/'owned_source/src') in paths['metag'] and 'nicotinamide_reference_control' in paths['fairchem']
assert 'backup/' not in json.dumps(paths)
assert shutil.disk_usage('/tmp').free>10*1024**3
write(HERE/'node_dependency_preflight.json',dict(host=os.uname().nodename,workers=reports,module_paths=paths,
    xtb_version_output=version.stdout+version.stderr,tmp_available_bytes=shutil.disk_usage('/tmp').free,
    gpu_compute_apps=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True)))
print(json.dumps(dict(status='passed',host=os.uname().nodename,module_paths=paths,workers=[r['worker'] for r in reports])))
