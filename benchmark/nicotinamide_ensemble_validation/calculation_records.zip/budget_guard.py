"""Bound aggregate GPU occupancy using one conservative common stop deadline."""
from pathlib import Path
import datetime
import json
import os
import signal
import subprocess
import time
from control_common import HERE,owner,write

plan=json.loads((HERE/'parallel_execution_amendment.json').read_text())
assert os.uname().nodename=='lambda13' and sorted(os.sched_getaffinity(0))==[36]
write(HERE/'budget_guard_owner.json',owner())
deadline=datetime.datetime.fromisoformat(plan['common_budget_stop_utc'])
manifest=json.loads((HERE/'launch_manifest.json').read_text())

def live(record):
    path=Path('/proc')/str(record['pid'])
    try:return (path/'stat').read_text().rsplit(')',1)[1].split()[19]==str(record['start_ticks'])
    except FileNotFoundError:return False

def inspect():
    workers=[];known=0
    for key in manifest['workers']:
        paths=[HERE/'workers'/key/'owner.json',HERE/'workers'/(key+'.launcher_owner.json')]
        available=[path for path in paths if path.exists()]
        if available:known+=1
        if available:
            r=json.loads(available[0].read_text())
            if live(r):workers.append(dict(r,worker=key))
    gpu=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True)
    predictors=[]
    for line in gpu.splitlines():
        uuid,pid=[part.strip() for part in line.split(',')]
        try:
            path=Path('/proc')/pid;argv=(path/'cmdline').read_bytes().decode().split('\0')
            if str(HERE/'reference_point.py') not in argv:continue
            tick=(path/'stat').read_text().rsplit(')',1)[1].split()[19]
            predictors.append(dict(host=os.uname().nodename,pid=int(pid),start_ticks=tick,gpu_uuid=uuid))
        except (FileNotFoundError,ProcessLookupError):continue
    return dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),known_workers=known,
        live_workers=workers,live_predictors=predictors)

status=dict(state='running',stop_deadline_utc=deadline.isoformat(),aggregate_GPU_hour_upper_bound=plan['conservative_GPU_hour_upper_bound'])
try:
    while True:
        current=inspect();status['observation']=current;write(HERE/'budget_guard_status.json',status)
        if current['known_workers']==len(manifest['workers']) and not current['live_workers'] and not current['live_predictors']:
            status['state']='all_original_producers_terminal';break
        if datetime.datetime.now(datetime.timezone.utc)>=deadline:
            status['state']='aggregate_budget_stop_requested';write(HERE/'budget_guard_status.json',status)
            for r in current['live_workers']:
                if live(r):os.kill(r['pid'],signal.SIGTERM)
            # Controllers join their own CUDA children before their leases exit.
            time.sleep(20)
            current=inspect()
            for r in current['live_predictors']:
                if live(r):os.killpg(r['pid'],signal.SIGTERM)
            time.sleep(10)
            current=inspect()
            for r in current['live_predictors']:
                if live(r):os.killpg(r['pid'],signal.SIGKILL)
            status['observation']=inspect();status['state']='aggregate_budget_stop_complete';break
        time.sleep(10)
finally:write(HERE/'budget_guard_status.json',status)
