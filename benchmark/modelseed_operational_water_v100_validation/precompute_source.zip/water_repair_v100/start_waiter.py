from pathlib import Path
import os,subprocess
from common import HERE,environment,write,owner,read,sha
assert not (HERE/'waiter_launcher.json').exists() and not (HERE/'wait_request.json').exists()
with (HERE/'waiter.log').open('x') as log:
 child=subprocess.Popen(['/usr/bin/taskset','-c','76,77','/usr/bin/python3',str(HERE/'wait_for_gate.py')],env=environment(),stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
start=Path('/proc',str(child.pid),'stat').read_text().rsplit(')',1)[1].split()[19]
write(HERE/'waiter_launcher.json',dict(pid=child.pid,start_ticks=start,host=os.uname().nodename,cpus=[76,77],freeze_sha256=sha(HERE/'freeze.json')))
print('Bounded water-capacity coordinator',child.pid,start)
