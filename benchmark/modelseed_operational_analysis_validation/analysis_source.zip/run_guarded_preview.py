from pathlib import Path
import importlib.abc
import os,runpy,socket,sys
H=Path(__file__).resolve().parent;P=H.parents[1];R=H/'resource_recovery'
class NoQuantum(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'torch','fairchem','cupy','pyscf'}:raise RuntimeError('Quantum import forbidden in retained-record preview: '+fullname)
sys.meta_path.insert(0,NoQuantum())
forbidden=[str((H/'cache').resolve()),str((P/'src').resolve())]
def audit(event,args):
 if event=='open' and not isinstance(args[0],int):
  path=os.path.realpath(os.fsdecode(args[0]))
  if any(path==root or path.startswith(root+os.sep) for root in forbidden):raise RuntimeError('Unowned/live source fallback forbidden: '+path)
 if event in {'socket.connect','socket.getaddrinfo'}:raise RuntimeError('Network forbidden in retained-record preview')
sys.addaudithook(audit);sys.dont_write_bytecode=True
sys.argv=[str(H/'analyze_results.py'),'--preview','--output',str(R/'preview01')]
runpy.run_path(str(H/'analyze_results.py'),run_name='__main__')
