"""Matched gas/effective-water optimizations and curvature on frozen starts."""
from pathlib import Path
import gzip,json,math,os,signal,time,traceback
import numpy as np
from ase import Atoms
from ase.calculators.calculator import Calculator,all_changes
from ase.optimize import FIRE,LBFGS
from rdkit import Chem
from rdkit.Chem import rdMolAlign
from common import HERE,authenticate,owner,read,sha,write
from solvent_gradient import evaluate

def stop(signum,frame):raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
inputs,protocol=authenticate();launch=read(HERE/'launch_manifest.json')
assert sorted(os.sched_getaffinity(0))==launch['cpus']
assert read(HERE/'force_fixture.json')['passed'] and read(HERE/'force_fixture.json')['complete']
import torch
torch.set_num_threads(1);torch.set_num_interop_threads(1)
from metag.energetics.uma import load_uma,_predict
from metag.energetics.thermal import uma_hessian_autograd,gibbs_corr_from_hessian
from metag.energetics.conformers import bond_graph,same_connectivity,same_stereochemistry

write(HERE/'molecular_predictor_owner.json',owner())
calculator=load_uma(protocol['model'],profile=protocol['profile'])
assert calculator.metag_provenance==read(HERE/'expected_UMA_producer.json'),'Original model producer changed; no chemistry attempted'
write(HERE/'model_provenance.json',dict(producer=calculator.metag_provenance,runtime=calculator.metag_runtime_profile,owner=owner()))
status=dict(state='running',optimizer_expected=48,optimized=[],optimizer_failures=[],retained=[],curvature_failures=[])
start=time.monotonic();counter=0

class Potential(Calculator):
    implemented_properties=['energy','forces']
    def __init__(self,mode,raw,trace,deadline):
        super().__init__();self.mode=mode;self.raw=raw;self.trace=trace;self.deadline=deadline;self.last=None
    def calculate(self,atoms=None,properties=('energy','forces'),system_changes=all_changes):
        assert time.monotonic()<self.deadline,'Declared per-pose optimization budget exhausted'
        super().calculate(atoms,properties,system_changes)
        energy,force,_=_predict(calculator,[atoms]);E=float(energy.detach().cpu().numpy()[0]);F=force.detach().cpu().numpy().astype(float)
        solvent=evaluate(atoms.get_chemical_symbols(),atoms.positions,atoms.info['charge'],protocol,self.raw) if self.mode=='aqueous' else None
        self.results=dict(energy=E+(solvent['energy_eV'] if solvent else 0.),forces=F+(solvent['forces_eV_A'] if solvent else 0.))
        self.last=dict(UMA_energy_eV=E,solvent_delta_eV=solvent['energy_eV'] if solvent else None,
                       potential_eV=self.results['energy'],forces_eV_A=self.results['forces'].tolist(),positions_A=atoms.positions.tolist())
        self.trace.write(json.dumps(self.last)+'\n');self.trace.flush()

def identity(atoms,molecule):
    return bool(same_connectivity(atoms,bond_graph(molecule)) and same_stereochemistry(atoms,molecule))

def rmsd(a,b,molecule):
    def with_xyz(xyz):
        m=Chem.Mol(molecule);m.RemoveAllConformers();c=Chem.Conformer(m.GetNumAtoms())
        for i,p in enumerate(xyz):c.SetAtomPosition(i,p)
        m.AddConformer(c);return m
    return rdMolAlign.GetBestRMS(with_xyz(a),with_xyz(b),maxMatches=10000)

def curvature(slot,record,molecule,mode):
    directory=HERE/'curvature'/slot;directory.mkdir(parents=True)
    atoms=Atoms(record['symbols'],positions=record['positions_A']);atoms.info.update(charge=record['charge'],spin=1)
    energy,force,_=_predict(calculator,[atoms]);E=float(energy.detach().cpu().numpy()[0]);F=force.detach().cpu().numpy().astype(float)
    assert abs((E-record['UMA_energy_eV'])*96.485)<.005
    H=uma_hessian_autograd(calculator,atoms,rows=protocol['Hessian_rows'])
    assert H.shape==(3*len(atoms),3*len(atoms)) and np.isfinite(H).all()
    np.savez_compressed(directory/'electronic.npz',H_UMA=H,energy_UMA_eV=E,force_UMA_eV_A=F)
    rows=[]
    with gzip.open(directory/'native.jsonl.gz','xt') as raw:
        solvent=evaluate(record['symbols'],atoms.positions,record['charge'],protocol,raw)
        total=E+solvent['energy_eV'];force_final=F+(solvent['forces_eV_A'] if mode=='aqueous' else 0.)
        assert identity(atoms,molecule) and np.linalg.norm(force_final,axis=1).max()<=protocol['fmax_eV_A']
        for step in (protocol['solvent_Hessian_steps_A'] if mode=='aqueous' else [None]):
            if step is None:combined=H;asymmetry=0.
            else:
                columns=[]
                for column in range(atoms.positions.size):
                    derivatives=[]
                    for sign in [1,-1]:
                        xyz=atoms.positions.copy();xyz.flat[column]+=sign*step
                        v=evaluate(record['symbols'],xyz,record['charge'],protocol,raw)
                        derivatives.append(v['forces_eV_A'])
                    columns.append(-(derivatives[0]-derivatives[1]).ravel()/(2*step))
                solvent_H=np.column_stack(columns);asymmetry=float(np.max(np.abs(solvent_H-solvent_H.T)))
                combined=H+.5*(solvent_H+solvent_H.T)
                np.savez_compressed(directory/f'solvent_h{step:.4f}.npz',H_solvent_raw=solvent_H,H_total=combined)
            correction,detail=gibbs_corr_from_hessian(atoms,combined,total,'nonlinear',symmetrynumber=1,spin=1,return_info=True,imag_as_soft=False,temperature_K=298.15,pressure_Pa=101325)
            row=dict(step_A=step,RRHO_kj=correction,n_imag=detail['n_imag'],max_imag_cm=detail['max_imag_cm'],Hessian_asymmetry_eV_A2=asymmetry)
            rows.append(row)
            assert row['n_imag']==0 and asymmetry<=protocol['max_solvent_Hessian_asymmetry_eV_A2'],row
        assert len(rows)==1 or abs(rows[0]['RRHO_kj']-rows[1]['RRHO_kj'])<=protocol['RRHO_step_sensitivity_max_kj']
    result=dict(record,passed=True,Hessian_steps=rows,RRHO_kj=rows[-1]['RRHO_kj'],UMA_energy_eV=E,ALPB_delta_eV=solvent['energy_eV'],UMA_ALPB_raw_G_kj=total*96.485+rows[-1]['RRHO_kj'],electronic_Hessian_sha256=sha(directory/'electronic.npz'),native_records_sha256=sha(directory/'native.jsonl.gz'),owner=owner())
    write(directory/'result.json',result);return result

try:
    geometries={};consecutive=0
    for species,item in inputs['species'].items():
        molecule=Chem.AddHs(Chem.MolFromSmiles(item['smiles']));assert [a.GetSymbol() for a in molecule.GetAtoms()]==item['symbols']
        for mode in inputs['geometry_modes']:
            rows=[]
            for seed,xyz in enumerate(item['poses']):
                slot=f'{species}__{mode}__{seed:02d}';attempt=HERE/'optimization'/slot;attempt.mkdir(parents=True);write(attempt/'owner.json',owner())
                claim=HERE/'claims'/slot;claim.mkdir(parents=True);write(claim/'owner.json',owner())
                print('OPTIMIZATION START '+slot,flush=True)
                try:
                    atoms=Atoms(item['symbols'],positions=xyz);atoms.info.update(charge=item['charge'],spin=1);assert identity(atoms,molecule)
                    with gzip.open(attempt/'native.jsonl.gz','xt') as raw,gzip.open(attempt/'trace.jsonl.gz','xt') as trace:
                        potential=Potential(mode,raw,trace,time.monotonic()+protocol['per_pose_budget_seconds']);atoms.calc=potential
                        FIRE(atoms,logfile=str(attempt/'FIRE.log'),dt=.05,dtmax=.5,maxstep=.1).run(fmax=.02,steps=protocol['FIRE_steps'])
                        success=LBFGS(atoms,logfile=str(attempt/'LBFGS.log'),maxstep=.1).run(fmax=protocol['fmax_eV_A'],steps=protocol['LBFGS_steps'])
                        assert success and identity(atoms,molecule),'Force/identity quality refusal'
                        last=potential.last
                    result=dict(slot=slot,species=species,mode=mode,seed_index=seed,smiles=item['smiles'],charge=item['charge'],symbols=item['symbols'],positions_A=atoms.positions.tolist(),UMA_energy_eV=last['UMA_energy_eV'],optimized_potential_eV=last['potential_eV'],maximum_force_eV_A=float(np.linalg.norm(atoms.get_forces(),axis=1).max()),passed=True,owner=owner())
                    write(attempt/'result.json',result);rows.append(result);status['optimized'].append(slot);consecutive=0
                    print('OPTIMIZATION COMPLETE '+slot,flush=True)
                except Exception as error:
                    failure=dict(slot=slot,error=str(error),traceback=traceback.format_exc());write(attempt/'failure.json',failure);status['optimizer_failures'].append(failure);consecutive+=1
                    if consecutive>=3:raise
                finally:
                    import shutil
                    shutil.rmtree(claim);write(HERE/'molecular_status.json',status)
            if len(rows)!=4:continue
            retained=[]
            for row in sorted(rows,key=lambda v:(v['optimized_potential_eV'],v['slot'])):
                if not any(abs(row['optimized_potential_eV']-old['optimized_potential_eV'])<=protocol['minimum_energy_tolerance_eV'] and rmsd(row['positions_A'],old['positions_A'],molecule)<=protocol['minimum_RMSD_A'] for old in retained):retained.append(row)
            geometries[(species,mode)]=(molecule,retained)
    write(HERE/'retained_geometry_index.json',{f'{s}|{m}':[v['slot'] for v in rows] for (s,m),(_,rows) in geometries.items()})
    consecutive=0
    for (species,mode),(molecule,rows) in geometries.items():
        for row in rows:
            slot=row['slot'];claim=HERE/'claims'/slot;claim.mkdir();write(claim/'owner.json',owner())
            print('CURVATURE START '+slot,flush=True)
            try:
                curvature(slot,row,molecule,mode);status['retained'].append(slot);consecutive=0
                print('CURVATURE COMPLETE '+slot,flush=True)
            except Exception as error:
                failure=dict(slot=slot,error=str(error),traceback=traceback.format_exc());write(HERE/'curvature'/slot/'failure.json',failure);status['curvature_failures'].append(failure);consecutive+=1
                if consecutive>=3:raise
            finally:
                import shutil
                shutil.rmtree(claim);write(HERE/'molecular_status.json',status)
    assert len(status['optimized'])==48 and not status['optimizer_failures'] and not status['curvature_failures'],'Complete-pool endpoint withheld'
    status['state']='complete'
except BaseException as error:
    status.update(state='stopped',error=str(error),traceback=traceback.format_exc());raise
finally:
    status['elapsed_seconds']=time.monotonic()-start;write(HERE/'molecular_status.json',status)
