"""Review every remaining source-cross-referenced boundary molecule before QM."""
from pathlib import Path
import datetime
import hashlib
import json
import sys
import time
import urllib.request
import urllib.error

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT/'benchmark')]
from rdkit import Chem
from rdkit.Chem import rdMolDescriptors
from audit_modelseed_inputs import load_chunks
from modelseed_cofactor_curation import canonical,review_conversion
from metag.state_function import plan_state
from metag.energetics.conformers import spin_multiplicity

read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    prior=ROOT/'analysis/modelseed_cofactor_curation_20261105_01'
    preparation=read(prior/'boundary_prerequisites.json')
    original_registry=read(prior/'registry.json')
    compounds,files=load_chunks(ROOT.parent.parent/'ModelSEEDDatabase/Biochemistry','compound')
    ids=sorted({cid for row in preparation['requests'].values() for cid in row['request']['species']})
    ordinary={'cpd00001','cpd00007','cpd00009','cpd00012','cpd00013','cpd00025'}
    selected=[cid for cid in ids if cid not in original_registry and cid not in ordinary]
    selection=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        scope='Source identity review before physical comparisons; no energy/label selection.',
        rule='All remaining nucleotide/cofactor identities participating in the12fixedboundary reactions, using exactly the existing ChEBI cross-reference.',
        selected=selected,source_files_sha256=files,boundary_input_sha256=sha(prior/'boundary_prerequisites.json'),
        ordinary_small_molecules_not_recurated=sorted(ordinary))
    (HERE/'source_selection.json').write_text(json.dumps(selection,indent=2)+'\n')
    folder=HERE/'primary_sources';folder.mkdir(exist_ok=False)
    rows={};receipts=[]
    for cid in selected:
        source=compounds[cid]
        aliases={b.split(':',1)[0]:b.split(':',1)[1].strip() for b in source['aliases'].split('|') if ':' in b}
        numbers=aliases['ChEBI'].split('; ')
        assert len(numbers)==1,(cid,numbers)
        number=numbers[0];url='https://www.ebi.ac.uk/chebi/backend/api/public/molfile/'+number
        receipt=dict(compound=cid,chebi_id='CHEBI:'+number,url=url,
            utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        try:
            with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MetaG molecular-reference audit'}),timeout=30) as response:
                data=response.read();path=folder/(number+'.mol');path.write_bytes(data)
                receipt.update(status=response.status,final_url=response.url,bytes=len(data),sha256=sha(path))
            molecule=Chem.MolFromMolFile(str(path));assert molecule is not None
            target=dict(smiles=Chem.MolToSmiles(molecule,isomericSmiles=True),charge=Chem.GetFormalCharge(molecule),
                formula=rdMolDescriptors.CalcMolFormula(molecule),inchikey=Chem.MolToInchiKey(molecule))
            review=review_conversion(int(source['charge']),source['smiles'],target['charge'],target['smiles'])
            original_plan=plan_state(int(source['charge']),source['smiles'])
            target_plan=plan_state(target['charge'],target['smiles'])
            rows[cid]=dict(name=source['name'],chebi_id='CHEBI:'+number,
                source={key:source[key] for key in ['smiles','charge','formula','inchikey']},target=target,review=review,
                original_plan=original_plan,target_plan=target_plan,
                original_reference_spin=spin_multiplicity(original_plan['reference_smiles'],original_plan['reference_charge']),
                target_reference_spin=spin_multiplicity(target_plan['reference_smiles'],target_plan['reference_charge']))
        except Exception as error:
            receipt.update(error=repr(error))
            rows[cid]=dict(name=source['name'],chebi_id='CHEBI:'+number,status='unresolved_source_review',error=repr(error))
        receipts.append(receipt)
        (HERE/'source_retrieval.json').write_text(json.dumps(receipts,indent=2)+'\n')
        (HERE/'identity_review.json').write_text(json.dumps(rows,indent=2,allow_nan=False)+'\n')
        print(cid,source['name'],receipt.get('status'),rows[cid].get('error') or
            json.dumps(dict(source_q=source['charge'],target_q=target['charge'],delta_H=review['delta_H'],
                target_reference_q=target_plan['reference_charge'],same_raw_reference=(original_plan['reference_charge'],original_plan['reference_smiles'])==(target_plan['reference_charge'],target_plan['reference_smiles']))),flush=True)
        time.sleep(.25)


if __name__=='__main__':main()
