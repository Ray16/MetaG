from pathlib import Path
import importlib,os,shutil,sys
from common import HERE,PYTHON,XTB,SDK,owner,write,check_freeze
assert os.uname().nodename=='lambda13'
assert sorted(os.sched_getaffinity(0))==[374,375]
assert max(os.getloadavg())+2<=os.cpu_count()
assert shutil.disk_usage('/tmp').free>10*1024**3
memory={l.split(':',1)[0]:int(l.split(':',1)[1].split()[0]) for l in Path('/proc/meminfo').read_text().splitlines()}
assert memory['MemAvailable']>64*1024**2
assert Path(PYTHON).is_file() and Path(XTB).is_file() and Path(SDK).is_dir()
versions={}
for name in ['numpy','scipy','rdkit','ase','torch','fairchem.core','metag.energetics.species','metag.energetics.thermal','benchmark.operational_water']:
 module=importlib.import_module(name);versions[name]=getattr(module,'__version__',None)
from metag.energetics.species import water_geometry
from metag.energetics.thermal import uma_gibbs_corr
from metag.symmetry import geometry_and_sigma
assert callable(water_geometry) and callable(uma_gibbs_corr)
assert len(geometry_and_sigma(['O','H','H'],[[0,0,0],[.757,.586,0],[-.757,.586,0]]))==3
write(HERE/'node_preflight.json',dict(status='passed',owner=owner(),interpreter=sys.executable,versions=versions,available_RAM_MiB=memory['MemAvailable']/1024,
 native_caps={k:os.environ[k] for k in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']},
 branch_imports_checked=True,symmetry_return_arity=3,quantum_model_loaded=False))
print('Water-repair node imports and branch dependencies passed; no quantum model loaded.')
