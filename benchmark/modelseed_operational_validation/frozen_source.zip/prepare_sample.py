"""Build the fixed operational sample and discover raw inputs without quantum energies."""
from pathlib import Path
from fractions import Fraction
from collections import Counter
import copy,datetime,gzip,hashlib,json,os,sys
H=Path(__file__).resolve().parent;P=H.parents[1]
sys.path[:0]=[str(P/'src'),str(P),str(P/'benchmark')]
from rdkit import Chem,RDLogger
from benchmark.modelseed_sampling import ec_stratum,select
from benchmark.audit_modelseed_inputs import load_chunks,parse_equation,pin_one_cpu
from benchmark.modelseed_cofactor_curation import validate_registry,rebase_equation
from benchmark.anchored_nicotinamide_regio import RegioAnchoredEstimator
from metag.state_function import StateFunctionEstimator
from metag.settings import Settings
from metag.constants import CONDITIONS,G_HPLUS
from metag.energetics.conformers import spin_multiplicity

read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):
 with (H/name).open('x') as f:json.dump(value,f,indent=2,allow_nan=False);f.write('\n')
class Discovery:
 model_name='synthetic-prerequisite-discovery'
 producer=dict(cacheable=False,kind='synthetic-not-physical')
 settings=Settings(thermal_validation_max=96)
 def __init__(self):self.calls=set();self.water=False
 @staticmethod
 def gauge(smi):
  mol=Chem.AddHs(Chem.MolFromSmiles(smi))
  return float(sum(G_HPLUS if a.GetAtomicNum()==1 else -1000*a.GetAtomicNum() for a in mol.GetAtoms()))
 def species(self,q,smi,label,warnings,diagnostics):
  canonical=Chem.MolToSmiles(Chem.MolFromSmiles(smi),isomericSmiles=True)
  self.calls.add((q,canonical));diagnostics['method']='synthetic-prerequisite-enumeration'
  return self.gauge(canonical),0.
 def liquid_water(self):self.water=True;return self.gauge('O')

def main():
 resources=pin_one_cpu();RDLogger.DisableLog('rdApp.*')
 design=read(H/'design.json');old=P/'benchmark/modelseed_cofactor_curation_validation'
 for relative,digest in design['inputs_sha256'].items():assert sha(P/relative)==digest
 assert sha(P/'benchmark/modelseed_sampling.py')==design['sampling_code_sha256']
 database=P.parent.parent/'ModelSEEDDatabase/Biochemistry'
 compounds,cf=load_chunks(database,'compound');reactions,rf=load_chunks(database,'reaction')
 assert dict(cf,**rf)==read(old/'upstream_provenance.json')['source_files_sha256']
 registry=validate_registry(read(old/'registry.json'),compounds)
 curated=copy.deepcopy(compounds)
 for cid,row in registry.items():curated[cid].update(smiles=row['target']['smiles'],charge=str(row['target']['charge']))
 with gzip.open(old/'curated_outcomes.jsonl.gz','rt') as f:outcomes={r['reaction']:r for line in f if (r:=json.loads(line))}
 assert len(outcomes)==43650
 frame=[dict(reaction=rid,stratum=ec_stratum(reactions[rid].get('ec_numbers'))) for rid,r in outcomes.items() if r['status']=='passes_cpu_input_gates']
 assert len(frame)==9719
 sample=select(frame,design['sampling_per_stratum'],design['selection_seed'])
 requests={};primitives={};discovery={};projection={}
 for chosen in sample['selected']:
  rid=chosen['reaction'];source=reactions[rid];terms=parse_equation(source['stoichiometry'])
  after,changes=rebase_equation(terms,registry)
  assert len({comp for cid,comp in after})==1
  request=dict(species={},n_Hplus=0,conditions=dict(CONDITIONS))
  exact=[]
  for (cid,comp),nu in sorted(after.items()):
   number=int(nu) if nu.denominator==1 else float(nu);exact.append([cid,comp,str(nu)])
   if cid=='cpd00067':request['n_Hplus']+=number;continue
   row=curated[cid];request['species'][cid]=[number,int(row['charge']),row['smiles']]
   projection[cid]={k:row.get(k) for k in ['id','name','smiles','charge','formula']}
  requests[rid]=dict(name=source.get('name'),source_ec=source.get('ec_numbers'),source_status=source.get('status'),stratum=chosen['stratum'],request=request,exact_curated_terms=exact,proton_adjustments=changes,source_stoichiometry_sha256=hashlib.sha256(source['stoichiometry'].encode()).hexdigest())
  arm_rows={}
  for arm,estimator in [('full',StateFunctionEstimator),('regio',RegioAnchoredEstimator)]:
   backend=Discovery();result=estimator(backend).score_reaction(request,key=rid)
   members=[];over=[]
   for q,smi in sorted(backend.calls):
    key=str(q)+'|'+smi;mol=Chem.AddHs(Chem.MolFromSmiles(smi));n=mol.GetNumAtoms()
    entry=primitives.setdefault(key,dict(kind='species',charge=q,smiles=smi,spin=spin_multiplicity(smi,q),n_atoms=n,used_by=[]))
    entry['used_by'].append(dict(reaction=rid,arm=arm));members.append(key)
    if n>design['raw_policy']['max_total_atoms_per_primitive']:over.append(key)
   if backend.water:
    primitives.setdefault('liquid_water',dict(kind='liquid_water',charge=0,smiles='O',spin=1,n_atoms=3,used_by=[]))['used_by'].append(dict(reaction=rid,arm=arm));members.append('liquid_water')
   arm_rows[arm]=dict(prerequisites=members,static_discovery_complete=result['dG'] is not None,planning_refusal=result['suspect'],capacity_exceeded_primitives=over)
  discovery[rid]=arm_rows
 # No synthetic energy or sigma is exported. Queue only primitives needed by at least one statically admitted, capacity-supported arm.
 used={key for rid,arms in discovery.items() for arm,row in arms.items() if row['static_discovery_complete'] and not row['capacity_exceeded_primitives'] for key in row['prerequisites']}
 tasks=[]
 for key in sorted(used):
  entry=primitives[key];assert entry['n_atoms']<=100
  tasks.append(dict(slot='raw_'+hashlib.sha256(key.encode()).hexdigest()[:16],source_input_key=key,**entry))
 # An independent queue order prevents an EC-stratum-first resource cutoff.
 tasks.sort(key=lambda t:hashlib.sha256((design['selection_seed']+'|rawqueue|'+t['source_input_key']).encode()).hexdigest())
 summary=dict(scope='Fixed probability sample and structural prerequisite discovery only; no physical predictions or new labels.',n_source=43650,n_preflight_eligible=9719,n_selected=sample['sample_size'],source_strata=dict(Counter(ec_stratum(r.get('ec_numbers')) for rid,r in reactions.items() if rid in outcomes)),frame_strata={k:r['population'] for k,r in sample['strata'].items()},selected_strata={k:r['sample_size'] for k,r in sample['strata'].items()},n_unique_primitives_discovered=len(primitives),n_executable_raw_tasks=len(tasks),task_atoms=sorted(t['n_atoms'] for t in tasks),static_discovery_refusals={rid:{arm:r['planning_refusal'] for arm,r in arms.items() if not r['static_discovery_complete']} for rid,arms in discovery.items() if any(not r['static_discovery_complete'] for r in arms.values())},capacity_refused={rid:{arm:len(r['capacity_exceeded_primitives']) for arm,r in arms.items() if r['capacity_exceeded_primitives']} for rid,arms in discovery.items() if any(r['capacity_exceeded_primitives'] for r in arms.values())},source_files_sha256=dict(cf,**rf),resources=resources,quantum_calculations_started=False)
 write('frame.json',frame);write('sample.json',sample);write('requests.json',requests);write('compound_projection.json',projection);write('prerequisite_discovery.json',discovery);write('primitives.json',primitives);write('tasks.json',tasks);write('preparation_summary.json',summary)
 print(json.dumps({k:v for k,v in summary.items() if k not in ['source_files_sha256','capacity_refused','static_discovery_refusals']},indent=2))
 print('static_refusals',summary['static_discovery_refusals']);print('capacity_refused',summary['capacity_refused'])

if __name__=='__main__':main()
