"""Publish the complete frozen component experiment after all numerical checks."""
from pathlib import Path
import hashlib,importlib.util,json,shutil,zipfile

HERE=Path(__file__).resolve().parent;METAG=HERE.parents[1]
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

assert read(HERE/'controller_status.json')['state']=='complete'
assert read(HERE/'molecular_status.json')['state']=='complete'
assert read(HERE/'independent_audit.json')['passed']
assert read(HERE/'cpu_verification_summary.json')['passed']
assert not any(v['owned_live'] for v in read(HERE/'original_GPU_terminal_audit.json'))
assert not any(v['owned_live'] for v in read(HERE/'CPU_terminal_audit.json')['processes'])
assert not any((HERE/'claims').iterdir())
destination=METAG/'benchmark/reference_transfer_validation';assert not destination.exists()
destination.mkdir()
shutil.copy2(METAG/'benchmark/audit_alpb_forces.py',HERE/'audit_alpb_forces.py')
with zipfile.ZipFile(destination/'calculation_records.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for path in sorted(HERE.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and not path.name.startswith(('publication_','goal_checkpoint')):
            archive.write(path,str(path.relative_to(HERE)))
for name in ['results.json','reference.json','component_diagnosis.json','quantity_scope_audit.json']:
    shutil.copy2(HERE/name,destination/name)
shutil.copy2(METAG/'benchmark/reference_transfer.py',destination/'reference_transfer.py')
r=read(HERE/'results.json');arms=r['arms'];cpu=read(HERE/'cpu_verification_summary.json')
macros=dict(rtStartN='48',rtGeometryN='30',rtReferenceN='2',rtNativeN='3876',
    rtAcetate=f"{r['chemical_reference']['chemical_reference_kj']['acetate_transfer']:.2f}",
    rtThiol=f"{r['chemical_reference']['chemical_reference_kj']['thiol_transfer']:.2f}",
    rtGasUMAALPBMAE=f"{arms['gas_geometry|UMA|ALPB']['MAE_kj']:.2f}",
    rtWaterUMAALPBMAE=f"{arms['aqueous_geometry|UMA|ALPB']['MAE_kj']:.2f}",
    rtGasUMASMDMAE=f"{arms['gas_geometry|UMA|SMD']['MAE_kj']:.2f}",
    rtWaterUMASMDMAE=f"{arms['aqueous_geometry|UMA|SMD']['MAE_kj']:.2f}")
electronic=max(abs(arms[f'{mode}_geometry|DFT|{solvent}']['reactions'][rxn]['prediction_kj']-arms[f'{mode}_geometry|UMA|{solvent}']['reactions'][rxn]['prediction_kj'])
    for mode in ['gas','aqueous'] for solvent in ['ALPB','SMD'] for rxn in ['acetate_transfer','thiol_transfer'])
macros['rtElectronicMax']=f'{electronic:.2f}'
(destination/'reference_transfer_numbers.tex').write_text('% Raw chemical reference transfers; not biochemical-pool benchmark numbers.\n'+''.join('\\newcommand{\\'+k+'}{'+v+'}\n' for k,v in macros.items()))
lines=[]
for mode in ['gas','aqueous']:
    for e,s in [('UMA','ALPB'),('DFT','ALPB'),('UMA','SMD'),('DFT','SMD')]:
        a=arms[f'{mode}_geometry|{e}|{s}'];lines.append(('Gas' if mode=='gas' else 'Aqueous')+f" & {e}/{s} & {a['reactions']['acetate_transfer']['prediction_kj']:.2f} & {a['reactions']['thiol_transfer']['prediction_kj']:.2f} & {a['MAE_kj']:.2f}\\\\\n")
(destination/'reference_transfer_table.tex').write_text(''.join(lines))
(destination/'README.md').write_text('''# Charged-reference chemical proton-transfer controls

The chemical reactions are acetic acid + ethanolamine -> acetate +
ethanolammonium, and 2-mercaptoethanol + ethanolamine ->
2-mercaptoethanolate + ethanolammonium. Both conserve elements, charge and
molecular count. NIST-evaluated ionization constants give chemical standard
energies -27.07 and +1.44 kJ/mol at 298.15 K and zero ionic strength in water.
The common molality-to-molarity change cancels in each two-to-two exchange.
The source is Goldberg, Kishore and Lennen (2002), Tables 7.2, 7.28 and 7.43:
[DOI 10.1063/1.1416902](https://doi.org/10.1063/1.1416902).
The full primary tables were read via the web tool; direct binary retrieval
was refused. The curated constants and locators are supplied, with no claim
of local source-PDF ownership. Their uncertainty codes are subjective
assessments, not standard deviations or declared confidence intervals.

All 48 planned optimizations finished: six chemical states, four fixed ETKDG
starts and both gas and effective-water optimization. Thirty geometries remain
under the frozen full-H RMSD/energy clustering rule. Water forces use
E(UMA) + E(GFN2/ALPB) - E(GFN2/gas), dense5810-point SASA quadrature and
xTB accuracy0.001. Gas thermochemistry uses exact UMA curvature; water
thermochemistry includes independently reconstructed solvent curvature at two
finite-difference steps. All retained states pass the declared force/mode gates.
Two acetate states have soft negative modes below50cm^-1: this is an approximate
mode policy, not proof of strictly positive curvature or conformational completeness.

Eight fixed arms cross geometry, electronic level (UMA/parentDFT) and solvent
(ALPB/SMD). No pKa correction or fitted offset enters their raw predictions.
The frozen results are unfavorable: UMA/ALPB MAE is27.46kJ/mol on gas geometries
and31.21 on water geometries; the respective UMA/SMD values are39.02 and36.65.
The source compilation and related constants were previously consulted during
development, and underlying solvation-parameter exposure is not fully indexed.
This is a chemical component control, not independent metabolic validation.
Scoring the same equations as transformed metabolite pools would make them
identities; quantity_scope_audit.json proves that distinction algebraically.

Independent QR/native replay reconstructs3876 retained solvent executions.
Three additional charged CPU fixtures reproduce the GPU calculation within
0.00030kJ/mol. This rules out that tested implementation discrepancy as an
explanation of the large errors, without validating the physical models.
component_diagnosis.json records a post-outcome base-cancelling contrast; it
does not add another independent observation or change the two-reference MAEs.

Replay from the MetaG repository, using NumPy and ASE without CUDA, UMA assets,
PySCF or xTB:

```bash
python benchmark/reference_transfer.py
```

For this folder alone use `python reference_transfer.py .`. The archive retains
all initial scientific inputs, frozen code/analysis, optimization traces,
native solvent records, Hessians, SCF outputs, CPU fixtures and ownership records.
Original absolute producer paths are provenance, not portable launch commands.
The independent record-only replay does not authenticate unavailable model assets
or recompute quantum calculations. No production reference policy is adopted,
and no primary independent biochemical reference or ModelSEED prediction is added.
''')
files={path.name:sha(path) for path in destination.iterdir() if path.is_file()}
(destination/'manifest.json').write_text(json.dumps(dict(files=files,scope='Complete chemical component test with all eight arms; no independent metabolic or production-promotion claim.'),indent=2)+'\n')
spec=importlib.util.spec_from_file_location('published_reference_transfer_audit',destination/'reference_transfer.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
report=module.audit(destination)
(HERE/'publication_audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
