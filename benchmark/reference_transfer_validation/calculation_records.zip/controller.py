"""One reserved GPU, joined children, fixed global deadline and single attempts."""
from pathlib import Path
import datetime,json,os,signal,subprocess,time,traceback
from common import HERE,authenticate,read,write,owner

inputs,protocol=authenticate();manifest=read(HERE/'launch_manifest.json')
assert sorted(os.sched_getaffinity(0))==manifest['cpus'] and os.environ.get('CUDA_VISIBLE_DEVICES') is not None
write(HERE/'controller_owner.json',owner());deadline=datetime.datetime.fromisoformat(manifest['deadline_utc'])
child=None;status=dict(state='running',phase='force_fixture',completed=[],failures=[])
def remaining():return max(0,(deadline-datetime.datetime.now(datetime.timezone.utc)).total_seconds())
def terminate():
    if child is not None and child.poll() is None:
        os.killpg(child.pid,signal.SIGTERM)
        try:child.wait(timeout=15)
        except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
def stop(signum,frame):terminate();raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
def execute(name,argv,timeout):
    global child
    available=min(timeout,remaining()-30);assert available>0,'Global study budget exhausted'
    with (HERE/(name+'.console.log')).open('x') as log:
        child=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        write(HERE/(name+'.owner.json'),dict(host=os.uname().nodename,pid=child.pid,start_ticks=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19],argv=argv))
        try:code=child.wait(timeout=available)
        finally:terminate()
        assert code==0,(name,code)

try:
    execute('force_fixture',[manifest['molecular_python'],str(HERE/'force_fixture.py')],180)
    status.update(phase='molecular_optimization_and_curvature');write(HERE/'controller_status.json',status)
    execute('molecular',[manifest['molecular_python'],str(HERE/'molecular_worker.py')],protocol['stage1_budget_seconds'])
    assert read(HERE/'molecular_status.json')['state']=='complete'
    execute('SCF_preparation',[manifest['DFT_python'],str(HERE/'prepare_scf.py')],120)
    status.update(phase='parent_DFT_SMD');write(HERE/'controller_status.json',status)
    execute('smoke',[manifest['DFT_python'],str(HERE/'reference_point.py'),'smoke'],240)
    assert read(HERE/'points/smoke.json')['passed']
    consecutive=0;stage_end=time.monotonic()+protocol['stage2_budget_seconds']
    for slot in read(HERE/'scf_geometry_inputs.json')['inputs']:
        if remaining()<=30 or time.monotonic()>=stage_end:raise TimeoutError('Study budget exhausted before a new SCF attempt')
        claim=HERE/'claims'/slot;claim.mkdir();write(claim/'owner.json',owner())
        try:
            print('SCF START '+slot,flush=True)
            execute('SCF_'+slot,[manifest['DFT_python'],str(HERE/'reference_point.py'),slot],min(1800,stage_end-time.monotonic()))
            assert read(HERE/'points'/(slot+'.json'))['passed'];status['completed'].append(slot);consecutive=0
            print('SCF COMPLETE '+slot,flush=True)
        except Exception as error:
            status['failures'].append(dict(slot=slot,error=str(error),traceback=traceback.format_exc()));consecutive+=1
            if consecutive>=3:raise
        finally:
            import shutil
            shutil.rmtree(claim);write(HERE/'controller_status.json',status)
    assert not status['failures'],'Complete panel withheld after failed point(s)'
    status.update(state='calculations_complete',phase='analysis');write(HERE/'controller_status.json',status)
    execute('analysis',[manifest['molecular_python'],str(HERE/'analyze.py')],120)
    status.update(state='complete',phase='finished')
except BaseException as error:
    status.update(state='stopped',error=str(error),traceback=traceback.format_exc());raise
finally:terminate();write(HERE/'controller_status.json',status)
