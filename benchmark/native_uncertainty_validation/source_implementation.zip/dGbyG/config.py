# This python file saves all the paths to the data and models used in the project.

import os

# Automatic detection of the package path.
package_path = os.path.split(os.path.abspath(__file__))[0]

# Directory path for/of saving network parameters files.
#inference_model_state_dict_dir = os.path.join(package_path, 'network', 'best_model_params')
inference_model_state_dict_dir = os.path.join(package_path, 'network', 'model_params', 'MPNN_model_params')

# Training data file path. 
train_data_path = os.path.join(package_path, 'data', 'TrainingData.csv')

# Compound databases path.
kegg_database_path = os.path.join(package_path, 'data', 'KEGG')
#kegg_additions_csv_path = os.path.join(package_path, 'data', 'KEGG', 'mol', 'kegg_additions.csv')
metanetx_database_path = os.path.join(package_path, 'data', 'MetaNetX', 'chem_prop.tsv')
hmdb_database_path = os.path.join(package_path, 'data', 'HMDB', 'structures.csv')
chebi_database_path = os.path.join(package_path, 'data', 'libChEBI')
lipidmaps_database_path = os.path.join(package_path, 'data', 'LIPID_MAPS', 'lipidmaps_ids_cc0.tsv')
recon3d_mol_dir_path = os.path.join(package_path, 'data', 'Recon3D', 'mol')

# pKa data file path.
chemaxon_pka_json_path = os.path.join(package_path, 'data', 'chemaxon_pKa.json')

# Directory path of Jar files of Chemaxon software path.
chemaxon_jar_dir = "/opt/chemaxon/jchemsuite/lib"
# License file path of Chemaxon software.
chemaxon_license_file_path = "/home/fanwc/.chemaxon/license.cxl"