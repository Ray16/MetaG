"""Resource-only repair after proving initial workers terminal and no inputs claimed."""
from pathlib import Path
import datetime
import json
import os
import shutil
import subprocess
import time

from common import HERE,GATE,PYTHON,environment,read,write,sha,check_freeze

assert os.uname().nodename=='lambda13'
freeze=check_freeze();old=read(HERE/'launch_manifest.json')
assert not (HERE/'resource_amendment.json').exists()
assert not list((HERE/'claims').iterdir()) and not list((HERE/'results').iterdir())
proof=[]
for path in (HERE/'workers').glob('*.json'):
    record=read(path);record=record.get('owner',record)
    if not isinstance(record,dict) or 'pid' not in record:continue
    proc=Path('/proc')/str(record['pid'])/'stat'
    if proc.exists():
        fields=proc.read_text().rsplit(')',1)[1].split()
        assert fields[0]=='Z' or fields[19]!=record['start_ticks'],('Original owner still live',record)
    proof.append(dict(pid=record['pid'],record=path.name,original_owner_terminal=True))
for w in ['worker0','worker1']:assert read(HERE/'workers'/(w+'.status.json'))['state']=='startup_failed_no_input_claimed'
env=environment();env['FAIRCHEM_CACHE_DIR']='/nfs/lambda_stor_01/homes/rzhu/.cache/fairchem'
code='''import json,pathlib,hashlib
from fairchem.core import pretrained_mlip
from metag.energetics.provenance import content_hash
r=pretrained_mlip.resolve_checkpoint('uma-s-1p2p1')
p=pathlib.Path(r.path)
h=hashlib.sha256()
with p.open('rb') as f:
 for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
refs=content_hash(dict(atom_refs=r.atom_refs,form_elem_refs=r.form_elem_refs))
print(json.dumps(dict(checkpoint_path=str(p),checkpoint_sha256=h.hexdigest(),references_sha256=refs)))
'''
check=subprocess.run(['/usr/bin/taskset','-c','372,373',PYTHON,'-c',code],env=env,
    capture_output=True,text=True,timeout=180)
assert check.returncode==0,(check.stdout,check.stderr)
asset=json.loads(check.stdout.strip().splitlines()[-1])
assert asset['checkpoint_sha256']==freeze['physical_model_identity']['checkpoint_sha256']
assert asset['references_sha256']==freeze['physical_model_identity']['references_sha256']
assert max(os.getloadavg())+4<=os.cpu_count()
resident=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True)
for a in old['allocations']:assert a['gpu_uuid'] not in resident
assert time.time()<datetime.datetime.fromisoformat(old['deadline_utc']).timestamp()-3600
shutil.copyfile(HERE/'launch_manifest.json',HERE/'launch_manifest.initial.json')
new=dict(old);new['allocations']=old['allocations']+[
    dict(old['allocations'][0],worker='worker0r1'),dict(old['allocations'][1],worker='worker1r1')]
new['resource_environment']={'FAIRCHEM_CACHE_DIR':env['FAIRCHEM_CACHE_DIR']}
new['original_launch_manifest_sha256']=sha(HERE/'launch_manifest.initial.json')
write(HERE/'resource_amendment.json',dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    reason='Initial registered-model cache was node-local and unavailable; all initial workers terminal before any input claim.',
    original_owner_proof=proof,initial_inputs_attempted=0,asset_preflight=asset,
    changed_environment=new['resource_environment'],scientific_freeze_unchanged=True,
    checkpoint_and_references_unchanged=True,common_deadline_unchanged=old['deadline_utc'],maximum_GPU_hours=8))
write(HERE/'launch_manifest.json',new)
for i,a in enumerate(new['allocations'][2:]):
    if i:time.sleep(15)
    argv=[GATE,'run',str(a['gpu_index']),'--label','metag_boundary_physics',
        '--','/usr/bin/taskset','-c',','.join(map(str,a['cpus'])),'/usr/bin/python3',str(HERE/'worker.py'),a['worker']]
    with (HERE/'logs'/(a['worker']+'.launcher.log')).open('x') as log:
        process=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=log,
            stderr=subprocess.STDOUT,start_new_session=True)
    try:start=Path(f'/proc/{process.pid}/stat').read_text().rsplit(')',1)[1].split()[19]
    except OSError:start=None
    write(HERE/'workers'/(a['worker']+'.launcher.json'),dict(pid=process.pid,host=os.uname().nodename,
        start_ticks=start,argv=argv,allocation=a))
    print('LAUNCHED',a['worker'],process.pid,flush=True)
