"""Path adapter for the unchanged parent-DFT numerical implementation."""
from common import HERE,owner,read,sha,write
from common import authenticate as initial_authenticate

def authenticate():
    initial_authenticate()
    receipt=read(HERE/'scf_preparation_receipt.json')
    assert receipt['inputs_sha256']==sha(HERE/'scf_geometry_inputs.json')
    for name,digest in receipt['source_result_sha256'].items():assert sha(HERE/name)==digest,name
    return read(HERE/'scf_geometry_inputs.json'),read(HERE/'parent_protocol.json')
