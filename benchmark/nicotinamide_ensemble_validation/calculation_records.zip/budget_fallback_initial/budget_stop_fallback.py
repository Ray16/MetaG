"""Independent process-only stop fallback; never depends on a CUDA query."""
from pathlib import Path
import datetime
import json
import os
import signal
import time
from control_common import HERE,owner,write

assert os.uname().nodename=='lambda13' and sorted(os.sched_getaffinity(0))==[36]
plan=json.loads((HERE/'parallel_execution_amendment.json').read_text())
deadline=datetime.datetime.fromisoformat(plan['common_budget_stop_utc'])
keys=set(json.loads((HERE/'launch_manifest.json').read_text())['workers'])
write(HERE/'budget_stop_fallback_owner.json',owner())

def processes():
    workers=[];points=[]
    for path in Path('/proc').glob('[0-9]*'):
        try:
            if path.stat().st_uid!=os.getuid():continue
            argv=(path/'cmdline').read_bytes().decode().split('\0')
            tick=(path/'stat').read_text().rsplit(')',1)[1].split()[19]
            row=dict(pid=int(path.name),start_ticks=tick)
            if str(HERE/'worker.py') in argv and any(key in argv for key in keys):workers.append(row)
            if str(HERE/'reference_point.py') in argv:points.append(row)
        except (OSError,UnicodeError,ValueError):continue
    return workers,points

def send(row,signum,group=False):
    path=Path('/proc')/str(row['pid'])
    try:
        if (path/'stat').read_text().rsplit(')',1)[1].split()[19]!=row['start_ticks']:return
        if group:os.killpg(row['pid'],signum)
        else:os.kill(row['pid'],signum)
    except ProcessLookupError:pass

while datetime.datetime.now(datetime.timezone.utc)<deadline:
    workers,points=processes()
    known=all((HERE/'workers'/key/'owner.json').exists() or (HERE/'workers'/(key+'.launcher_owner.json')).exists() for key in keys)
    if known and not workers and not points:
        write(HERE/'budget_stop_fallback_status.json',dict(state='all_producers_terminal_before_deadline'));raise SystemExit(0)
    time.sleep(min(10,max(.01,(deadline-datetime.datetime.now(datetime.timezone.utc)).total_seconds())))
workers,points=processes()
write(HERE/'budget_stop_fallback_status.json',dict(state='budget_stop_requested',workers=workers,points=points))
for row in workers:send(row,signal.SIGTERM)
time.sleep(20)
workers,points=processes()
for row in points:send(row,signal.SIGTERM,group=True)
time.sleep(10)
workers,points=processes()
for row in points:send(row,signal.SIGKILL,group=True)
for row in workers:send(row,signal.SIGKILL)
time.sleep(2)
workers,points=processes()
write(HERE/'budget_stop_fallback_status.json',dict(state='budget_stop_finished',remaining_owned_workers=workers,remaining_owned_points=points))
