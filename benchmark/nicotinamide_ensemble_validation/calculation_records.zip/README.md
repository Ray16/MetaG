# Complete retained nicotinamide ensemble control

This study extends the earlier nine-geometry parent-DFT control to all 103
retained geometries: 41 oxidized and 55 reduced full-cofactor minima, plus
three oxidized and four reduced small-core minima. These are the original fully
protonated reference states (oxidized charge +1, reduced charge 0), not an
experimentally equilibrated biochemical protonation ensemble.

Nine exactly matching earlier gas/SMD pairs are reused with their original
producer identities. The remaining 94 pairs are required. Two additional large
reproduction pairs and two water numerical fixtures test the H100 implementation;
they do not add chemical coverage. No missing or failed conformer may be omitted
from a claimed complete-pool endpoint.

`fixed_geometry_protocol.json`, `study_manifest.json`, and `analysis_freeze.json`
record the frozen comparison and producer inputs. All four source records are
copied without changing their bytes into `raw_records/`. The SCF point script
retains the earlier numerical implementation; its only adaptation chooses a
worker-specific output directory. Preparation checks its exact inverse transform.

The primary endpoint is the full-pool minus restricted-pool DFT/SMD balanced
exchange:

    full_oxidized + core_reduced -> full_reduced + core_oxidized

Four electronic/solvent arms, all conformer weights, and electronic, solvent,
original RRHO, and configurational contributions are retained. A 5 kJ/mol
sensitivity threshold describes a modeling change, not experimental accuracy.
The independent decimal log-partition calculation checks the assembled arithmetic.

UMA electronic energies were replayed on all 103 stored geometries under their
original model producer. The DFT queue uses atomic reservations, disjoint CPU
sets and native thread caps of one. The original two-H100/five-hour plan is
preserved in `launch_manifest_original.json`. Measured full-cofactor reproduction
times showed its ten-GPU-hour ceiling could not complete the frozen input set.
The resource-only `execution_amendment.json` adds two H100 workers and raises the
ceiling to 30 GPU-hours. The later `parallel_execution_amendment.json` adds three
more available H100 workers, with seven workers at most and a common budget stop
of 2026-11-05 06:27:07.732168 UTC. Its conservative occupancy bound is 29.75
GPU-hours, leaving 0.25 GPU-hours for shutdown. Original workers retain any earlier
deadlines. Two independently identified budget supervisors enforce the common
stop; their owners and process evidence are recorded separately. The scientific
protocol, point implementation, numerical gates and analysis remain unchanged.
Each new geometry gets one scientific attempt, partial files are preserved, and
three consecutive failures stop a worker. No automatic stale-claim recovery runs.

Read current output QC and fresh process ownership using:

    python status.py

Compute final results only when every required pair is available:

    python analyze.py

The analysis intentionally refuses a partial pool. `current_status.json` and the
worker logs distinguish live calculations, completed output, failed attempts and
verified pairs. Existing local files or a launch return code do not prove progress.

This is a fixed-geometry component/ensemble intervention. It does not establish
experimental Gibbs-energy accuracy, aqueous conformational completeness, electronic
ground-state stability, pH/ionic-strength/Mg handling, unfamiliar-chemistry
performance, or a validated replacement for the production reference policy.
No experimental reaction targets enter the calculation or arm selection.
