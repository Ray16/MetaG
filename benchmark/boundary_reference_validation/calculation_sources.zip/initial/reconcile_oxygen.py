"""Verify an existing triplet record after the wrapper omitted its spin cache key."""
from pathlib import Path
import copy
import math
from common import HERE,read,write,sha,check_freeze

check_freeze()
slot='molecule_71cc5ddaede2ebe8'
original=HERE/'results'/(slot+'.json');result=read(original)
assert result['status']=='execution_failure' and result['error'].startswith('FileNotFoundError')
files=list((HERE/'cache'/slot).glob('*.json'));assert len(files)==1
path=files[0];raw=read(path);task=result['request']
assert (raw['smi'],raw['q'],raw['method'])==('O=O',0,'implicit')
assert task['spin']==raw['settings']['spin']==3
assert raw['settings']['producer']==result['producer']
assert raw['G']==result['energy_kj'] and raw['sigma']==result['sampling_sigma_kj']
assert raw['settings']['thermal_validation_max']==96
ensemble=raw['meta']['thermal']['ensemble'];minima=ensemble['validated_minima']
assert len(minima)==1 and ensemble['n_reference_thermal_approximation']==0
point=minima[0];assert point['geometry']['charge']==0 and point['geometry']['spin_multiplicity']==3
assert sorted(point['geometry']['symbols'])==['O','O']
rebuilt=point['electronic_kj']+point['solvation_kj']+point['thermal_kj']
assert abs(rebuilt-raw['G'])<1e-7
write(HERE/'cache_reconciliations.json',{slot:dict(status='verified_existing_record',
    original_task_result_sha256=sha(original),original_wrapper_status=result['status'],
    cache_path=str(path),cache_sha256=sha(path),n_validated_minima=1,
    explanation='The calculator correctly keyed a triplet record with spin=3; the post-calculation wrapper reconstructed a singlet-style key. Raw provenance, returned energy/sigma, spin and full thermal partition verified. No new quantum calculation and no original outcome overwritten.',
    physical_calculation_repeated=False,energy_kj=raw['G'],sampling_sigma_kj=raw['sigma'],
    partition_reconstruction_error_kj=rebuilt-raw['G'])})
print('Verified existing triplet oxygen record; preserved original wrapper failure')
