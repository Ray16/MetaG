"""Preflight and reserve one free V100 for the two fixed missing parents."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import os
import shutil
import subprocess

HERE=Path(__file__).resolve().parent
OUT=HERE/'quantum_extension'
assert not(OUT/'launch_manifest.json').exists(),'Inspect existing ownership before resubmission'
protocol=json.loads((OUT/'protocol.json').read_text());cpus=protocol['resources']['cpus']
python='/nfs/lambda_stor_01/homes/rzhu/.cache/metag-environments/uma-nitro-20261023-645af7d/venv/bin/python'
gate='/nfs/lambda_stor_01/homes/rzhu/bin/gpu_reserve'
sdk=HERE.parents[1]/'analysis/nicotinamide_reference_control_20261104_01/fairchem_sdk/src'
assert sdk.is_dir()
environment=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',
    PYTHONPATH=os.pathsep.join([str(HERE/'assembly_source'),str(sdk)]),
    LD_LIBRARY_PATH='/nfs/lambda_stor_01/homes/rzhu/miniforge3/envs/redox/lib:/nfs/lambda_stor_01/homes/rzhu/miniforge3/envs/xtb/lib',
    XTB_BIN='/nfs/lambda_stor_01/homes/rzhu/miniforge3/envs/xtb/bin/xtb',
    OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',
    METAG_XTB_WORKERS='2',UMA_RUNTIME_PROFILE='nitro',UMA_ENERGY_CHUNK='64',UMA_FIRE_CHUNK='64',
    UMA_HESS_ROWS='8',METAG_CACHE=str(OUT/'cache'))
cpu_text=','.join(map(str,cpus))
args=['/homes/rzhu/miniforge3/envs/uma/bin/python',
    '/nfs/lambda_stor_01/homes/rzhu/.codex-personal/skills/lambda-fleet/scripts/preflight_node.py',
    'local','--python',python,'--cpu-set',cpu_text,'--min-available-ram-mib','16384',
    '--module','rdkit','--module','torch','--module','ase','--module','fairchem.core',
    '--module','metag.energetics.backend','--bin',gate,'--bin',environment['XTB_BIN'],
    '--library-path',environment['LD_LIBRARY_PATH']]
r=subprocess.run(args,env=environment,capture_output=True,text=True,timeout=60)
(OUT/'dependency_preflight.json').write_text(r.stdout)
r.check_returncode()
print(r.stdout[:1000],flush=True)
probe=subprocess.check_output(['/usr/bin/taskset','-c',cpu_text,python,'-c',
    'import fairchem.core,metag,json;print(json.dumps({"fairchem":fairchem.core.__file__,"metag":metag.__file__}))'],
    env=environment,text=True)
(OUT/'module_paths.json').write_text(probe)
assert str(sdk) in probe and str(HERE/'assembly_source') in probe and 'backup/' not in probe
for name in ['compute_parents.py','control_parents.py']:ast.parse((HERE/name).read_text())
assert max(os.getloadavg())+len(cpus)<=os.cpu_count()
assert shutil.disk_usage('/tmp').free>5*1024**3
uuid=next(x.split(',')[1].strip() for x in subprocess.check_output([
    '/usr/bin/nvidia-smi','--query-gpu=index,uuid','--format=csv,noheader'],text=True).splitlines()
    if x.split(',')[0].strip()=='7')
resident=subprocess.check_output(['/usr/bin/nvidia-smi','--query-compute-apps=gpu_uuid,pid',
    '--format=csv,noheader'],text=True)
assert uuid not in resident,'GPU contention; no molecular attempt consumed'
assert not any((OUT/'cache').iterdir())
now=datetime.datetime.now(datetime.timezone.utc)
argv=['/usr/bin/taskset','-c',cpu_text,gate,'run','7','--label','metag_source_amino_parents','--',
    '/homes/rzhu/miniforge3/envs/uma/bin/python',str(HERE/'control_parents.py')]
names=['compute_parents.py','control_parents.py','launch_parents.py','protocol.json','catalog.json',
    'raw_settings.json','quantum_extension/protocol.json','quantum_extension/dependency_preflight.json',
    'quantum_extension/module_paths.json']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=dict(utc=now.isoformat(),deadline_utc=(now+datetime.timedelta(seconds=3300)).isoformat(),
    host=os.uname().nodename,cpus=cpus,gpu_index=7,gpu_uuid=uuid,python=python,argv=argv,
    files_sha256={name:sha(HERE/name) for name in names},
    sdk_files_sha256={str(p.relative_to(sdk)):sha(p) for p in (sdk/'fairchem/core').rglob('*.py')},
    environment={k:environment[k] for k in ['PYTHONPATH','LD_LIBRARY_PATH','HF_HUB_OFFLINE','XTB_BIN',
        'OMP_NUM_THREADS','OMP_THREAD_LIMIT','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS',
        'METAG_XTB_WORKERS','UMA_RUNTIME_PROFILE','UMA_ENERGY_CHUNK','UMA_FIRE_CHUNK','UMA_HESS_ROWS','METAG_CACHE']},
    expected_slots=['alanine_S_parent','aspartate_R_parent'])
(OUT/'launch_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with (OUT/'launcher.log').open('x') as log:
    worker=subprocess.Popen(argv,env=environment,stdin=subprocess.DEVNULL,stdout=log,
        stderr=subprocess.STDOUT,start_new_session=True)
owner=dict(pid=worker.pid,host=os.uname().nodename,
    start_ticks=Path(f'/proc/{worker.pid}/stat').read_text().rsplit(')',1)[1].split()[19])
(OUT/'launcher_owner.json').write_text(json.dumps(owner,indent=2)+'\n')
print('LAUNCHED',json.dumps(owner),flush=True)
