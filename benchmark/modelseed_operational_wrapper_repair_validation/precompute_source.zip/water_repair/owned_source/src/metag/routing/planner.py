"""Reaction route planning without model loading or species-energy evaluation.

This layer depends only on molecular structure and protonation rules; it never
imports the QM backend or uses observed reaction energies.

Stages, in order (each balance-guarded): cofactor ring cores -> nucleotide cores
-> full-vs-truncate gate -> spectator truncation -> pH-0 neutral reference
-> zwitterion guard.
"""
from metag.chem import is_balanced, reaction_residual, fmt_num
from metag.reactions import validate_reaction

# Spectator-truncation radius (bonds kept around the reaction centre). Anomeric sugar reactions use
# radius 3: radius 2 can amputate electrostatically coupled ribose substituents.
TRUNCATION_RADIUS = 2


BASE_REFERENCES = ("gated", "global")


def route_reaction(reaction, allow_truncate=True, log=print, force_neutral=False, base_reference="gated"):
    """Structural routing -- pure logic, no QM: cofactor ring cores -> NTP cores -> full-vs-truncate
    gate -> spectator truncation -> pH-0 transform -> zwitterion invariant.

    Returns (rx, routes, truncated): `rx` is the rewritten reaction score_reaction scores (the input dict
    is never mutated), `routes` records which transforms fired plus any errors/warnings.

    DIRECTION INVARIANCE: several stages are heuristics whose outcome can depend on which side is written
    first (MCS pairing and atom maps, the reaction-centre ring gate). The reaction is therefore always
    routed in a canonical orientation (the side with the lexicographically smaller sorted canonical-SMILES
    key is the reactant side) and mapped back, so the reverse reaction routes to exactly the mirror image
    and ΔG(reverse) = -ΔG(forward).

    BALANCE GUARD: every rewrite must keep the reaction element- and charge-balanced with its proton
    count in n_H+ -- the one invariant all of them share. A step whose output breaks a balance its input
    had is REVERTED and recorded in routes["reverted"]. Without it an element leak (e.g. a mixed disulfide
    replaced by a symmetric core, dropping the CoA half) reached QM and was caught, if at all, only by
    the |ΔG| sanity bound."""
    validate_reaction(reaction)
    if base_reference not in BASE_REFERENCES:
        raise ValueError(f"base_reference must be one of {BASE_REFERENCES}, got {base_reference!r}")
    # Canonicalize the actual matching graphs, not just the direction-comparison
    # key. First-match graph heuristics otherwise see the caller's SMILES order.
    # Keep every declared state/stereocentre and copy metadata without mutation.
    from rdkit import Chem
    species = {
        name: [c, q, Chem.MolToSmiles(Chem.MolFromSmiles(s), isomericSmiles=True)]
        for name, (c, q, s) in reaction["species"].items()}
    # DRAWING INVARIANCE for bases: protonate neutral ammonia/aliphatic amines to their dominant pH-7
    # cation before any route decision (acids are already canonicalized to max-anion inside the pH-0
    # build). The proton count moves into n_H+ so the reaction stays element- and charge-balanced.
    # Caller-supplied pka_sites declare their own protonation states and are left as drawn.
    amine_canonicalized = []
    if not reaction.get("pka_sites"):
        from metag.routing.pka_transform import canonicalize_basic_amines
        n_hplus = reaction.get("n_Hplus", 0)
        for name, (c, q, s) in species.items():
            canon, added = canonicalize_basic_amines(s)
            if added:
                species[name] = [c, q + added, canon]
                n_hplus -= c * added
                amine_canonicalized.append(name)
        if amine_canonicalized:
            reaction = dict(reaction, n_Hplus=n_hplus)
    reaction = dict(reaction, species=dict(sorted(
        species.items(), key=lambda item: (item[1][2], item[1][0], item[1][1], item[0]))))
    if not _reverse_is_canonical(reaction["species"]):
        rx, routes, truncated = _route_oriented(reaction, allow_truncate, log, force_neutral, base_reference)
        routes["routed_orientation"] = "as_written"
        routes["amine_canonicalized"] = amine_canonicalized
        return rx, routes, truncated
    rx, routes, truncated = _route_oriented(_reversed(reaction), allow_truncate, log, force_neutral, base_reference)
    rx = _reversed(rx)
    if routes.get("protonation_sites_by_species"):
        routes["protonation_sites_by_species"] = {
            name: [[_OTHER_SIDE[site[0]], *site[1:]] for site in sites]
            for name, sites in routes["protonation_sites_by_species"].items()}
    routes["routed_orientation"] = "reversed_to_canonical_and_back"
    routes["amine_canonicalized"] = amine_canonicalized
    return rx, routes, truncated


_OTHER_SIDE = {"react": "prod", "prod": "react"}


def _side_key(species, sign):
    from rdkit import Chem
    return sorted((Chem.MolToSmiles(Chem.MolFromSmiles(smi)), abs(coeff), q)
                  for coeff, q, smi in species.values() if sign * coeff > 0)


def _reverse_is_canonical(species):
    """True when the reverse of the written reaction is the canonical orientation."""
    try:
        return _side_key(species, +1) < _side_key(species, -1)
    except Exception:
        return False                                      # unparsable input: keep as written; validation reports it


def _reversed(reaction):
    """The same reaction written in the opposite direction (coefficients, n_H+ and pKa-site sides)."""
    out = dict(reaction, species={n: [-c, q, s] for n, (c, q, s) in reaction["species"].items()},
               n_Hplus=-reaction.get("n_Hplus", 0))
    if reaction.get("pka_sites"):
        out["pka_sites"] = [[_OTHER_SIDE[site[0]], *site[1:]] for site in reaction["pka_sites"]]
    return out


def _route_oriented(reaction, allow_truncate, log, force_neutral, base_reference="gated"):
    from metag.routing.sugar_states import prepare_declared_sugar_inputs
    prepared, sugar_declarations = prepare_declared_sugar_inputs(reaction)
    rx = dict(prepared)
    rx.setdefault("note", "")
    rx.setdefault("n_Hplus", 0)
    # Routing describes a chemical event, independent of how many times the
    # equation is written. Several core builders require unit coefficients.
    # Normalize for planning, then restore the caller's extent before assembly.
    from metag.reactions import unit_stoichiometry
    _unit_species, _route_extent = unit_stoichiometry(rx["species"])
    if _route_extent != 1.0:
        rx = dict(rx, species=_unit_species, n_Hplus=rx["n_Hplus"] / _route_extent)
        if rx.get("pka_sites"):
            rx["pka_sites"] = [list(site[:2]) + [site[2] if len(site) > 2 else "acid",
                                (site[3] if len(site) > 3 else 1.0) / _route_extent]
                               for site in rx["pka_sites"]]
    routes = {"cofactor_ring": False, "ntp_core": False, "prefer_full": False,
              "truncated": False, "trunc_radius": None, "ph0": False, "zwitterion_ph0": False,
              "errors": [], "warnings": [], "reverted": [], "input_balanced": True}
    routes["stereo_preservation_policy"] = "2026-10-18-source-centres-and-defined-fragments"
    routes["base_reference"] = base_reference
    if sugar_declarations:
        routes['declared_sugar_pools'] = sugar_declarations
        routes['generic_truncation_disabled_for_declared_sugar_pools'] = True
    if not is_balanced(rx["species"], rx["n_Hplus"]):
        res, dq = reaction_residual(rx["species"], rx["n_Hplus"])
        routes["input_balanced"] = False
        routes["warnings"].append(f"input reaction not element/charge balanced (residual {res}, charge "
                                  f"{fmt_num(dq) if dq is not None else '?'}): ΔG is not meaningful")
        log(f"  !! {routes['warnings'][-1]}")
    rx = _route_cores(rx, routes, log)
    rx = _route_truncation(rx, routes, allow_truncate and not sugar_declarations, log)
    truncated = routes["truncated"]
    rx = _route_ph0(rx, routes, log, base_reference)
    rx = _route_neutral_reference(rx, routes, force_neutral, log)
    if _route_extent != 1.0:
        rx = dict(rx, species={n: [c * _route_extent, q, s] for n, (c, q, s) in rx["species"].items()},
                  n_Hplus=rx["n_Hplus"] * _route_extent)
        if rx.get("pka_sites"):
            rx["pka_sites"] = [list(site[:2]) + [site[2] if len(site) > 2 else "acid",
                                (site[3] if len(site) > 3 else 1.0) * _route_extent]
                               for site in rx["pka_sites"]]
        if routes.get('protonation_sites_by_species'):
            routes['protonation_sites_by_species'] = {
                name: [list(site[:3]) + [site[3] * _route_extent] for site in sites]
                for name, sites in routes['protonation_sites_by_species'].items()}
    return rx, routes, truncated


def _balance_guard(step, before, after, routes, log, reset=None):
    """Keep `after` if it is balanced (or if `before` already was not); otherwise revert to `before`,
    record the error, and reset the step's route flags."""
    if after is before or not is_balanced(before["species"], before["n_Hplus"]):
        return after
    if is_balanced(after["species"], after["n_Hplus"]):
        return after
    res, dq = reaction_residual(after["species"], after["n_Hplus"])
    msg = (f"{step}: rewritten reaction not balanced (residual {res}, charge "
           f"{fmt_num(dq) if dq is not None else '?'}) -> step reverted")
    routes["reverted"].append(msg)                        # designed "not applicable" outcome, not an error
    log(f"  !! {msg}")
    for k, v in (reset or {}).items():
        routes[k] = v
    return before



def _route_cores(rx, routes, log):
    """Apply structural cofactor and nucleotide cores, checking balance after each."""
    _pre = rx
    try:
        from metag.routing.cofactor_cores import cofactor_ring
        new = cofactor_ring(rx["species"])
        if new is not rx["species"]:
            # Coring changes species CHARGES; n_H+ must move by the negative of the charge change
            # to keep charge closure (Σcoeff·q + n_H+ = 0). This is a NO-OP for symmetric
            # NAD(P)+/NADH swaps (the +2/-2 shifts cancel) but CORRECTS asymmetric double-redox
            # (2 GSH : 1 GSSG) where the old "n_H+ preserved" left a -2 imbalance -> ~+2340 kJ
            # proton leak (glutathione reductase rxn00070/00086 -> +2363; fixed -> ~+22, exp ~+15).
            dq = (sum(c * q for (c, q, s) in new.values())
                  - sum(c * q for (c, q, s) in rx["species"].values()))
            rx = dict(rx, species=new, n_Hplus=rx["n_Hplus"] - dq,
                      note=rx.get("note", "") + " [RINGCOFACTOR]")
            routes["cofactor_ring"] = True
            log(f"  [cofactor-ring: NAD(P) -> nicotinamide ring model"
                + (f"; n_H+ {fmt_num(rx['n_Hplus']+dq)}->{fmt_num(rx['n_Hplus'])} (charge closure)]" if dq else "]"))
    except Exception as e:
        log(f"  [cofactor-ring error: {e}; unchanged]"); routes["errors"].append(f"cofactor_ring: {e}")
    rx = _balance_guard("cofactor_ring", _pre, rx, routes, log, reset={"cofactor_ring": False})
    # Cap a conserved nucleoside while retaining the reacting polyphosphate.
    _pre = rx
    try:
        from metag.routing.ntp_core import ntp_core
        new = ntp_core(rx["species"])
        if new is not rx["species"]:
            rx = dict(rx, species=new, note=rx.get("note", "") + " [NTP-CORE]"); routes["ntp_core"] = True
            log("  [ntp-core: nucleoside-5'-phosphate -> methyl polyphosphate (adenosine capped)]")
    except Exception as e:
        log(f"  [ntp-core error: {e}; unchanged]"); routes["errors"].append(f"ntp_core: {e}")
    rx = _balance_guard("ntp_core", _pre, rx, routes, log, reset={"ntp_core": False})
    return rx


def _route_truncation(rx, routes, allow_truncate, log):
    """Choose full molecules or a balanced reactive core."""
    _prefer_full = False
    if allow_truncate:
        try:
            from metag.routing.truncation_gate import prefer_full
            _prefer_full = prefer_full(rx["species"])
        except Exception as e:
            from metag.routing.truncate import MCSBudgetExceeded
            if isinstance(e, MCSBudgetExceeded):        # no atom map: score the full molecules
                _prefer_full = True; routes["warnings"].append(f"prefer_full: {e}; full molecules")
            else:
                _prefer_full = False; routes["errors"].append(f"prefer_full: {e}")
        routes["prefer_full"] = bool(_prefer_full)
        if _prefer_full:
            log("  [route: prefer FULL molecule (compact ring, charge-conserved, no floppy linker) -> skip truncation]")
    _pre = rx
    if allow_truncate and not _prefer_full:
        try:
            from metag.routing.truncate import build_truncated_reaction, truncation_radius
            _rad = TRUNCATION_RADIUS
            _adaptive_rad = truncation_radius(rx["species"], default=_rad)
            if _adaptive_rad != _rad:
                _rad = _adaptive_rad
                routes["trunc_radius_reason"] = "anomeric_ring_reaction_center"
                log("  [truncation radius 3: preserve the complete reacting sugar environment]")
            tr = build_truncated_reaction(rx["species"], radius=_rad)
            # VALIDITY GUARD (general): a truncation removes CONSERVED spectator parts and caps cut C-C
            # bonds FAR from functional groups. It must NEVER cut a bond ON a CATIONIC center: capping a
            # quaternary ammonium [N+](C)(C)(C) with H yields a PRIMARY ammonium CH2-NH3+ -- a different
            # molecule (carnitine betaine -> primary amine; silently wrong ΔG, the failed 3-dehydrocarnitine
            # core just exposed it). GENERAL symptom for ANY cation (N+, S+, guanidinium, sulfonium...):
            # a positively-charged atom in the core carries MORE H than the same atom in the full species.
            # Match the truncation's 'X_t' core name back to the original 'X'. (Root-cause fix would live in
            # truncate.py's cut-site selection; this is the safety guard + the species-failure retry below.)
            def _truncation_mangles_cation(orig, cored):
                # symptom = a positively-charged atom LOST heavy-atom coordination vs the full species
                # (quaternary N+ degree 4 -> bare [N+] degree 1 = an undervalent, chemically-invalid
                # cation). Element-agnostic (N+, S+, guanidinium C...); compares the max cation heavy-degree.
                from rdkit import Chem as _C
                def cation_deg(smi):
                    m = _C.MolFromSmiles(smi)
                    return sorted(a.GetDegree() for a in m.GetAtoms() if a.GetFormalCharge() > 0) if m else []
                for nm, (c, q, s) in cored.items():
                    onm = nm[:-2] if nm.endswith("_t") else nm
                    if onm not in orig:
                        continue
                    dc, do = cation_deg(s), cation_deg(orig[onm][2])
                    # mangled = a RETAINED cation lost coordination. A cation absent from the core (dc empty) was
                    # removed WITH the spectator -- identical on both sides, so it cancels: not a mangle (this
                    # branch used to reject ~89% of the truncations the guard blocked, e.g. SAM/SAH, carnitine)
                    if do and (not dc or max(dc) < max(do)):
                        return nm
                return None
            if tr is not None:
                bad = _truncation_mangles_cation(rx["species"], tr[0])
                if bad:
                    log(f"  [auto-truncation REJECTED: mangles a cationic center ({bad}) -> full molecules]")
                    routes["warnings"].append(f"truncation rejected: mangles a cationic center ({bad})")
                    tr = None
            if tr is not None:
                from metag.validation.stereochemistry import unresolved_species
                if not unresolved_species(rx['species']):
                    introduced = unresolved_species(tr[0])
                    if introduced:
                        routes['stereochemistry_truncation_rejected'] = introduced
                        routes['warnings'].append('truncation rejected: introduces unresolved stereochemical identity')
                        log('  [auto-truncation REJECTED: undefined core stereochemistry -> retain pre-truncation molecules]')
                        tr = None
            if tr is not None:
                rx = dict(rx, species=tr[0], n_Hplus=tr[1],
                          note=rx.get("note", "") + " [AUTO-TRUNCATED]")
                truncated = True
                routes.update(truncated=True, trunc_radius=_rad)
                log(f"  [auto-truncated -> {len(tr[0])} core species, n_H+={tr[1]}]")
            else:
                log(f"  [auto-truncation fallback: full molecules]")
        except Exception as e:
            from metag.routing.truncate import MCSBudgetExceeded
            log(f"  [auto-truncation error: {e}; full molecules]")
            if isinstance(e, MCSBudgetExceeded):        # truncation not applicable, not an invalid result
                routes["warnings"].append(f"truncation: {e}; full molecules")
            else:
                routes["errors"].append(f"truncation: {e}")
    rx = _balance_guard("truncation", _pre, rx, routes, log, reset={"truncated": False, "trunc_radius": None})
    truncated = routes["truncated"]
    return rx


def _route_ph0(rx, routes, log, base_reference="gated"):
    """Build neutral reference species and their protonation terms after core selection.

    base_reference='gated': basic amines are neutralized only when the reaction-class gate
    (pka_transform._base_gate) fires, so one species can take different reference states in
    different reactions. 'global': every eligible base is neutralized in every reaction, so each
    species has a single reference state and shared species cancel around closed cycles."""
    _pre = rx
    if not rx.get("pka_sites"):
        try:
            from metag.routing.pka_transform import build_ph0_reaction
            # UNIFIED build: anions ALWAYS neutralized; basic amines additionally when the
            # internal base gate passes -> covers the net-proton
            # deamination/transaminase/lyase class the old anion-only path refused.
            why = []
            owned = {}
            out = build_ph0_reaction(rx["species"], rx["n_Hplus"],
                                     base=True, force_base=(base_reference == "global"),
                                     why=why, site_ownership=owned)
            if out is not None:
                ns, pks, nh = out
                rx = dict(rx, species=ns, n_Hplus=nh, pka_sites=pks,
                          note=rx.get("note", "") + " [pH0]")
                routes["ph0"] = True
                routes['protonation_sites_by_species'] = owned
                log(f"  [pH0 -> {len(pks)} pKa sites, n_H+={fmt_num(nh)}]")
            else:
                reason = why[0] if why else "no ionizable site"
                routes["ph0_skipped"] = reason
                log(f"  [pH0: {reason} -> unchanged]")
        except Exception as e:
            log(f"  [pH0-auto error: {e}; unchanged]"); routes["errors"].append(f"ph0: {e}")
    rx = _balance_guard("ph0", _pre, rx, routes, log, reset={"ph0": False})
    if rx is _pre and not routes['ph0']:
        routes.pop('protonation_sites_by_species', None)
    return rx


def _route_neutral_reference(rx, routes, force_neutral, log):
    """Route remaining zwitterions (or, with force_neutral, every ionized species) to the neutral reference."""
    _neutral_all = force_neutral     # force_neutral: re-route after a rearranged species
    _pre = rx
    previous_ownership = routes.get('protonation_sites_by_species')
    previous_ph0 = routes['ph0']
    try:
        from metag.routing.pka_transform import build_ph0_reaction, has_zwitterion, has_ionized
        _needs = (lambda sp: has_ionized(sp)) if _neutral_all else (lambda sp: has_zwitterion(sp))
        if _needs(rx["species"]) and rx.get("pka_sites"):
            routes["warnings"].append("charged species reaches QM (user-supplied pka_sites; not re-routed)")
        elif _needs(rx["species"]):
            owned = {}
            out = build_ph0_reaction(rx["species"], rx["n_Hplus"], base=True, force_base=True,
                                     site_ownership=owned)
            if out is not None and not _needs(out[0]):
                ns, pks, nh = out
                rx = dict(rx, species=ns, n_Hplus=nh, pka_sites=pks,
                          note=rx.get("note", "") + " [pH0-zwitterion]")
                routes["ph0"] = True; routes["zwitterion_ph0"] = True
                routes['protonation_sites_by_species'] = owned
                log(f"  [zwitterion invariant -> neutral-microspecies path, {len(pks)} pKa sites, n_H+={fmt_num(nh)}]")
            else:
                routes["warnings"].append("zwitterion reaches QM (neutral-microspecies build refused)")
                log("  !! zwitterion reaches QM: neutral-microspecies build refused")
    except Exception as e:
        routes["errors"].append(f"zwitterion_ph0: {e}")
    rx = _balance_guard("zwitterion_ph0", _pre, rx, routes, log, reset={"zwitterion_ph0": False})
    if rx is _pre and routes.get('protonation_sites_by_species') is not previous_ownership:
        routes['ph0'] = previous_ph0
        if previous_ownership is None:
            routes.pop('protonation_sites_by_species', None)
        else:
            routes['protonation_sites_by_species'] = previous_ownership
    return rx
