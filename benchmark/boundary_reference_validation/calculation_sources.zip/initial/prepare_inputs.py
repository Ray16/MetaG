"""Freeze primary-source boundary structures and exact molecular prerequisites."""
from pathlib import Path
from fractions import Fraction
import copy
import hashlib
import json
import sys

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[1]
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
sys.path.insert(0,str(ROOT/'benchmark'))
from rdkit import Chem
from audit_modelseed_inputs import load_chunks
from modelseed_cofactor_curation import validate_registry,rebase_equation
from metag.constants import CONDITIONS
from metag.state_function import plan_state
from metag.reactions import validate_reaction
from metag.chem import is_balanced,is_water
from metag.energetics.conformers import spin_multiplicity
from metag.routing.aldehyde_hydration import n_hydration_sites
from benchmark.anchored_nicotinamide import anchor_plan as original_anchor
from benchmark.anchored_nicotinamide_regio import anchor_plan as regio_anchor

read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,value):
    with (HERE/name).open('x') as stream:json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def main():
    old=ROOT/'analysis/modelseed_cofactor_curation_20261105_01'
    summary=read(old/'summary.json');review=read(HERE/'identity_review.json')
    compounds,cf=load_chunks(ROOT.parent.parent/'ModelSEEDDatabase/Biochemistry','compound')
    reactions,rf=load_chunks(ROOT.parent.parent/'ModelSEEDDatabase/Biochemistry','reaction')
    registry=read(old/'registry.json')
    for cid,row in review.items():
        assert 'target_plan' in row,(cid,row)
        registry[cid]=dict(name=row['name'],chebi_id=row['chebi_id'],source=row['source'],
            target=row['target'],delta_H=row['review']['delta_H'])
    validate_registry(registry,compounds)
    curated=copy.deepcopy(compounds)
    for cid,row in registry.items():curated[cid].update(smiles=row['target']['smiles'],charge=str(row['target']['charge']))
    sources=read(old/'affected_reactions.json');sources={r['reaction']:r for r in sources}
    catalog=read(ROOT/'benchmark/global_amino_reference_validation/catalog596.json')
    available={(r['charge'],r['smiles']):r for r in catalog['records']}
    requests={};needs={};state_plans={}
    for rid in summary['anchor_retaining_input_ids']:
        before={(cid,comp):Fraction(nu) for cid,comp,nu in sources[rid]['original_terms']}
        after,changes=rebase_equation(before,registry)
        assert len({comp for cid,comp in after})==1
        request=dict(species={},n_Hplus=0,conditions=dict(CONDITIONS))
        for (cid,comp),nu in after.items():
            assert nu.denominator==1
            if cid=='cpd00067':request['n_Hplus']+=int(nu);continue
            row=curated[cid];q=int(row['charge']);smi=row['smiles']
            request['species'][cid]=[int(nu),q,smi]
            plan=plan_state(q,smi);ref=(plan['reference_charge'],plan['reference_smiles'])
            assert n_hydration_sites(ref[1])==0
            state_plans[cid]=plan
            recipes={'full':[(1.,*ref)]}
            for arm,planner in [('anchor14',original_anchor),('anchor12and14',regio_anchor)]:
                transfer=planner(*ref)
                recipes[arm]=[(t['coefficient'],t['charge'],t['smiles']) for t in transfer['raw_terms']] if transfer else [(1.,*ref)]
            for arm,terms in recipes.items():
                for weight,rq,rs in terms:
                    if is_water(rs,rq):continue
                    key=str(rq)+'|'+rs
                    entry=needs.setdefault(key,dict(charge=rq,smiles=rs,spin=spin_multiplicity(rs,rq),
                        available_owned_record=(rq,rs) in available,used_by=[]))
                    entry['used_by'].append(dict(reaction=rid,compound=cid,arm=arm,coefficient=weight))
                    if (rq,rs) in available:
                        raw=available[(rq,rs)];entry.update(source_record=raw['name'],source_sha256=raw['sha256'],raw_profile=raw['raw_profile'])
        validate_reaction(request);assert is_balanced(request['species'],request['n_Hplus'])
        requests[rid]=dict(name=reactions[rid]['name'],source_ec=reactions[rid].get('ec_numbers'),
            request=request,proton_adjustments_from_literal=changes,
            source_stoichiometry_sha256=hashlib.sha256(reactions[rid]['stoichiometry'].encode()).hexdigest())
    tasks=[]
    for key,entry in sorted(needs.items()):
        if entry['available_owned_record']:continue
        mol=Chem.AddHs(Chem.MolFromSmiles(entry['smiles']))
        tasks.append(dict(slot='molecule_'+hashlib.sha256(key.encode()).hexdigest()[:16],
            charge=entry['charge'],smiles=entry['smiles'],spin=entry['spin'],n_atoms=mol.GetNumAtoms(),
            source_input_key=key,used_by=entry['used_by']))
    tasks.sort(key=lambda t:(-t['n_atoms'],t['slot']))
    write('registry_extended.json',registry);write('requests.json',requests);write('state_plans.json',state_plans)
    write('raw_prerequisites.json',needs);write('tasks.json',tasks)
    write('input_preparation.json',dict(n_requested=len(requests),n_registered_identities=len(registry),
        n_unique_nonwater_primitives=len(needs),n_retained_primitives=sum(r['available_owned_record'] for r in needs.values()),
        n_new_molecular_tasks=len(tasks),source_tables_sha256=dict(cf,**rf),
        max_atoms=max(t['n_atoms'] for t in tasks),
        source_identity_review_sha256=sha(HERE/'identity_review.json'),
        counterfactual_input_summary_sha256=sha(old/'summary.json'),
        scope='Primary-source state choices and exact proton rebasing fixed before physical outputs. No reaction labels are consulted.'))
    print(json.dumps(read(HERE/'input_preparation.json'),indent=2))
    print('TASKS',[(t['slot'],t['charge'],t['spin'],t['n_atoms']) for t in tasks])


if __name__=='__main__':main()
