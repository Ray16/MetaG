"""Screen the full source metadata universe, without equilibrium values or predictions."""
from pathlib import Path
from collections import Counter,defaultdict
import csv,hashlib,json,re,sys
H=Path(__file__).resolve().parent;P=H.parents[1]
sys.path[:0]=[str(P/'src'),str(P)]
from benchmark.benchmark_feasibility import named_equation_key
META=P/'benchmark/feasibility_validation/opentecr_source_metadata.csv'
TRAIN=P/'benchmark/feasibility_validation/training671_structural.csv'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def typography(text):
 for name,letter in [('alpha','α'),('beta','β'),('gamma','γ'),('omega','ω')]:
  text=text.replace('{\\'+name+'}',name).replace('\\'+name,name).replace(letter,name)
 return re.sub(r'(?i)\bN-(?:w|omega)-','N-omega-',text)

def key(text,strip_phase=False,normalize_typography=False):
 text=text.replace(' ⇌ ',' = ').replace(' ↔ ',' = ')
 if normalize_typography:text=typography(text)
 if strip_phase:text=re.sub(r'\((?:aq|l|g|cr|s)\)','',text,flags=re.I)
 return named_equation_key(text)

with TRAIN.open(newline='') as f:training=[r for r in csv.DictReader(f) if r['type']=='reaction dg']
indexes={tier:defaultdict(list) for tier in ['strict','phase_erased_exposure_proxy','typography_exposure_proxy']};training_unresolved=[]
for i,row in enumerate(training):
 for tier,strip,normalized in [('strict',False,False),('phase_erased_exposure_proxy',True,False),('typography_exposure_proxy',True,True)]:
  try:indexes[tier][key(row['description'],strip,normalized)].append(row['description'])
  except ValueError:training_unresolved.append(dict(description=row['description'],tier=tier))
with META.open(newline='') as f:source=list(csv.DictReader(f))
groups={};unresolved=[]
for i,row in enumerate(source):
 try:signature=key(row['reaction'])
 except ValueError as e:unresolved.append(dict(source_row=i,reason=str(e)));continue
 signature_text=json.dumps(signature)
 if signature_text not in groups:
  relaxed=key(row['reaction'],True)
  groups[signature_text]=dict(reaction=row['reaction'],strict_training_name_match=indexes['strict'].get(signature,[]),
   phase_erased_training_exposure_proxy=indexes['phase_erased_exposure_proxy'].get(relaxed,[]),typography_training_exposure_proxy=indexes['typography_exposure_proxy'].get(key(row['reaction'],True,True),[]),source_rows=[])
 groups[signature_text]['source_rows'].append(dict(source_row=i,**row))
new=[]
for g in groups.values():
 if g['strict_training_name_match'] or g['phase_erased_training_exposure_proxy'] or g['typography_training_exposure_proxy']:continue
 conditions=[]
 for row in g['source_rows']:
  complete=all(row[k].strip() for k in ['temperature','ionic_strength','p_h','p_mg'])
  conditions.append(dict(source_row=row['source_row'],all_four_fields_filled=complete,
   nominal298_15=row['temperature'].strip()=='298.15',reference=row['reference']))
 new.append(dict(g,condition_screen=conditions,measurement_independence_verified=False,reference_admitted=False))
report=dict(scope='Full projected OpenTECR source metadata screen; name nonmatches are leads, not molecular novelty, measurement independence or eligible reference labels.',
 inputs_sha256=dict(source=sha(META),training=sha(TRAIN)),outcome_values_read_or_exported=False,predictions_performed=False,
 counts=dict(source_metadata_rows=len(source),unique_strict_named_equations=len(groups),
  equations_without_any_declared_training_name_exposure_match=len(new),
  such_equations_with_any_complete_four_field_row=sum(any(x['all_four_fields_filled'] for x in g['condition_screen']) for g in new),
  such_equations_with_any_298_15_complete_row=sum(any(x['all_four_fields_filled'] and x['nominal298_15'] for x in g['condition_screen']) for g in new)),
 candidate_groups=new,unresolved_source_rows=unresolved,unresolved_training_description_entries=training_unresolved,
 independence_certified=False,experimental_references_admitted=0,
 limits='Phase-erased matching is conservative exposure screening only; gas/liquid/aqueous states are not thermodynamically equated. Synonym/state-pool/structure matches can remain unresolved. Filled metadata is not primary-source authentication and a blank never means zeroI or absentMg. Historical MetaG/source ancestry, exact chemistry, conditions and uncertainty remain required.')
(H/'source_metadata_screen.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['counts'],indent=2))
for g in new:
 if any(x['all_four_fields_filled'] and x['nominal298_15'] for x in g['condition_screen']):
  print('PRIORITY SOURCE LEAD',g['reaction'],sorted({r['reference'] for r in g['source_rows']}))
