from pathlib import Path
import json
import pytest
from compute_one import actual_implicit_record


def record(path,spin=3):
 row=dict(smi='O=O',q=0,method='implicit',G=1.,sigma=0.,settings=dict(model='fixture',spin=spin,producer={'cacheable':True}))
 path.write_text(json.dumps(row));return row


def test_reads_actual_triplet_record_without_reconstructing_a_singlet_filename(tmp_path):
 row=record(tmp_path/'arbitrary_produced_key.json')
 path,actual=actual_implicit_record(tmp_path,dict(smiles='O=O',charge=0,spin=3),dict(model='fixture'),{'cacheable':True})
 assert path.name=='arbitrary_produced_key.json' and actual==row


def test_wrong_spin_or_ambiguous_raw_records_are_refused(tmp_path):
 record(tmp_path/'a.json',spin=1)
 with pytest.raises(ValueError,match='spin'):actual_implicit_record(tmp_path,dict(smiles='O=O',charge=0,spin=3),dict(model='fixture'),{'cacheable':True})
 record(tmp_path/'b.json',spin=3)
 with pytest.raises(ValueError,match='exactly one'):actual_implicit_record(tmp_path,dict(smiles='O=O',charge=0,spin=3),dict(model='fixture'),{'cacheable':True})
