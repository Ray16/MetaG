"""Read-only dependency/resource preflight, then one atomic shared-GPU reservation."""
from pathlib import Path
import ast,datetime,hashlib,json,os,shutil,subprocess,sys
from common import HERE,read,write,owner,sha

assert not (HERE/'launch_manifest.json').exists(),'Inspect original ownership and outputs before any resubmission'
p=read(HERE/'protocol.json');resource=p['resources'];cpus=resource['cpus'];gate='/nfs/lambda_stor_01/homes/rzhu/bin/gpu_reserve'
assert os.uname().nodename==resource['host']
python='/nfs/lambda_stor_01/homes/rzhu/.cache/metag-environments/uma-nitro-20261023-645af7d/venv/bin/python'
DFTpython='/nfs/lambda_stor_01/homes/rzhu/miniforge3/envs/redox/bin/python'
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',
    PYTHONPATH=os.pathsep.join([p['source_engine'],p['source_sdk']]),
    LD_LIBRARY_PATH='/nfs/lambda_stor_01/homes/rzhu/miniforge3/envs/redox/lib:/nfs/lambda_stor_01/homes/rzhu/miniforge3/envs/xtb/lib',
    METAG_POINT_OUTPUT=str(HERE/'points'),OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
helper='/nfs/lambda_stor_01/homes/rzhu/.codex-personal/skills/lambda-fleet/scripts/preflight_node.py'
for name,executable,modules in [('molecular',python,['torch','ase','rdkit','fairchem.core','metag.energetics.uma']),('DFT',DFTpython,['pyscf','gpu4pyscf','cupy'])]:
    argv=[sys.executable,helper,'local','--python',executable,'--cpu-set',','.join(map(str,cpus)),
          '--min-available-ram-mib','16384','--library-path',env['LD_LIBRARY_PATH'],'--bin',gate,'--bin',p['xtb']]
    for module in modules:argv+=['--module',module]
    r=subprocess.run(argv,env=env,capture_output=True,text=True,timeout=60);(HERE/(name+'_dependency_preflight.json')).write_text(r.stdout)
    if r.returncode:print(r.stdout);print(r.stderr);r.check_returncode()
for path in HERE.glob('*.py'):ast.parse(path.read_text(),filename=str(path))
assert max(os.getloadavg())+len(cpus)<=os.cpu_count()
assert shutil.disk_usage('/tmp').free>=5*1024**3
gpu_lines=subprocess.check_output(['/usr/bin/nvidia-smi','--query-gpu=index,uuid,memory.total','--format=csv,noheader'],text=True).splitlines()
gpu=next(line.split(',') for line in gpu_lines if int(line.split(',')[0])==resource['gpu_index'])
uuid=gpu[1].strip();assert int(gpu[2].strip().split()[0])>=24000
resident=subprocess.check_output(['/usr/bin/nvidia-smi','--query-compute-apps=gpu_uuid,pid','--format=csv,noheader'],text=True)
assert uuid not in resident,'Resident process means occupied; no input attempt consumed'
for directory in ['claims','points','optimization','curvature']:(HERE/directory).mkdir(exist_ok=True)
now=datetime.datetime.now(datetime.timezone.utc)
files=[path.name for path in HERE.iterdir() if path.is_file() and path.suffix in ['.py','.json'] and path.name not in ['freeze.json','launch_manifest.json']]
write(HERE/'freeze.json',dict(utc=now.isoformat(),files_sha256={name:sha(HERE/name) for name in files},scope='Frozen initial scientific inputs, source references, producer code and analysis before molecular calculations. Derived geometries and SCF outputs are separately bound.'))
argv=[gate,'run',str(resource['gpu_index']),'--label','metag_aqueous_reference_transfer','--','/usr/bin/taskset','-c',','.join(map(str,cpus)),sys.executable,str(HERE/'controller.py')]
manifest=dict(utc=now.isoformat(),deadline_utc=(now+datetime.timedelta(seconds=p['controller_budget_seconds'])).isoformat(),host=os.uname().nodename,
    gpu_index=resource['gpu_index'],gpu_uuid=uuid,cpus=cpus,molecular_python=python,DFT_python=DFTpython,argv=argv,expected_optimizer_tasks=48,
    total_GPU_hour_ceiling=2,freeze_sha256=sha(HERE/'freeze.json'),scope=p['scope'])
write(HERE/'launch_manifest.json',manifest)
with (HERE/'launcher.log').open('x') as log:
    process=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
write(HERE/'launcher_owner.json',dict(pid=process.pid,host=os.uname().nodename,start_ticks=Path(f'/proc/{process.pid}/stat').read_text().rsplit(')',1)[1].split()[19]))
print(json.dumps(dict(launcher_pid=process.pid,gpu_uuid=uuid,cpus=cpus,deadline_utc=manifest['deadline_utc']),indent=2))
