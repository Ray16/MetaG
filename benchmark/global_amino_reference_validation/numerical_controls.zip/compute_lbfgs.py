"""Tight-force LBFGS control with complete endpoint forces and Hessians retained."""
from pathlib import Path
from dataclasses import asdict
import hashlib
import json
import os
import time
import traceback
import numpy as np
import torch
from ase import Atoms
from ase.calculators.calculator import Calculator,all_changes
from ase.optimize import LBFGS
from rdkit import Chem

HERE=Path(__file__).resolve().parent
OUT=HERE/'lbfgs_control'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,value):
    target=OUT/name;tmp=target.with_suffix(target.suffix+'.tmp')
    tmp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');tmp.replace(target)

def main():
    m=read(OUT/'launch_manifest.json');p=read(OUT/'protocol.json');data=read(OUT/'input.json')
    for n,d in m['files_sha256'].items():assert sha(HERE/n)==d,n
    assert sha(OUT/'input.json')==p['input_sha256']
    assert sorted(os.sched_getaffinity(0))==m['cpus']
    write('predictor_owner.json',dict(pid=os.getpid(),host=os.uname().nodename,
        start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]))
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    from metag.energetics.uma import load_uma,_predict
    from metag.energetics.backend import UMABackend
    from metag.energetics.conformers import bond_graph,same_connectivity,same_stereochemistry
    from metag.energetics.thermal import uma_hessian_autograd,gibbs_corr_from_hessian,dgsolv
    from metag.settings import Settings
    pu=load_uma('uma-s-1p2p1',profile='nitro')
    backend=UMABackend(pu,Settings(**read(HERE/'raw_settings.json')),log=lambda *_:None)
    assert backend.producer==read(HERE/'catalog.json')['producer']
    config=pu._reference.model.module.backbone.regress_config
    write('force_model_definition.json',dict(regress_config=asdict(config),
        source='Official loaded checkpoint backbone regression configuration; no model override.'))
    template=Chem.AddHs(Chem.MolFromSmiles(data['reference_smiles']));graph=bond_graph(template)
    summaries=[]
    for slot,positions in data['starts'].items():
        started=time.monotonic();evaluations=0
        atoms=Atoms(data['symbols'],positions=positions,
            info={'charge':data['charge'],'spin':data['spin_multiplicity']})
        result=dict(slot=slot,source_positions_angstrom=positions,optimizer='ASE_LBFGS',
            fmax_required_eV_A=p['fmax_eV_A'],step_budget=p['step_budget'])
        optimizer=None
        class BudgetExceeded(RuntimeError):pass
        class SameHamiltonian(Calculator):
            implemented_properties=['energy','forces']
            def calculate(self,atoms=None,properties=('energy','forces'),system_changes=all_changes):
                nonlocal evaluations
                super().calculate(atoms,properties,system_changes)
                if time.monotonic()-started>p['per_arm_seconds']:raise BudgetExceeded('per-arm budget exhausted')
                e,f,_=_predict(pu,[atoms]);evaluations+=1
                self.results=dict(energy=float(e.cpu().numpy()[0]),forces=f.cpu().numpy().astype(float))
        try:
            atoms.calc=SameHamiltonian()
            optimizer=LBFGS(atoms,maxstep=p['maxstep_A'],logfile=str(OUT/(slot+'.optimizer.log')))
            converged=bool(optimizer.run(fmax=p['fmax_eV_A'],steps=p['step_budget']))
            atoms.calc=None
            e,f,_=_predict(pu,[atoms]);energy=float(e.cpu().numpy()[0]);force=f.cpu().numpy().astype(float)
            H=uma_hessian_autograd(pu,atoms,rows=8)
            corr,info=gibbs_corr_from_hessian(atoms,H,energy,'nonlinear',symmetrynumber=1,
                spin=1,return_info=True,imag_as_soft=False)
            info.pop('_imag_vecs',None)
            solvent=dgsolv(data['symbols'],atoms.positions,data['charge'],data['spin_multiplicity'])
            identity=bool(same_connectivity(atoms,graph) and same_stereochemistry(atoms,template))
            maximum=float(np.linalg.norm(force,axis=1).max())
            accepted=bool(converged and maximum<=p['fmax_eV_A'] and identity and info['n_imag']==0
                and corr is not None and np.isfinite(corr) and solvent is not None and np.isfinite(solvent))
            np.savez_compressed(OUT/(slot+'.npz'),H_eV_A2=H,forces_eV_A=force,
                positions_angstrom=atoms.positions,energy_eV=energy)
            result.update(status='complete',positions_angstrom=atoms.positions.tolist(),
                converged=converged,max_force_eV_A=maximum,identity_preserved=identity,
                n_imag=int(info['n_imag']),max_imag_cm=float(info['max_imag_cm']),
                electronic_kj=energy*96.485,solvation_kj=solvent,thermal_kj=corr,
                strict_endpoint_accepted=accepted,endpoint_total_kj=(energy*96.485+solvent+corr if accepted else None),
                Hessian_archive_sha256=sha(OUT/(slot+'.npz')))
        except Exception as error:
            result.update(status='failed',error=str(error),traceback=traceback.format_exc(),strict_endpoint_accepted=False)
        result.update(elapsed_seconds=time.monotonic()-started,evaluations=evaluations,
            steps=int(optimizer.nsteps) if optimizer is not None else 0)
        write(slot+'.json',result);summaries.append(result)
        print('LBFGS ENDPOINT',slot,result['status'],result.get('max_force_eV_A'),result.get('n_imag'),flush=True)
    write('summary.json',dict(results=summaries,producer=backend.producer,
        scope=p['scope'],complete_molecular_estimate=False,raw_cache_replaced=False))

if __name__=='__main__':main()
