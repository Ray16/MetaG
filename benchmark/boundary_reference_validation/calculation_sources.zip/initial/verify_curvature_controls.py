"""Independent QR external-mode projection and ideal-gas RRHO on four matrices."""
from pathlib import Path
import json
import math
import numpy as np
from ase import Atoms,units
from ase.thermochemistry import IdealGasThermo

HERE=Path(__file__).resolve().parent
output=[]
for path in sorted((HERE/'curvature_controls').glob('*.json')):
    row=json.loads(path.read_text());g=row['geometry'];a=Atoms(symbols=g['symbols'],positions=g['positions_angstrom'])
    data=np.load(path.with_suffix('.npz'));H=data['hessian_eV_A2']
    masses=a.get_masses();x=a.positions-np.average(a.positions,axis=0,weights=masses);root=np.sqrt(masses)
    columns=[]
    for axis in np.eye(3):columns.append((np.broadcast_to(axis,x.shape)*root[:,None]).ravel())
    for axis in np.eye(3):columns.append((np.cross(axis,x)*root[:,None]).ravel())
    external=np.column_stack(columns);assert np.linalg.matrix_rank(external)==6
    Q,_=np.linalg.qr(external,mode='complete');B=Q[:,6:]
    mw=H/np.outer(np.repeat(root,3),np.repeat(root,3))
    eig=np.linalg.eigvalsh(B.T@mw@B)
    factor=units._hbar*1e10/math.sqrt(units._e*units._amu)
    energies=factor*np.sqrt(np.abs(eig));imag=energies[eig<0]/1.23984e-4
    assert not np.any(imag>50.),(row['slot'],imag)
    floored=np.maximum(energies,50.*1.23984e-4)
    assert len(floored)==3*len(a)-6 and row['symmetrynumber']==1
    thermo=IdealGasThermo(vib_energies=floored,potentialenergy=0.,atoms=a,
        geometry='nonlinear',symmetrynumber=1,spin=(g['spin_multiplicity']-1)/2,vib_selection='all')
    calculated=thermo.get_gibbs_energy(temperature=298.15,pressure=101325.,verbose=False)*96.485
    assert abs(calculated-row['thermal_kj'])<.0001
    assert abs(calculated-row['expected_thermal_kj'])<.02
    output.append(dict(slot=row['slot'],QR_RRHO_kj=calculated,native_RRHO_kj=row['thermal_kj'],
        difference_from_native_kj=calculated-row['thermal_kj'],difference_from_retained_kj=calculated-row['expected_thermal_kj'],
        force_max_eV_A=row['force_max_eV_A'],n_internal_modes=len(floored),n_strong_imaginary=0,
        n_soft_negative=int(np.sum(eig<0))))
result=dict(status='passed',scope='Four fixed-geometry numerical controls; not an all-minimum thermal replay or experimental accuracy validation.',controls=output)
(HERE/'independent_curvature_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
