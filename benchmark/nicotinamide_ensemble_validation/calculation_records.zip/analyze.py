"""Analyze complete retained pools; fail closed if any required SCF pair is absent."""
from collections import Counter
from decimal import Decimal, localcontext
import json
import math
from pathlib import Path
from control_common import HERE, authenticate, load_point, sha, write
from original_audit import pool

WEIGHTS = dict(full_red=1, full_ox=-1, core_red=-1, core_ox=1)

def analyze():
    analysis_freeze=json.loads((HERE/'analysis_freeze.json').read_text())
    assert analysis_freeze['analyze_sha256']==sha(__file__)
    assert analysis_freeze['protocol_sha256']==sha(HERE/'fixed_geometry_protocol.json')
    inputs, protocol = authenticate()
    points = {slot:load_point(slot,inputs,protocol) for slot in inputs['inputs']}
    missing = [slot for slot,point in points.items() if point is None]
    assert not missing, f'Complete-pool endpoint withheld; {len(missing)} missing pairs: {missing}'
    by_family={family:sorted(key for key,item in inputs['inputs'].items() if item['family']==family) for family in WEIGHTS}
    assert [len(by_family[f]) for f in ['core_ox','core_red','full_ox','full_red']]==[3,4,41,55]
    reused=json.loads((HERE/'reuse_receipt.json').read_text())
    restricted={family:[key for key in keys if key in reused] for family,keys in by_family.items()}
    assert [len(restricted[f]) for f in ['core_ox','core_red','full_ox','full_red']]==[3,4,1,1]
    residual=Counter();charge=0
    for family,keys in by_family.items():
        first=inputs['inputs'][keys[0]]['geometry']
        for key in keys:
            geometry=inputs['inputs'][key]['geometry']
            assert Counter(geometry['symbols'])==Counter(first['symbols']) and geometry['charge']==first['charge']
        residual.update({symbol:count*WEIGHTS[family] for symbol,count in Counter(first['symbols']).items()})
        charge+=WEIGHTS[family]*first['charge']
    assert not any(residual.values()) and charge==0 and sum(WEIGHTS.values())==0
    arms={};independent={}
    for subset, selection in [('full',by_family),('restricted',restricted)]:
        for electronic in ['UMA','DFT']:
            for solvent in ['ALPB','SMD']:
                families={};decimal_pools={}
                for family,keys in selection.items():
                    rows=[]
                    for key in keys:
                        original=inputs['inputs'][key]['original_components_kj'];point=points[key]
                        e=original['electronic_kj'] if electronic=='UMA' else point['gas']['energy_Eh']*protocol['Hartree_to_kj_per_mol']
                        s=original['solvation_kj'] if solvent=='ALPB' else point['SMD_delta_Eh']*protocol['Hartree_to_kj_per_mol']
                        rows.append(dict(electronic_kj=e,solvation_kj=s,thermal_kj=original['thermal_kj']))
                    value=pool(rows,protocol['pool_KT_kj'])
                    probabilities=value['probabilities']
                    value.update(slots=keys,maximum_probability=max(probabilities),
                        dominant_slot=keys[max(range(len(keys)),key=lambda i:probabilities[i])],
                        entropy_effective_population=math.exp(-math.fsum(p*math.log(p) for p in probabilities if p)),
                        inverse_participation_population=1/math.fsum(p*p for p in probabilities))
                    families[family]=value
                    # Independent high-precision log partition uses the unrounded
                    # component floats as the declared numerical inputs.
                    with localcontext() as context:
                        context.prec=50
                        D=lambda value:Decimal(str(value))
                        totals=[sum(map(D,row.values())) for row in rows]
                        minimum=min(totals);kt=D(protocol['pool_KT_kj'])
                        part=sum((-(total-minimum)/kt).exp() for total in totals)
                        decimal_pools[family]=minimum-kt*part.ln()
                        assert abs(float(decimal_pools[family])-value['G_kj'])<1e-7
                exchange=math.fsum(WEIGHTS[family]*families[family]['G_kj'] for family in WEIGHTS)
                components={name:math.fsum(WEIGHTS[family]*families[family]['components_kj'][name] for family in WEIGHTS)
                    for name in next(iter(families.values()))['components_kj']}
                assert abs(math.fsum(components.values())-exchange)<1e-7
                key=f'{subset}|{electronic}|{solvent}'
                arms[key]=dict(exchange_kj=exchange,components_kj=components,families=families)
                independent[key]=str(sum(Decimal(WEIGHTS[f])*decimal_pools[f] for f in WEIGHTS))
                assert abs(float(independent[key])-exchange)<1e-7
    original={family:json.loads(Path(source['path']).read_text())['G'] for family,source in inputs['source_records'].items()}
    for family,value in arms['full|UMA|ALPB']['families'].items():assert abs(value['G_kj']-original[family])<1e-7
    ensemble_contrasts={f'{e}|{s}':arms[f'full|{e}|{s}']['exchange_kj']-arms[f'restricted|{e}|{s}']['exchange_kj']
        for e in ['UMA','DFT'] for s in ['ALPB','SMD']}
    primary=ensemble_contrasts['DFT|SMD']
    factorial={}
    for subset in ['full','restricted']:
        values={f'{e}|{s}':arms[f'{subset}|{e}|{s}']['exchange_kj'] for e in ['UMA','DFT'] for s in ['ALPB','SMD']}
        factorial[subset]=dict(electronic_at_ALPB_kj=values['DFT|ALPB']-values['UMA|ALPB'],
            solvent_at_UMA_kj=values['UMA|SMD']-values['UMA|ALPB'],
            electronic_at_SMD_kj=values['DFT|SMD']-values['UMA|SMD'],
            solvent_at_DFT_kj=values['DFT|SMD']-values['DFT|ALPB'],
            interaction_kj=values['DFT|SMD']-values['UMA|SMD']-values['DFT|ALPB']+values['UMA|ALPB'])
    return dict(scope=protocol['scope'],n_geometries=103,n_reused=9,n_new=94,weights=WEIGHTS,
        element_residual={k:v for k,v in residual.items() if v},charge_residual=charge,
        arms=arms,full_minus_restricted_kj=ensemble_contrasts,
        primary_DFT_SMD_ensemble_contrast_kj=primary,
        exceeds_descriptive_sensitivity_threshold=abs(primary)>=protocol['descriptive_sensitivity_threshold_kj'],
        factorial_contrasts=factorial,independent_decimal_exchange_kj=independent,
        new_primary_experimental_references_admitted=0,production_reference_policy_adopted=False,
        limitations=['Fixed original gas geometries and RRHO; not a complete aqueous equilibrium ensemble.',
            'All originally retained minima included; no proof of conformational or electronic ground-state completeness.',
            'SMD and parent DFT are modeling alternatives, not independent experimental truth.',
            'This closed atom/charge-balanced exchange has no proton or electron reference offset to fit.',
            'No pH, Mg-binding, ionic-strength or biochemical accuracy validation is established.'])

if __name__=='__main__':
    result=analyze();write(HERE/'ensemble_results.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='arms'},indent=2))
