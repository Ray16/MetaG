"""Read-only verification of actual worker/predictor ownership and allocations."""
from pathlib import Path
import datetime
import json
import os
import subprocess
from common import HERE,read,write

assert os.uname().nodename=='lambda13'
manifest=read(HERE/'launch_manifest.json');allocations=manifest['allocations'][-2:]
all_processes={}
for p in Path('/proc').glob('[0-9]*'):
    try:
        stat=(p/'stat').read_text().rsplit(')',1)[1].split()
        all_processes[int(p.name)]=dict(parent=int(stat[1]),state=stat[0],start_ticks=stat[19],
            affinity=sorted(os.sched_getaffinity(int(p.name))),
            command=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace'))
    except (OSError,ValueError):continue
workers=[];roots=[]
for a in allocations:
    f=HERE/'workers'/(a['worker']+'.owner.json')
    if not f.exists():workers.append(dict(worker=a['worker'],state='owner_not_yet_written'));continue
    owner=read(f);current=all_processes.get(owner['pid'])
    live=current is not None and current['start_ticks']==owner['start_ticks'] and current['state']!='Z'
    if live:assert current['affinity']==a['cpus'];roots.append(owner['pid'])
    pf=HERE/'workers'/(a['worker']+'.predictor.json');predictor=read(pf) if pf.exists() else None
    info=all_processes.get(predictor['pid']) if predictor else None
    active=info is not None and info['start_ticks']==predictor['start_ticks'] and info['state']!='Z'
    environment={}
    if active:
        assert info['affinity']==a['cpus']
        raw=(Path('/proc')/str(predictor['pid'])/'environ').read_bytes().split(b'\0')
        env={item.split(b'=',1)[0].decode():item.split(b'=',1)[1].decode() for item in raw if b'=' in item}
        for key in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:
            assert env[key]=='1';environment[key]=env[key]
        environment.update(CUDA_VISIBLE_DEVICES=env.get('CUDA_VISIBLE_DEVICES'),METAG_XTB_WORKERS=env.get('METAG_XTB_WORKERS'),
            FAIRCHEM_CACHE_DIR=env.get('FAIRCHEM_CACHE_DIR'))
    workers.append(dict(worker=a['worker'],allocation=a,worker_live=live,predictor_live=active,
        predictor=predictor,predictor_affinity=info['affinity'] if active else None,environment=environment,
        status=read(HERE/'workers'/(a['worker']+'.status.json'))['state']))
owned=set(roots)
while True:
    added={pid for pid,row in all_processes.items() if row['parent'] in owned}-owned
    if not added:break
    owned.update(added)
cpus={c for a in allocations for c in a['cpus']};external=[]
for pid,row in all_processes.items():
    if pid in owned or pid==os.getpid() or row['state']=='Z' or 'python' not in row['command'].split(' ',1)[0]:continue
    if len(row['affinity'])<os.cpu_count() and set(row['affinity'])&cpus:external.append(dict(pid=pid,**row))
assert not external,external
mem={line.split(':',1)[0]:int(line.split(':',1)[1].split()[0]) for line in Path('/proc/meminfo').read_text().splitlines()}
assert max(os.getloadavg())+4<=os.cpu_count() and mem['MemAvailable']/1024>=131072
gpus=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,used_gpu_memory','--format=csv,noheader'],text=True)
for a in allocations:
    resident=[line for line in gpus.splitlines() if a['gpu_uuid'] in line]
    assert len(resident)<=1,(a,resident)
result=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),workers=workers,
    external_CPU_overlap=external,online_cpus=os.cpu_count(),load=os.getloadavg(),available_RAM_MiB=mem['MemAvailable']/1024,
    gpu_compute_processes=gpus,claimed_inputs=sorted(p.name for p in (HERE/'claims').iterdir()),
    terminal_molecular_results=len(list((HERE/'results').glob('*.json'))))
write(HERE/'startup_verification.json',result)
print(json.dumps(result,indent=2))
