"""Analyze all predeclared chemical component arms; refuse incomplete pools."""
from decimal import Decimal,localcontext
import json,math
from common import HERE,authenticate,read,sha,write

def run():
    inputs,protocol=authenticate();reference=read(HERE/'reference.json')
    status=read(HERE/'molecular_status.json');assert status['state']=='complete'
    controller=read(HERE/'controller_status.json');assert controller['state'] in ['calculations_complete','complete']
    assert not controller['failures']
    scf=read(HERE/'scf_geometry_inputs.json')['inputs'];index=read(HERE/'retained_geometry_index.json')
    outputs={};kt=protocol['pool_KT_kj'];factor=protocol['units']['Hartree_to_kj'];eV=protocol['units']['eV_to_kj']
    for slot in scf:
        point=read(HERE/'points'/(slot+'.json'));curvature=read(HERE/'curvature'/slot/'result.json')
        assert point['passed'] and curvature['passed'] and point['geometry']==scf[slot]['geometry']
        assert point['source_sha256']==sha(HERE/'reference_point.py')
        assert point['protocol_sha256']==sha(HERE/'parent_protocol.json')
        assert point['input_sha256']==sha(HERE/'scf_geometry_inputs.json')
        for phase in ['gas','water']:
            value=point[phase];summary=value['scf_summary']
            assert value['converged'] and value['n_molecular_orbitals']==scf[slot]['n_AO']
            assert value['orbital_gradient_norm']<=read(HERE/'parent_protocol.json')['stationary_gradient_maximum']
            terms=[summary[k] for k in ['e1','e2','nuc']]
            if phase=='water':terms.extend([summary['e_solvent'],summary['e_cds']])
            assert abs(math.fsum(terms)-value['energy_Eh'])<1e-8
        assert abs(point['SMD_delta_Eh']-point['water']['energy_Eh']+point['gas']['energy_Eh'])<1e-10
        outputs[slot]=(curvature,point)
    arms={}
    for mode in inputs['geometry_modes']:
        for electronic in ['UMA','DFT']:
            for solvent in ['ALPB','SMD']:
                families={}
                for family in inputs['species']:
                    slots=index[f'{family}|{mode}'];rows=[]
                    for slot in slots:
                        c,d=outputs[slot]
                        E=c['UMA_energy_eV']*eV if electronic=='UMA' else d['gas']['energy_Eh']*factor
                        S=c['ALPB_delta_eV']*eV if solvent=='ALPB' else d['SMD_delta_Eh']*factor
                        rows.append(dict(electronic_kj=E,solvation_kj=S,RRHO_kj=c['RRHO_kj']))
                    total=[math.fsum(row.values()) for row in rows];low=min(total)
                    weights=[math.exp(-(g-low)/kt) for g in total];part=math.fsum(weights);probabilities=[p/part for p in weights]
                    value=low-kt*math.log(part)
                    components={k:math.fsum(p*r[k] for p,r in zip(probabilities,rows)) for k in rows[0]}
                    components['configurational_kj']=kt*math.fsum(p*math.log(p) for p in probabilities if p)
                    assert abs(math.fsum(components.values())-value)<1e-7
                    with localcontext() as context:
                        context.prec=50;D=lambda x:Decimal(str(x));totals=[sum(D(v) for v in row.values()) for row in rows];m=min(totals)
                        independent=m-D(kt)*sum((-(g-m)/D(kt)).exp() for g in totals).ln()
                        assert abs(float(independent)-value)<1e-7
                    families[family]=dict(G_kj=value,components_kj=components,probabilities=probabilities,slots=slots,independent_decimal_G_kj=str(independent))
                reactions={}
                for key,coefficients in inputs['reactions'].items():
                    predicted=math.fsum(w*families[k]['G_kj'] for k,w in coefficients.items());target=reference['chemical_reference_kj'][key]
                    reactions[key]=dict(prediction_kj=predicted,evaluated_reference_kj=target,error_kj=predicted-target,absolute_error_kj=abs(predicted-target),conditional_source_half_width_kj=reference['conditional_source_half_width_kj'][key])
                arms[f'{mode}_geometry|{electronic}|{solvent}']=dict(species=families,reactions=reactions,MAE_kj=math.fsum(r['absolute_error_kj'] for r in reactions.values())/2)
    result=dict(scope=protocol['scope'],arms=arms,n_species=6,n_optimized_starting_poses=48,n_retained_geometries=len(outputs),chemical_reference=reference,
        primary_independent_metabolic_references_added=0,production_reference_policy_adopted=False,
        limitations=['Two correlated chemical proton-transfer reactions, not a biochemical-pool benchmark.','Four starting poses are a finite search, not proof of full conformational completeness.','Aqueous RRHO uses approximate effective-potential curvature; alternative electronic/solvent arms retain that thermal model.','Source uncertainties are subjective, covariance is unknown, and component-model parameter exposure is incompletely indexed.','No statistical generalization, total-error interval, physical-reference promotion or label-fitted correction is established.'])
    write(HERE/'results.json',result);print(json.dumps({k:{'reactions':v['reactions'],'MAE_kj':v['MAE_kj']} for k,v in arms.items()},indent=2))

if __name__=='__main__':run()
