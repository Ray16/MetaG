"""Stage every physical record/outcome and the exact scoring implementations."""
from pathlib import Path
import gzip
import hashlib
import json
import shutil
import zipfile
from common import HERE,ROOT,read,sha

packet=ROOT/'benchmark/boundary_reference_validation';packet.mkdir(exist_ok=False)
for name in ['protocol.json','freeze.json','analysis_freeze.json','analysis_revision1.json','analysis_revision2.json',
             'augmented_analysis_freeze.json','input_preparation.json','registry_extended.json','identity_review.json',
             'source_selection.json','source_retrieval.json','raw_settings.json','requests.json','state_plans.json',
             'retained_raw_verification.json','compatibility_fixtures.json','cache_reconciliations.json',
             'resource_amendment.json','launch_manifest.initial.json','launch_manifest.json',
             'curvature_control_protocol.json','independent_curvature_verification.json','cold_replay.py']:
    shutil.copyfile(HERE/name,packet/name)
for name in ['boundary_reference.py']:shutil.copyfile(ROOT/'benchmark'/name,packet/name)
for name in ['primary_sources','curvature_controls']:
    shutil.copytree(HERE/name,packet/name)
old=ROOT/'benchmark/modelseed_cofactor_curation_validation/primary_sources'
for f in old.iterdir():
    if not (packet/'primary_sources'/f.name).exists():shutil.copyfile(f,packet/'primary_sources'/f.name)
catalog=read(HERE/'assembly_augmented/raw_catalog.json');shutil.copyfile(HERE/'assembly_augmented/raw_catalog.json',packet/'raw_catalog.json')
legacy=ROOT/'benchmark/global_amino_reference_validation'
water=read(legacy/'catalog596.json')['water_liquid_1atm_kj']
(packet/'water_reference.json').write_text(json.dumps(dict(water_liquid_1atm_kj=water,
    source_catalog_sha256=sha(legacy/'catalog596.json'),scope='Retained experimental-hydration water reference before the gas-to1Mstandard-state correction; same in all arms.'),indent=2)+'\n')
raw_by_name={}
for directory in [HERE,HERE/'numerical_extension']:
    for file in (directory/'results').glob('*.json'):
        row=read(file)
        if row['status']=='molecular_record_complete':
            path=Path(row['cache_path']);raw_by_name[path.name]=path
for entry in read(HERE/'cache_reconciliations.json').values():
    path=Path(entry['cache_path']);raw_by_name[path.name]=path
with zipfile.ZipFile(packet/'raw_records.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    with zipfile.ZipFile(legacy/'raw_records.zip') as old_archive:
        for row in catalog['records']:
            data=raw_by_name[row['name']].read_bytes() if row['name'] in raw_by_name else old_archive.read(row['name'])
            assert hashlib.sha256(data).hexdigest()==row['sha256'];archive.writestr(row['name'],data)
with zipfile.ZipFile(packet/'assemblies.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for label,folder in [('primary','assembly'),('augmented','assembly_augmented')]:
        for f in sorted((HERE/folder).glob('*.json')):archive.write(f,label+'/'+f.name)
with zipfile.ZipFile(packet/'scoring_source.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for f in sorted((HERE/'owned_source').rglob('*')):
        if f.is_file() and f.suffix in {'.py','.json'}:archive.write(f,str(f.relative_to(HERE/'owned_source')))
with zipfile.ZipFile(packet/'calculation_sources.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for f in sorted(HERE.glob('*.py')):archive.write(f,'initial/'+f.name)
    for f in sorted((HERE/'numerical_extension').glob('*')):
        if f.is_file() and f.suffix in {'.py','.json'}:archive.write(f,'numerical_extension/'+f.name)
    f=HERE/'numerical_extension/owned_source/src/metag/energetics/minimum_optimizer.py'
    archive.write(f,'numerical_extension/minimum_optimizer.py')
    archive.write(legacy/'assembly_source.zip','legacy_raw_source.zip')
outcomes={label:{f.stem:read(f) for f in sorted((folder/'results').glob('*.json'))}
          for label,folder in [('initial',HERE),('numerical_extension',HERE/'numerical_extension')]}
(packet/'task_outcomes.json.gz').write_bytes(gzip.compress(json.dumps(outcomes,sort_keys=True,allow_nan=False).encode(),mtime=0))
with zipfile.ZipFile(packet/'runtime_logs.zip','w',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
    for label,folder in [('initial',HERE),('numerical_extension',HERE/'numerical_extension')]:
        for f in sorted((folder/'logs').glob('*.log')):archive.write(f,label+'/'+f.name)
(packet/'.gitignore').write_text('__pycache__/\n');(packet/'.gitattributes').write_text('*.zip -diff -text\n*.gz -diff -text\n*.npz -diff -text\n')
(packet/'README.md').write_text('''# Twelve source-curated ModelSEED boundary reactions

This numerical pilot evaluates three fixed state-function estimators: full molecules,
the earlier1,4-only nicotinamide anchor, and separate1,2/1,4methyl cores sharing one
exact full oxidized reference per scaffold. Molecular structures were chosen from
the ChEBI cross-references already present in the source database. All18participating
source identities and exact proton rebasing were fixed before new calculations.

The initial14molecular attempts yielded9complete wrapper records,4quality refusals,
and one wrapper cache-key error. Triplet oxygen's existing complete record was
independently verified: the wrapper had omitted its spin=3cache-key field. No
oxygen calculation or original outcome was overwritten. The physical first-pass
count is therefore10accepted records and4quality refusals.

All4refusals reached a400-step curvature-recovery limit without satisfying its
unchanged0.001eV/Angstrom force criterion, with identity preserved. A separately
frozen numerical profile raised only that limit to1200steps and recovered3records;
full1,2-NADP remained unavailable. The model, solvent, Hessian/force acceptance
criteria, stochastic seeds and96-candidate ceiling were unchanged. Accepted
legacy64-ceiling records retain their owning source/settings; none is relabelled.

Primary availability is5/12,5/12,8/12; after the separate numerical extension it is
11/12,11/12,12/12. The complete available stoichiometric nullspace has one cycle per
arm in the augmented panel. All136augmented reversal/extent/atom-order/species-order
checks pass. These are targeted pilot results, not genome-scale coverage.

For NADH1,4-to1,2isomerization, the modeled energies are+12.7246kJ/mol(full),
-29.1694(earlier mixed approximation),+14.4842(two-isomer anchor). The latter two
approximations remain cycle consistent. Agreement within1.76kJ/mol of the full
model is an internal model comparison, not experimental accuracy. The local
approximation also imposes equal NAD/NADP isomer-core differences, and can miss
scaffold-specific effects. Sampling spreads exclude these physical-model errors.
No experimental labels are added, and no production policy is selected.

From the repository root, using its audit environment:

```sh
python benchmark/boundary_reference.py --cold-replay
```

The data audit reconstructs all raw partitions, declared protonation terms,
reaction sums and correlated sampling propagation with50-digit decimal arithmetic.
A cold process replays all12requests under all3arms and both availability profiles,
with quantum imports/network forbidden. Four stored fixed-geometry Hessians support
an independent QR/RRHO numerical check; this is not an all-minimum Hessian replay,
proof of exact stationarity, complete aqueous sampling or experimental validation.
Retained-geometry force residuals are reported and are not uniformly0.001eV/Angstrom.

All25accepted primitive records, initial/secondary outcomes, source code and logs
are included. Raw per-minimum thermal values are model outputs; independently
regenerating every quantum/Hessian calculation additionally requires the pinned
FairChem SDK, licensed UMA weights and xTB. Original component references, their
experimental-hydration water value and each producer identity remain explicit.
No model weights are redistributed. The original8GPU-hour common deadline was
retained across numerical profiles. Molecular-stage elapsed times exclude model
startup and are not a whole-method speedup benchmark.
''')
manifest=dict(schema=1,scope='Model-estimated boundary energies; no experimental accuracy or genome-scale coverage established.',
    files={str(f.relative_to(packet)):dict(bytes=f.stat().st_size,sha256=sha(f))
           for f in sorted(packet.rglob('*')) if f.is_file()})
(packet/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('Staged',len(catalog['records']),'molecular records; packet bytes',sum(v['bytes'] for v in manifest['files'].values()))
