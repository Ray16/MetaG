"""Independent CPU implementation of three frozen charged SCF fixtures."""
from pathlib import Path
import argparse,hashlib,json,math,os,time
import numpy as np
from common import HERE,read,sha,write,owner

parser=argparse.ArgumentParser();parser.add_argument('slot');args=parser.parse_args()
manifest=read(HERE/'cpu_verification_manifest.json');config=manifest['tasks'][args.slot]
assert sorted(os.sched_getaffinity(0))==config['cpus']
assert sha(__file__)==manifest['source_sha256']
assert sha(HERE/'parent_protocol.json')==manifest['parent_protocol_sha256']
assert sha(HERE/'scf_geometry_inputs.json')==manifest['SCF_inputs_sha256']
directory=HERE/'CPU_verification'/args.slot;write(directory/'owner.json',owner())
from pyscf import gto,dft,lib
from pyscf.solvent import smd
import pyscf
lib.num_threads(4)
protocol=read(HERE/'parent_protocol.json');geometry=read(HERE/'scf_geometry_inputs.json')['inputs'][args.slot]['geometry'];start=time.monotonic()
mol=gto.M(atom=list(zip(geometry['symbols'],geometry['positions_angstrom'])),unit='Angstrom',basis=protocol['basis'],charge=geometry['charge'],spin=0,verbose=4,output=str(directory/'SCF.log'),max_memory=64000)
assert np.linalg.eigvalsh(mol.intor('int1e_ovlp'))[0]>=protocol['overlap_minimum_eigenvalue']
def calculator():
    mf=dft.RKS(mol,xc=protocol['functional']).density_fit(auxbasis=protocol['auxbasis'])
    mf.grids.level=protocol['grid_level'];mf.nlcgrids.level=protocol['nlc_grid_level']
    mf.conv_tol=protocol['SCF_tolerance_Eh'];mf.conv_tol_grad=protocol['SCF_gradient_tolerance'];mf.max_cycle=protocol['max_cycle'];mf.chkfile=None
    assert mf.do_nlc();return mf
def stage(mf,**kwargs):
    E=float(mf.kernel(**kwargs));gradient=float(np.linalg.norm(mf.get_grad(mf.mo_coeff,mf.mo_occ,mf.get_fock())))
    assert mf.converged and math.isfinite(E) and mf.mo_coeff.shape[1]==mol.nao_nr()
    assert gradient<=protocol['stationary_gradient_maximum']
    return dict(energy_Eh=E,converged=True,orbital_gradient_norm=gradient,n_molecular_orbitals=mf.mo_coeff.shape[1],scf_summary={str(k):float(v) for k,v in mf.scf_summary.items()})
gas=calculator();result=dict(slot=args.slot,geometry=geometry,source_sha256=sha(__file__),pyscf_version=pyscf.__version__,owner=owner(),gas=stage(gas))
write(directory/'partial.json',result)
water=calculator();water.with_df=gas.with_df;water=water.SMD();water.with_solvent.solvent='water';water.with_solvent.sasa_ng=protocol['SMD_sasa_ng'];water.with_solvent.equilibrium_solvation=True
result['water']=stage(water,dm0=gas.make_rdm1());result['SMD_delta_Eh']=result['water']['energy_Eh']-result['gas']['energy_Eh'];result['CDS_Eh']=float(water.with_solvent.e_cds)
GPU=read(HERE/'points'/(args.slot+'.json'));assert sha(HERE/'points'/(args.slot+'.json'))==config['GPU_point_sha256']
differences={phase:abs(result[phase]['energy_Eh']-GPU[phase]['energy_Eh'])*protocol['Hartree_to_kj_per_mol'] for phase in ['gas','water']}
differences['SMD_increment']=abs(result['SMD_delta_Eh']-GPU['SMD_delta_Eh'])*protocol['Hartree_to_kj_per_mol']
result.update(differences_kj=differences,numerical_tolerance_kj=.05,passed=max(differences.values())<=.05,elapsed_seconds=time.monotonic()-start,scope='CPU/GPU numerical verification of charged fixtures; not experimental or ground-state accuracy.')
write(directory/'result.json',result);assert result['passed'],differences
print(json.dumps(dict(slot=args.slot,differences_kj=differences,passed=result['passed']),indent=2))
