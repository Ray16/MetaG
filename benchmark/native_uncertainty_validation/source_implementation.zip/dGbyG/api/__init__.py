import pandas as pd
import numpy as np
from tqdm import tqdm
from .utils import predict_standard_dGf_prime, predict_standard_dGr_prime
from .utils import predict_standard_dGr_prime_from_S, predict_standard_dGr_prime_from_rxn
from .utils import to_mol, to_mol_methods, check_pKa_json
from .Chemistry import Compound, Reaction




def predict_standard_dG_for_gem(GEM, compartments_conditions=None, cid_types=None, output='dGr'):
    '''
    Parameters
    ----------
    GEM: cobra.core.model.Model
        The GEM model
    compartments_conditions: dict, optional
        dict of conditions for each compartment
    cid_types: string or list of strings, optional
        list of compound ID types used for reading the structure of metabolites in order
    output: string, optional
        'dGr' or 'dGf' or 'both'

    Returns
    -------
    if output == 'dGr': pandas.DataFrame
        The standard free energy of reaction
    if output == 'dGf': pandas.DataFrame
        The standard formation free energy of metabolites
    if output == 'both': tuple of pandas.DataFrame
        (The standard formation free energy of metabolites, The standard free energy of reaction)
    '''

    # print compound ID types included in GEM
    IDs = set({})
    for met in GEM.metabolites:
        for key, value in met.annotation.items():
            IDs |= set([key])
    print(f'Compound ID types: {IDs}')

    # print compartments included in GEM
    print(f'Compartments: {GEM.compartments}')

    # try all compound ID types that can be recognized by dGbyG if cid_types is None
    if cid_types is None:
        cid_types = to_mol_methods().keys()
    elif isinstance(cid_types, str):
        cid_types = [cid_types]
    
    # read metabolites to construct compound objects
    for met in tqdm(GEM.metabolites, desc='Read metabolites structures'):
        mol = None
        for cid_type in cid_types:
            cid = met.annotation.get(cid_type, None)
            if cid is not None:
                if isinstance(cid, str): 
                    mol = to_mol(cid, cid_type)
                elif isinstance(cid, list) and len(cid) > 0:
                    mol = to_mol(cid[0], cid_type)
                else:
                    print(type(cid))
            
            # break at the first time a valid mol is found
            if mol is not None: break
        
        # add cid_type and compound object to the metabolite object
        met.cid_type = cid_type if mol else None
        met.compound = Compound(mol,)

        # add compartment condition to the compound object
        if compartments_conditions is not None:
            met.compound.condition = compartments_conditions[met.compartment]

        # add charge to the compound object
        if met.compound.mol is not None:
            met.compound.atom_bag['charge'] = met.charge

    # print the number of metabolites and the number of metabolites with a valid structure
    print(f'Total metabolites: {len(GEM.metabolites)}')
    print(f'Structured: {sum([met.compound.mol is not None for met in GEM.metabolites])}')

    # check if metabolites pKa is available
    smiles_list = [met.compound.Smiles for met in GEM.metabolites if met.compound.mol is not None]
    check_pKa_json(smiles_list, predict=True)
    
    # predict dGf
    dGf = []
    for met in tqdm(GEM.metabolites, desc='Metabolites dGf'):
        # predict transformed standard dGf prime
        dGf.append(met.compound.transformed_standard_dGf_prime)

    # convert to dataframe
    dGf_df = pd.DataFrame(dGf, index=[met.id for met in GEM.metabolites], columns=['standard_dGf_prime', 'SD'])

    # predict transformed standard dGr prime
    dGr = []
    for rxn in tqdm(GEM.reactions, desc='Reactions dGr'):
        if rxn.boundary:
            rxn.rxn = None
            dGr.append((np.nan, np.nan))
        elif rxn.boundary is False:
            rxn_dict = dict([(met.compound, coeff) for met, coeff in rxn.metabolites.items()])
            r = Reaction(rxn_dict, mol_type='compound')
            rxn.rxn = r
            dGr.append(r.transformed_standard_dGr_prime)
    
    # convert to dataframe
    dGr_df = pd.DataFrame(dGr, index=[rxn.id for rxn in GEM.reactions], columns=['standard_dGr_prime', 'SD'])

    have_dGr_num = dGr_df.loc[:,'standard_dGr_prime'].notna().sum()
    print(f'dGr coverage: {have_dGr_num}/{dGr_df.shape[0]}={have_dGr_num/dGr_df.shape[0]}')

    if output == 'dGr':
        return dGr_df
    elif output == 'dGf':
        return dGf_df
    else:
        return dGf_df, dGr_df
