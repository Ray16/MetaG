"""GPU-gate-owned controller with one bounded, isolated attempt per molecule."""
from pathlib import Path
import datetime
import os
import shutil
import signal
import subprocess
import sys
import time

from common import HERE,PYTHON,read,write,owner,environment,check_freeze

active=None;worker=None
def group_members(pgid):
    rows=[]
    for path in Path('/proc').glob('[0-9]*'):
        try:
            if path.stat().st_uid!=os.getuid() or os.getpgid(int(path.name))!=pgid:continue
            if (path/'stat').read_text().rsplit(')',1)[1].split()[0]=='Z':continue
            env=(path/'environ').read_bytes().split(b'\0')
            assert ('METAG_BOUNDARY_RUN='+read(HERE/'launch_manifest.json')['run_id']).encode() in env
            rows.append(int(path.name))
        except (OSError,ProcessLookupError):continue
    return rows
def cleanup(process):
    # This group was created solely for this input. Never release its claim
    # while an inherited xTB child can still write outputs.
    for sig,seconds in [(signal.SIGTERM,5),(signal.SIGKILL,3)]:
        if not group_members(process.pid):break
        os.killpg(process.pid,sig)
        until=time.monotonic()+seconds
        while group_members(process.pid) and time.monotonic()<until:time.sleep(.1)
    process.wait(timeout=5)
    assert not group_members(process.pid),'Owned predictor descendants still live'
def stop(signum,frame):
    if active is not None:cleanup(active)
    raise SystemExit(128+signum)
for sig in [signal.SIGTERM,signal.SIGINT]:signal.signal(sig,stop)


def run_child(slot,limit):
    global active
    env=environment();env['METAG_BOUNDARY_RUN']=read(HERE/'launch_manifest.json')['run_id']
    env['METAG_CACHE']=str(HERE/'cache'/slot)
    (HERE/'cache'/slot).mkdir(exist_ok=True)
    with (HERE/'logs'/(worker+'.'+slot+'.log')).open('x') as log:
        process=subprocess.Popen([PYTHON,str(HERE/'compute_one.py'),slot,worker],env=env,
            stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        active=process
        identity=dict(host=os.uname().nodename,pid=process.pid,process_group=process.pid,
            start_ticks=Path(f'/proc/{process.pid}/stat').read_text().rsplit(')',1)[1].split()[19])
        write(HERE/'workers'/(worker+'.predictor.json'),dict(slot=slot,**identity))
        timeout=False
        try:code=process.wait(timeout=limit)
        except subprocess.TimeoutExpired:timeout=True;code=None
        finally:cleanup(process);active=None
    return dict(exit_code=code,timed_out=timeout,owner=identity)


def main():
    global worker
    worker=sys.argv[1];check_freeze()
    manifest=read(HERE/'launch_manifest.json');allocation=next(a for a in manifest['allocations'] if a['worker']==worker)
    assert owner()['cpus']==allocation['cpus'] and os.uname().nodename==allocation['host']
    assert os.environ.get('CUDA_VISIBLE_DEVICES')
    assert all(os.environ[k]=='1' for k in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'])
    write(HERE/'workers'/(worker+'.owner.json'),owner())
    status=dict(state='initializing',worker=worker,owner=owner(),completed=[],refused=[],execution_failures=[])
    write(HERE/'workers'/(worker+'.status.json'),status)
    deadline=datetime.datetime.fromisoformat(manifest['deadline_utc']).timestamp()
    startup=run_child('startup',min(300,max(1,deadline-time.time())))
    if startup['exit_code']!=0 or startup['timed_out']:
        status.update(state='startup_failed_no_input_claimed',startup=startup)
        write(HERE/'workers'/(worker+'.status.json'),status);return
    assert read(HERE/'workers'/(worker+'.startup.json'))['status']=='passed'
    status.update(state='running',startup=startup);failures=0
    for task in read(HERE/'tasks.json'):
        slot=task['slot']
        if time.time()>=deadline:status['state']='common_deadline';break
        if (HERE/'results'/(slot+'.json')).exists():continue
        claim=HERE/'claims'/slot
        try:claim.mkdir()
        except FileExistsError:continue
        write(claim/'owner.json',dict(owner=owner(),run_id=manifest['run_id'],task=slot))
        try:
            if (HERE/'results'/(slot+'.json')).exists():continue
            started=time.monotonic()
            execution=run_child(slot,min(1800,max(1,deadline-time.time())))
            path=HERE/'results'/(slot+'.json')
            if execution['timed_out'] or not path.exists():
                partial=None
                if path.exists():
                    partial=HERE/'partial'/(slot+'.late_result.json');path.replace(partial)
                write(path,dict(slot=slot,request=task,status='execution_timeout' if execution['timed_out'] else 'predictor_execution_failure',
                    execution=execution,elapsed_seconds=time.monotonic()-started,partial=str(partial) if partial else None))
            result=read(path);result['controller_execution']=execution;write(path,result)
            if result['status']=='molecular_record_complete':status['completed'].append(slot);failures=0
            elif result['status']=='workflow_no_estimate':status['refused'].append(slot);failures=0
            else:status['execution_failures'].append(slot);failures+=1
            write(HERE/'workers'/(worker+'.status.json'),status)
            if failures>=3:status['state']='execution_failure_circuit_break';break
        finally:
            assert active is None
            shutil.rmtree(claim)
    if status['state']=='running':status['state']='queue_scan_complete'
    write(HERE/'workers'/(worker+'.status.json'),status)


if __name__=='__main__':main()
