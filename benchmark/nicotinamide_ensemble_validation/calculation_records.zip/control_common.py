"""Authenticate frozen study inputs and validate both reused and new SCF pairs."""
from pathlib import Path
import datetime
import hashlib
import json
import math
import os
import socket

HERE = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + f'.tmp-{os.getpid()}')
    temporary.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)
def owner():
    return dict(host=socket.gethostname(), pid=os.getpid(),
        start_ticks=Path(f'/proc/{os.getpid()}/stat').read_text().rsplit(')', 1)[1].split()[19],
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        cpu_affinity=sorted(os.sched_getaffinity(0)),
        managed_cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
        native_thread_caps={key:os.environ.get(key) for key in
            ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']})

def authenticate():
    manifest = json.loads((HERE / 'study_manifest.json').read_text())
    for name, digest in manifest['files_sha256'].items():
        assert sha(HERE / name) == digest, name
    inputs = json.loads((HERE / 'geometry_inputs.json').read_text())
    for family, source in inputs['source_records'].items():
        assert sha(source['path']) == source['sha256'], family
        minima = json.loads(Path(source['path']).read_text())['meta']['thermal']['ensemble']['validated_minima']
        items = [row for row in inputs['inputs'].values() if row['family'] == family]
        assert {row['minimum_index'] for row in items} == set(range(len(minima)))
        for row in items:
            point = minima[row['minimum_index']]
            assert row['geometry'] == point['geometry']
            assert row['reference_smiles'] == point['reference_smiles']
            assert all(point[key] == value for key, value in row['original_components_kj'].items())
    return inputs, json.loads((HERE / 'fixed_geometry_protocol.json').read_text())

NUMERICAL_KEYS = ['functional','basis','density_fitting','auxbasis','grid_level','nlc_grid_level',
    'SCF_tolerance_Eh','SCF_gradient_tolerance','stationary_gradient_maximum','max_cycle',
    'overlap_minimum_eigenvalue','max_memory_MB','solvent','SMD_sasa_ng','SMD_equilibrium_solvation',
    'Hartree_to_kj_per_mol','UMA_eV_to_kj_per_mol','pool_KT_kj']

def verify_point(slot, point, inputs, protocol, *, reused=False):
    item = inputs['inputs'][slot]
    assert point['passed'] is True and point['slot'] == slot
    assert point['geometry'] == item['geometry']
    assert point['n_AO'] == item['n_AO'] and point['n_electrons'] == item['n_electrons']
    assert point['overlap_minimum_eigenvalue'] >= protocol['overlap_minimum_eigenvalue']
    for name in ['gas','water']:
        state = point[name]
        assert state['converged'] is True and math.isfinite(state['energy_Eh'])
        assert state['n_molecular_orbitals'] == item['n_AO']
        assert 0 <= state['orbital_gradient_norm'] <= protocol['stationary_gradient_maximum']
        summary = state['scf_summary']
        assert abs(summary['e2'] - summary['coul'] - summary['exc']) < 1e-8
        terms = [summary[key] for key in ['e1','e2','nuc']]
        if name == 'water':
            terms += [summary['e_solvent'], summary['e_cds']]
            assert abs(summary['e_cds'] - point['CDS_Eh']) < 1e-12
        assert abs(math.fsum(terms) - state['energy_Eh']) < 1e-8
    assert abs(point['SMD_delta_Eh'] - point['water']['energy_Eh'] + point['gas']['energy_Eh']) < 1e-10
    assert point['surface_discretization_method'] == 'SWIG'
    if reused:
        receipts = json.loads((HERE / 'reuse_receipt.json').read_text())
        receipt = receipts[slot]
        assert sha(HERE / receipt['point']) == receipt['sha256']
        assert point['source_sha256'] == receipt['original_point_source_sha256']
        assert point['protocol_sha256'] == receipt['original_protocol_sha256']
        assert point['input_sha256'] == receipt['original_input_sha256']
        previous = json.loads((HERE / 'reused_protocol.json').read_text())
        assert all(previous[key] == protocol[key] for key in NUMERICAL_KEYS)
    else:
        assert point['source_sha256'] == sha(HERE / 'reference_point.py')
        assert point['protocol_sha256'] == sha(HERE / 'fixed_geometry_protocol.json')
        assert point['input_sha256'] == sha(HERE / 'geometry_inputs.json')
    receipt = next(iter(json.loads((HERE / 'reuse_receipt.json').read_text()).values()))
    assert point['versions'] == json.loads((HERE / receipt['point']).read_text())['versions']
    return point

def load_point(slot, inputs, protocol):
    reuse = json.loads((HERE / 'reuse_receipt.json').read_text())
    reused = slot in reuse
    path = HERE / reuse[slot]['point'] if reused else HERE / 'points' / (slot + '.json')
    if not path.exists():
        return None
    return verify_point(slot, json.loads(path.read_text()), inputs, protocol, reused=reused)
