from pathlib import Path
import datetime,hashlib,json,os

HERE=Path(__file__).resolve().parent
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,value):
    path=Path(path);temporary=path.with_name(path.name+f'.tmp-{os.getpid()}')
    temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)
def owner():
    return dict(host=os.uname().nodename,pid=os.getpid(),
        start_ticks=Path(f'/proc/{os.getpid()}/stat').read_text().rsplit(')',1)[1].split()[19],
        utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cpu_affinity=sorted(os.sched_getaffinity(0)),
        managed_cuda_visible_devices=os.environ.get('CUDA_VISIBLE_DEVICES'),
        native_thread_caps={k:os.environ.get(k) for k in ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']})
def authenticate():
    for name,digest in read(HERE/'freeze.json')['files_sha256'].items():assert sha(HERE/name)==digest,name
    protocol=read(HERE/'protocol.json');base=Path(protocol['source_engine']).parents[1]
    for name,digest in read(HERE/'dependency_sources.json')['files_sha256'].items():assert sha(base/name)==digest,name
    assert sha(protocol['xtb'])==protocol['xtb_sha256']
    return read(HERE/'geometry_inputs.json'),protocol
