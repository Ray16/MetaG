"""Capture four fixed-geometry Hessians for a separate CPU QR/RRHO audit."""
from pathlib import Path
import json
import os
import sys
import time

from common import HERE,read,write,sha,check_freeze

assert os.uname().nodename=='lambda13' and sorted(os.sched_getaffinity(0))==[372,373]
assert os.environ.get('CUDA_VISIBLE_DEVICES')
check_freeze();control=read(HERE/'curvature_control_protocol.json')
assert control['source_sha256']==sha(Path(__file__))
import numpy as np
import torch
torch.set_num_threads(1);torch.set_num_interop_threads(1)
from ase import Atoms
from metag.energetics.uma import load_uma,_predict
from metag.energetics.thermal import uma_hessian_autograd,gibbs_corr_from_hessian
from metag.symmetry import geometry_and_sigma

pu=load_uma('uma-s-1p2p1',profile='nitro')
out=HERE/'curvature_controls';out.mkdir(exist_ok=False)
for row in control['points']:
    started=time.monotonic();g=row['geometry']
    atoms=Atoms(symbols=g['symbols'],positions=g['positions_angstrom'],info=dict(charge=g['charge'],spin=g['spin_multiplicity']))
    energy,forces,_=_predict(pu,[atoms]);electronic=float(energy.detach().cpu().numpy()[0])*96.485
    force=forces.detach().cpu().numpy()
    H=uma_hessian_autograd(pu,atoms,rows=8)
    geometry,symmetry,_=geometry_and_sigma(g['symbols'],g['positions_angstrom'])
    assert geometry=='nonlinear' and symmetry==1
    correction,info=gibbs_corr_from_hessian(atoms,H,electronic/96.485,geometry,symmetry,
        spin=g['spin_multiplicity'],return_info=True)
    info.pop('_imag_vecs',None)
    matrix=out/(row['slot']+'.npz');np.savez_compressed(matrix,hessian_eV_A2=H,forces_eV_A=force)
    write(out/(row['slot']+'.json'),dict(slot=row['slot'],source_raw_sha256=row['source_raw_sha256'],
        geometry=g,matrix_sha256=sha(matrix),electronic_kj=electronic,
        electronic_difference_kj=electronic-row['electronic_kj'],
        thermal_kj=correction,thermal_difference_kj=correction-row['thermal_kj'],native_diagnostics=info,
        expected_thermal_kj=row['thermal_kj'],symmetrynumber=symmetry,geometry_kind=geometry,
        force_max_eV_A=float(np.linalg.norm(force,axis=1).max()),
        elapsed_seconds=time.monotonic()-started,execution=pu.execution_snapshot()))
    print('CONTROL COMPLETE',row['slot'],correction-row['thermal_kj'],flush=True)
