"""One gate-owned CUDA child at a time; shared resumable, single-attempt queue."""
import argparse
import datetime
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time
import traceback
from control_common import HERE, authenticate, load_point, owner, verify_point, write

parser = argparse.ArgumentParser()
parser.add_argument('worker')
args = parser.parse_args()
inputs, protocol = authenticate()
launch = json.loads((HERE / 'launch_manifest.json').read_text())
assignment = launch['workers'][args.worker]
assert os.uname().nodename == assignment['host']
assert sorted(os.sched_getaffinity(0)) == assignment['cpus']
assert os.environ.get('CUDA_VISIBLE_DEVICES') is not None
assert all(os.environ.get(key) == '1' for key in
    ['OMP_NUM_THREADS','OMP_THREAD_LIMIT','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'])
deadline = datetime.datetime.fromisoformat(launch['deadline_utc'])
worker_dir = HERE / 'workers' / args.worker
worker_dir.mkdir(exist_ok=False)
write(worker_dir / 'owner.json', owner())
child = None

def seconds_left():
    return (deadline - datetime.datetime.now(datetime.timezone.utc)).total_seconds()

def join_child():
    global child
    if child is not None:
        if child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try: child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL); child.wait()
        child = None

def stop(signum, frame):
    join_child()
    raise SystemExit(128 + signum)

signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)

def run(slot, output, log):
    global child
    output.mkdir(parents=True, exist_ok=True)
    environment = dict(os.environ, METAG_POINT_OUTPUT=str(output))
    argv = [launch['dft_python'], str(HERE / 'reference_point.py'), slot]
    with log.open('x') as stream:
        child = subprocess.Popen(argv, env=environment, stdin=subprocess.DEVNULL,
            stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        write(log.with_suffix('.owner.json'), dict(host=os.uname().nodename, pid=child.pid,
            start_ticks=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19],
            cpu_affinity=sorted(os.sched_getaffinity(child.pid)), argv=argv))
        try:
            code = child.wait(timeout=max(1, min(seconds_left(), protocol['point_timeout_seconds'])))
        except BaseException:
            join_child(); raise
        child = None
        assert code == 0, f'{slot}: child returned {code}'
    return json.loads((output / (slot + '.json')).read_text())

status = dict(state='startup', worker=args.worker, completed=[], failures=[], claimed=None)
try:
    # Both the small CPU/GPU fixture and one large reused point must reproduce
    # before this worker may claim any new scientific geometry.
    bridge_dir = HERE / 'bridges' / args.worker
    smoke = run('smoke', bridge_dir, worker_dir / 'smoke.console.log')
    assert smoke['passed'] and max(smoke['CPU_GPU_absolute_difference_kj'].values()) <= protocol['numerical_smoke_tolerance_kj']
    bridge_slot = assignment['architecture_bridge_slot']
    actual = run(bridge_slot, bridge_dir, worker_dir / 'architecture_bridge.console.log')
    verify_point(bridge_slot, actual, inputs, protocol)
    prior = load_point(bridge_slot, inputs, protocol)
    deltas = {name:abs(actual[name]['energy_Eh'] - prior[name]['energy_Eh']) * protocol['Hartree_to_kj_per_mol'] for name in ['gas','water']}
    assert max(deltas.values()) <= protocol['architecture_bridge_tolerance_kj'], deltas
    write(worker_dir / 'architecture_bridge.json', dict(passed=True, slot=bridge_slot,
        absolute_energy_difference_kj=deltas, scope='Architecture/numerical reproduction; not physical or experimental accuracy.'))
    replay = json.loads((HERE / 'uma_replay.json').read_text())
    assert replay['passed'] and set(replay['rows']) == set(inputs['inputs'])
    failures = 0
    status['state'] = 'running'
    for slot in launch['queue_order']:
        if load_point(slot, inputs, protocol) is not None:
            continue
        if (HERE / 'attempts' / slot).exists():
            continue
        if seconds_left() <= 0:
            status['state'] = 'runtime_budget_exhausted'; break
        assert max(os.getloadavg()) + len(assignment['cpus']) <= os.cpu_count()
        available = int(Path('/proc/meminfo').read_text().split('MemAvailable:')[1].split()[0]) * 1024
        assert available >= 128 * 1024**3, 'Insufficient available RAM; no geometry attempt consumed'
        assert shutil.disk_usage('/tmp').free >= 50 * 1024**3
        claim = HERE / 'claims' / slot
        try: claim.mkdir()
        except FileExistsError: continue
        write(claim / 'owner.json', owner())
        status['claimed'] = slot
        write(worker_dir / 'status.json', status)
        attempt = None
        try:
            if load_point(slot, inputs, protocol) is not None:
                continue
            attempt = HERE / 'attempts' / slot
            try: attempt.mkdir()
            except FileExistsError: continue
            write(attempt / 'owner.json', owner())
            print(f'POINT START {slot}', flush=True)
            result = run(slot, HERE / 'points', attempt / 'console.log')
            verify_point(slot, result, inputs, protocol)
            status['completed'].append(slot); failures = 0
            print(f'POINT COMPLETE {slot}', flush=True)
        except Exception as error:
            record = dict(slot=slot, error=str(error), traceback=traceback.format_exc())
            status['failures'].append(record)
            write((attempt if attempt is not None else worker_dir) / (slot + '.failure.json'), record)
            failures += 1
            if failures >= protocol['consecutive_actual_failure_limit']:
                status['state'] = 'consecutive_failure_circuit_break'; break
            if seconds_left() <= 0:
                status['state'] = 'runtime_budget_exhausted'; break
            time.sleep(10)
        finally:
            join_child()
            shutil.rmtree(claim)
            status['claimed'] = None
            write(worker_dir / 'status.json', status)
    else:
        status['state'] = 'no_claimable_pending_slots'
except BaseException as error:
    status.update(state='stopped', error=str(error), traceback=traceback.format_exc())
    raise
finally:
    join_child()
    write(worker_dir / 'status.json', status)
