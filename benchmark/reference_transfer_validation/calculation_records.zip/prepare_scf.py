"""Bind every retained geometry to an exact AO/electron-count SCF request."""
import json
from common import HERE,authenticate,read,sha,write

inputs,protocol=authenticate()
status=read(HERE/'molecular_status.json');assert status['state']=='complete'
assert len(status['optimized'])==48 and not status['optimizer_failures'] and not status['curvature_failures']
from pyscf import gto,lib
lib.num_threads(1)
parent=read(HERE/'parent_protocol.json');data={};sources={}
for slot in status['retained']:
    path=HERE/'curvature'/slot/'result.json';row=read(path);assert row['passed']
    geometry=dict(symbols=row['symbols'],positions_angstrom=row['positions_A'],charge=row['charge'],spin_multiplicity=1)
    mol=gto.M(atom=list(zip(geometry['symbols'],geometry['positions_angstrom'])),unit='Angstrom',basis=parent['basis'],charge=row['charge'],spin=0,verbose=0)
    data[slot]=dict(geometry=geometry,n_AO=mol.nao_nr(),n_electrons=mol.nelectron)
    sources[str(path.relative_to(HERE))]=sha(path)
write(HERE/'scf_geometry_inputs.json',dict(inputs=data))
write(HERE/'scf_preparation_receipt.json',dict(inputs_sha256=sha(HERE/'scf_geometry_inputs.json'),source_result_sha256=sources,n_geometries=len(data),selection='Every retained geometry under the frozen clustering and quality gates; no experimental target selection.'))
print(json.dumps(dict(n_SCF_pairs=len(data)),indent=2))
