"""Freeze the complete retained nicotinamide pools before additional QM work."""
from pathlib import Path
from collections import Counter
import ast
import datetime
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
OLD = HERE.parents[1] / 'benchmark/nicotinamide_validation'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

assert not (HERE / 'geometry_inputs.json').exists()
for name in ['raw_records', 'reused_points', 'points', 'claims', 'attempts', 'workers', 'bridges']:
    (HERE / name).mkdir(exist_ok=False)
old_inputs = json.loads((OLD / 'geometry_inputs.json').read_text())
old_protocol = json.loads((OLD / 'fixed_geometry_protocol.json').read_text())
protocol = dict(old_protocol)
protocol.update(
    scope='Complete retained fixed-geometry nicotinamide ensemble intervention; no experimental-accuracy or production-policy claim.',
    geometry_rule='All 3/4 core and 41/55 full-cofactor validated minima, each counted once as in the original raw ensemble. No energy or label-based exclusion.',
    runtime_budget_seconds=18000,
    total_gpu_hour_ceiling=10,
    maximum_workers=2,
    point_timeout_seconds=1800,
    architecture_bridge_tolerance_kj=0.05,
    missing_point_policy='No complete-ensemble endpoint if any required point fails. Preserve all failed/partial results; do not substitute the best subset.',
    primary_endpoint='Full-pool minus old restricted-pool DFT/SMD atom- and charge-balanced full/core exchange, in kJ/mol.',
    descriptive_sensitivity_threshold_kj=5.0,
    sensitivity_threshold_scope='Magnitude of a modeling intervention, not an experimental acceptance criterion or production promotion gate.',
    secondary_endpoints=['All four electronic/solvent arms with full versus restricted pools', 'Family conformer weights and effective population sizes', 'Electronic, solvent, original thermal and configurational contributions', 'SCF/resource failures and complete-pool coverage'],
    experimental_targets_consulted=False,
    production_reference_policy_adopted=False,
)
write(HERE / 'fixed_geometry_protocol.json', protocol)
shutil.copyfile(OLD / 'fixed_geometry_protocol.json', HERE / 'reused_protocol.json')
shutil.copyfile(OLD / 'reference_point.py', HERE / 'reference_point_original.py')
shutil.copyfile(OLD / 'cpu_smoke.py', HERE / 'cpu_smoke.py')
shutil.copyfile(OLD / 'cpu_water_smoke.json', HERE / 'cpu_water_smoke.json')
shutil.copyfile(OLD / 'audit_nicotinamide_control.py', HERE / 'original_audit.py')

# Only the output destination is adapted. The SCF construction, tolerances and
# post-calculation gates remain exactly the earlier executable implementation.
original = (OLD / 'reference_point.py').read_text()
modified = original.replace('import argparse\n', 'import argparse\nimport os\nfrom pathlib import Path\n', 1).replace(
    "output = HERE/'points'", "output = Path(os.environ.get('METAG_POINT_OUTPUT', str(HERE/'points')))")
# Check the explicit inverse text transform as well as parsing before freezing.
assert modified.replace('import argparse\nimport os\nfrom pathlib import Path\n', 'import argparse\n', 1).replace(
    "output = Path(os.environ.get('METAG_POINT_OUTPUT', str(HERE/'points')))", "output = HERE/'points'", 1) == original
ast.parse(modified)
(HERE / 'reference_point.py').write_text(modified)
inputs = {}; sources = {}; reuse = {}; family_counts = {}
for family, source in old_inputs['source_records'].items():
    source_path = Path(source['path'])
    assert sha(source_path) == source['sha256']
    destination = HERE / 'raw_records' / source_path.name
    shutil.copyfile(source_path, destination)
    sources[family] = dict(path=str(destination), sha256=sha(destination), original_path=str(source_path))
    raw = json.loads(destination.read_text())
    minima = raw['meta']['thermal']['ensemble']['validated_minima']
    template = next(v for v in old_inputs['inputs'].values() if v['family'] == family)
    family_counts[family] = len(minima)
    for i, minimum in enumerate(minima):
        geometry = minimum['geometry']
        assert Counter(geometry['symbols']) == Counter(template['geometry']['symbols'])
        assert geometry['charge'] == template['geometry']['charge']
        assert geometry['spin_multiplicity'] == 1
        detached = dict(geometry); digest = detached.pop('sha256')
        assert hashlib.sha256(json.dumps(detached, sort_keys=True, allow_nan=False).encode()).hexdigest() == digest
        slot = f'{family}__minimum_{i:03d}'
        item = dict(family=family, minimum_index=i, geometry=geometry,
            reference_smiles=minimum['reference_smiles'], n_AO=template['n_AO'], n_electrons=template['n_electrons'],
            original_components_kj={k:minimum[k] for k in ['electronic_kj','solvation_kj','thermal_kj','total_kj']})
        inputs[slot] = item
        if slot in old_inputs['inputs']:
            assert item == old_inputs['inputs'][slot]
            for suffix in ['.json', '.gas.json', '.scf.log']:
                path = OLD / 'points' / (slot + suffix)
                shutil.copyfile(path, HERE / 'reused_points' / path.name)
            reuse[slot] = dict(point='reused_points/'+slot+'.json', sha256=sha(HERE/'reused_points'/(slot+'.json')),
                original_input_sha256=sha(OLD/'geometry_inputs.json'),
                original_protocol_sha256=sha(OLD/'fixed_geometry_protocol.json'),
                original_point_source_sha256=sha(OLD/'reference_point.py'))
assert family_counts == dict(full_ox=41, full_red=55, core_ox=3, core_red=4)
assert len(inputs) == 103 and len(reuse) == 9
write(HERE/'geometry_inputs.json', dict(inputs=inputs, source_records=sources, family_counts=family_counts))
write(HERE/'reuse_receipt.json', reuse)
write(HERE/'preparation_receipt.json', dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    n_geometries=len(inputs), n_preexisting_points=len(reuse), n_new_required_points=len(inputs)-len(reuse),
    family_counts=family_counts, experimental_targets_consulted=False,
    original_point_source_sha256=sha(HERE/'reference_point_original.py'),
    adapted_point_source_sha256=sha(HERE/'reference_point.py'),
    point_adaptation='Only import os/Path and choose durable output directory; exact inverse text transform checked.',
    numerical_protocol_sha256=sha(HERE/'fixed_geometry_protocol.json')))
print(json.dumps(dict(n_geometries=len(inputs), reused=len(reuse), new=len(inputs)-len(reuse))))
