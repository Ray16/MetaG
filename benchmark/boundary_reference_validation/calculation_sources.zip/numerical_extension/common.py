from pathlib import Path
import datetime
import hashlib
import json
import os

HERE=Path(__file__).resolve().parent
ROOT=Path('/nfs/lambda_stor_01/homes/rzhu/ModelSEED_FAISS/thermodynamic_calc/MetaG')
PYTHON=str(HERE.parent/'job_env/bin/python')
SDK=ROOT/'analysis/nicotinamide_reference_control_20261104_01/fairchem_sdk/src'
GATE='/nfs/lambda_stor_01/homes/rzhu/bin/gpu_reserve'
XTB='/nfs/lambda_stor_01/homes/rzhu/miniforge3/envs/xtb/bin/xtb'
LIB='/nfs/lambda_stor_01/homes/rzhu/miniforge3/envs/redox/lib:/nfs/lambda_stor_01/homes/rzhu/miniforge3/envs/xtb/lib'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(path,value):
    path=Path(path);temp=path.with_name(path.name+'.'+str(os.getpid())+'.tmp')
    temp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temp.replace(path)
def owner():
    return dict(host=os.uname().nodename,pid=os.getpid(),
        start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19],
        cpus=sorted(os.sched_getaffinity(0)))
def environment():
    return dict(os.environ,PYTHONPATH=os.pathsep.join([str(HERE/'owned_source/src'),str(SDK)]),
        PYTHONDONTWRITEBYTECODE='1',HF_HUB_OFFLINE='1',FAIRCHEM_CACHE_DIR='/nfs/lambda_stor_01/homes/rzhu/.cache/fairchem',XTB_BIN=XTB,LD_LIBRARY_PATH=LIB,
        OMP_NUM_THREADS='1',OMP_THREAD_LIMIT='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1',
        METAG_XTB_WORKERS='1',UMA_RUNTIME_PROFILE='nitro',UMA_ENERGY_CHUNK='64',UMA_FIRE_CHUNK='64',UMA_HESS_ROWS='8')
def check_freeze():
    freeze=read(HERE/'freeze.json')
    for relative,digest in freeze['files_sha256'].items():assert sha(HERE/relative)==digest,relative
    for relative,digest in freeze['sdk_files_sha256'].items():assert sha(SDK/relative)==digest,relative
    assert sha(XTB)==freeze['xtb_sha256']
    return freeze
