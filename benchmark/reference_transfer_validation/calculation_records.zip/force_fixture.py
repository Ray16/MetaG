"""Conservative solvent force checks on all six initial chemical states."""
import gzip,json
import numpy as np
from common import HERE,authenticate,write,owner
from solvent_gradient import evaluate

def run():
    inputs,protocol=authenticate();rng=np.random.default_rng(1729);rows={}
    with gzip.open(HERE/'force_fixture.raw.jsonl.gz','xt') as raw:
        for key,item in inputs['species'].items():
            xyz=np.array(item['poses'][0]);d=rng.normal(size=xyz.shape);d/=np.linalg.norm(d)
            baseline=evaluate(item['symbols'],xyz,item['charge'],protocol,raw)
            analytic=-float(np.sum(baseline['forces_eV_A']*d));values=[]
            for step in protocol['solvent_Hessian_steps_A']:
                plus=evaluate(item['symbols'],xyz+step*d,item['charge'],protocol,raw)
                minus=evaluate(item['symbols'],xyz-step*d,item['charge'],protocol,raw)
                finite=(plus['energy_eV']-minus['energy_eV'])/(2*step)
                values.append(dict(step_A=step,finite_derivative_eV_A=finite,analytic_derivative_eV_A=analytic,difference_eV_A=finite-analytic))
            passed=max(abs(v['difference_eV_A']) for v in values)<=protocol['force_fixture_tolerance_eV_A']
            rows[key]=dict(passed=passed,derivative_checks=values)
            write(HERE/'force_fixture.json',dict(states=rows,complete=False,owner=owner()))
            assert passed,(key,values)
    report=dict(passed=True,complete=True,states=rows,owner=owner(),scope='Numerical energy/force agreement; no thermodynamic accuracy claim.')
    write(HERE/'force_fixture.json',report)

if __name__=='__main__':run()
