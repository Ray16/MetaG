"""Launch three bounded, disjoint CPU checks after charged-state discrepancies."""
from pathlib import Path
import datetime,json,os,signal,subprocess,sys,time
from common import HERE,read,sha,write,owner

assert not (HERE/'cpu_verification_manifest.json').exists(),'Inspect original handles before any restart'
assert max(os.getloadavg())+12<=os.cpu_count()
available=int(next(line.split()[1] for line in Path('/proc/meminfo').read_text().splitlines() if line.startswith('MemAvailable:')))*1024
assert available>=200*1024**3
root=HERE/'CPU_verification';root.mkdir()
python='/nfs/lambda_stor_01/homes/rzhu/miniforge3/envs/redox/bin/python'
index=read(HERE/'retained_geometry_index.json');species=['acetate_ion','mercaptoethanol_ion','ethanolamine_ion'];tasks={}
for family,cpus in zip(species,[list(range(32,36)),list(range(36,40)),list(range(40,44))]):
    # The first retained gas geometry was selected by the original optimized
    # model energy before parent-DFT outcomes, not by the numerical discrepancy.
    slot=index[family+'|gas'][0];tasks[slot]=dict(cpus=cpus,GPU_point_sha256=sha(HERE/'points'/(slot+'.json')))
for path in Path('/proc').glob('[0-9]*'):
    try:
        if path.stat().st_uid!=os.getuid():continue
        argv=(path/'cmdline').read_bytes().decode().split('\0')
        if not argv or 'python' not in Path(argv[0]).name:continue
        affinity=os.sched_getaffinity(int(path.name))
        assert len(affinity)>=16 or not (affinity&set(range(32,44))),f'CPU overlap with{path.name}'
    except (FileNotFoundError,ProcessLookupError,PermissionError,UnicodeError):continue
manifest=dict(utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tasks=tasks,source_sha256=sha(HERE/'cpu_charged_point.py'),parent_protocol_sha256=sha(HERE/'parent_protocol.json'),SCF_inputs_sha256=sha(HERE/'scf_geometry_inputs.json'),numerical_tolerance_kj=.05,per_task_budget_seconds=1800,scope='Targeted CPU/GPU charged-fixture verification prompted by large physical errors; original scientific calculation outputs and primary analysis unchanged.')
write(HERE/'cpu_verification_manifest.json',manifest);write(HERE/'cpu_verification_controller_owner.json',owner());children=[]
env=dict(os.environ,OMP_NUM_THREADS='4',OMP_THREAD_LIMIT='4',MKL_NUM_THREADS='4',OPENBLAS_NUM_THREADS='4',NUMEXPR_NUM_THREADS='4',PYTHONDONTWRITEBYTECODE='1')
def terminate():
    for child in children:
        if child.poll() is None:
            os.killpg(child.pid,signal.SIGTERM)
            try:child.wait(timeout=15)
            except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
def stop(signum,frame):terminate();raise SystemExit(128+signum)
signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
started=time.monotonic()
try:
    for slot,config in tasks.items():
        d=root/slot;d.mkdir()
        with (d/'console.log').open('x') as log:
            child=subprocess.Popen(['/usr/bin/taskset','-c',','.join(map(str,config['cpus'])),python,str(HERE/'cpu_charged_point.py'),slot],env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        children.append(child);write(d/'launcher_owner.json',dict(pid=child.pid,host=os.uname().nodename,start_ticks=Path(f'/proc/{child.pid}/stat').read_text().rsplit(')',1)[1].split()[19]))
    codes=[child.wait(timeout=max(1,1800-(time.monotonic()-started))) for child in children]
    assert codes==[0,0,0],codes
    assert all(read(root/slot/'result.json')['passed'] for slot in tasks)
    write(HERE/'cpu_verification_summary.json',dict(passed=True,tasks={slot:read(root/slot/'result.json')['differences_kj'] for slot in tasks},scope=manifest['scope']))
finally:terminate()
