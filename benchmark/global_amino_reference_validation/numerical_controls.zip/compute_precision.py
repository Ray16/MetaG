"""Resolve one saved strong mode with stricter force convergence, preserving all arms."""
from pathlib import Path
import hashlib
import json
import os
import time
import numpy as np
import torch
from ase import Atoms
from rdkit import Chem

HERE=Path(__file__).resolve().parent
OUT=HERE/'precision_control'
read=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,value):
    target=OUT/name;temp=target.with_suffix(target.suffix+'.tmp')
    temp.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temp.replace(target)

def main():
    manifest=read(OUT/'launch_manifest.json');p=read(OUT/'protocol.json');g=read(OUT/'input.json')
    for n,d in manifest['files_sha256'].items():assert sha(HERE/n)==d,n
    assert sha(OUT/'input.json')==p['input_sha256']
    assert sorted(os.sched_getaffinity(0))==manifest['cpus']
    write('predictor_owner.json',dict(pid=os.getpid(),host=os.uname().nodename,
        start_ticks=Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]))
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    from metag.energetics.uma import load_uma,batched_fire,_predict
    from metag.energetics.thermal import uma_gibbs_corr,dgsolv
    from metag.energetics.backend import UMABackend
    from metag.energetics.conformers import bond_graph,same_connectivity,same_stereochemistry
    from metag.settings import Settings
    pu=load_uma('uma-s-1p2p1',profile='nitro')
    backend=UMABackend(pu,Settings(**read(HERE/'raw_settings.json')),log=lambda *_:None)
    assert backend.producer==read(HERE/'catalog.json')['producer']
    base=Atoms(g['symbols'],positions=g['positions_angstrom'],info={'charge':g['charge'],'spin':g['spin_multiplicity']})
    template=Chem.AddHs(Chem.MolFromSmiles(g['reference_smiles']));graph=bond_graph(template)
    def score(atoms,slot,converged,fmax_required):
        energy,force,_=_predict(pu,[atoms]);energy=float(energy.cpu().numpy()[0]);force=force.cpu().numpy().astype(float)
        corr,info=uma_gibbs_corr(pu,g['symbols'],atoms.positions,g['charge'],spin=g['spin_multiplicity'],
            return_info=True,hessian='autograd',imag_as_soft=False)
        modes=info.pop('_imag_vecs')
        identity=same_connectivity(atoms,graph) and same_stereochemistry(atoms,template)
        maximum=float(np.linalg.norm(force,axis=1).max())
        solvent=dgsolv(g['symbols'],atoms.positions,g['charge'],g['spin_multiplicity'])
        accepted=bool(identity and converged and maximum<=fmax_required and info['n_imag']==0
            and corr is not None and np.isfinite(corr) and solvent is not None and np.isfinite(solvent))
        result=dict(slot=slot,positions_angstrom=atoms.positions.tolist(),converged=bool(converged),
            identity_preserved=bool(identity),max_force_eV_A=maximum,required_force_eV_A=fmax_required,
            electronic_kj=energy*96.485,solvation_kj=solvent,thermal_kj=corr,
            n_imag=int(info['n_imag']),max_imag_cm=float(info['max_imag_cm']),strict_endpoint_accepted=accepted,
            endpoint_total_kj=(energy*96.485+solvent+corr if accepted else None))
        write(slot+'.json',result)
        print('ENDPOINT',slot,'force',maximum,'imag',info['max_imag_cm'],'accepted',accepted,flush=True)
        return result,modes
    first,modes=score(base,'original_endpoint',True,.01)
    assert first['n_imag']>0 and len(modes)>0
    mode=np.asarray(modes[0],float)
    inputs=[base.copy(),Atoms(g['symbols'],positions=base.positions+p['mode_displacement_A']*mode,
        info=base.info.copy()),Atoms(g['symbols'],positions=base.positions-p['mode_displacement_A']*mode,
        info=base.info.copy())]
    started=time.monotonic();outputs=[]
    for slot,initial in zip(p['arms'][1:],inputs):
        relaxed,_,flags=batched_fire(pu,[initial],fmax=p['fmax_eV_A'],steps=p['steps'],
            return_converged=True,label=slot,_reference_only=True)
        result,_=score(relaxed[0],slot,bool(flags[0]),p['fmax_eV_A'])
        outputs.append(result)
    write('summary.json',dict(arms=p['arms'],accepted=[r['slot'] for r in outputs if r['strict_endpoint_accepted']],
        elapsed_seconds=time.monotonic()-started,producer=backend.producer,
        scope=p['scope'],raw_cache_replaced=False,complete_molecular_estimate=False))

if __name__=='__main__':main()
