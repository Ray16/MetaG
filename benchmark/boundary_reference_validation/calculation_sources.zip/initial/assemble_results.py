"""Reassemble all fixed boundary requests and retain every declared arm/refusal."""
from pathlib import Path
from collections import Counter
from fractions import Fraction
import argparse
import copy
import hashlib
import json
import math
import sys
import zipfile

from common import HERE,ROOT,read,write,sha,check_freeze
sys.path[:0]=[str(HERE/'owned_source/src'),str(HERE/'owned_source')]
from rdkit import Chem
import sympy as sp
from metag.settings import Settings
from metag.state_function import StateFunctionEstimator
from metag.constants import G_HPLUS,STD_STATE_KJ
from metag.chem import is_water
from benchmark.anchored_nicotinamide import AnchoredNicotinamideEstimator
from benchmark.anchored_nicotinamide_regio import RegioAnchoredEstimator

class MissingMolecule(RuntimeError):pass


def component_values(raw):
    minima=raw['meta']['thermal']['ensemble']['validated_minima']
    assert minima and raw['meta']['thermal']['ensemble']['n_reference_thermal_approximation']==0
    totals=[m['electronic_kj']+m['solvation_kj']+m['thermal_kj'] for m in minima]
    low=min(totals);weights=[math.exp(-(g-low)/2.4789) for g in totals];normalization=math.fsum(weights)
    populations=[w/normalization for w in weights]
    result={kind:math.fsum(p*m[field] for p,m in zip(populations,minima))
            for kind,field in [('electronic','electronic_kj'),('solvation','solvation_kj'),('thermal','thermal_kj')]}
    result['conformer_mixing']=2.4789*math.fsum(p*math.log(p) for p in populations if p>0)
    assert abs(math.fsum(result.values())-raw['G'])<1e-7
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--include-numerical-extension',action='store_true')
    args=parser.parse_args()
    check_freeze()
    tasks=read(HERE/'tasks.json')
    assert all((HERE/'results'/(t['slot']+'.json')).exists() for t in tasks),'All14input attempts must be terminal before the primary assembly'
    assert not list((HERE/'claims').iterdir()),'Do not assemble while a predictor can still change a record'
    secondary={}
    if args.include_numerical_extension:
        extra=HERE/'numerical_extension'
        assert not list((extra/'claims').iterdir())
        for task in read(extra/'tasks.json'):
            path=extra/'results'/(task['slot']+'.json')
            assert path.exists(),'Every declared secondary input must be terminal'
            original=read(HERE/'results'/(task['slot']+'.json'))
            assert original['status']=='workflow_no_estimate'
            assert sha(HERE/'results'/(task['slot']+'.json'))==task['initial_result_sha256']
            secondary[task['slot']]=read(path)
    output=HERE/('assembly_augmented' if args.include_numerical_extension else 'assembly');output.mkdir(exist_ok=False)
    packet=ROOT/'benchmark/global_amino_reference_validation';catalog=read(packet/'catalog596.json')
    records={};raws={};source_profiles={}
    needs=read(HERE/'raw_prerequisites.json')
    with zipfile.ZipFile(packet/'raw_records.zip') as archive:
        for row in catalog['records']:
            key=(row['charge'],row['smiles'])
            if str(key[0])+'|'+key[1] not in needs:continue
            data=archive.read(row['name']);assert hashlib.sha256(data).hexdigest()==row['sha256']
            raw=json.loads(data);assert raw['G']==row['G_kj'] and raw['sigma']==row['sigma_kj']
            records[key]=dict(name=row['name'],sha256=row['sha256'],profile='retained_'+row['raw_profile'],
                              G_kj=raw['G'],sigma_kj=raw['sigma'])
            raws[key]=raw
            source_profiles['retained_'+row['raw_profile']]=dict(producer=raw['settings']['producer'],settings=raw['settings'])
    task_outcomes={};reconciliations=read(HERE/'cache_reconciliations.json') if (HERE/'cache_reconciliations.json').exists() else {}
    for task in tasks:
        result=read(HERE/'results'/(task['slot']+'.json'));task_outcomes[task['slot']]=result['status']
        is_secondary=False
        if task['slot'] in secondary and secondary[task['slot']]['status']=='molecular_record_complete':
            result=secondary[task['slot']];is_secondary=True
        verified=result
        if result['status']!='molecular_record_complete':
            if task['slot'] not in reconciliations:continue
            verified=reconciliations[task['slot']]
            assert verified['status']=='verified_existing_record'
            assert verified['original_task_result_sha256']==sha(HERE/'results'/(task['slot']+'.json'))
        path=Path(verified['cache_path']);assert sha(path)==verified['cache_sha256'];raw=read(path)
        key=(task['charge'],task['smiles']);assert key not in records
        assert raw['q']==key[0] and raw['smi']==key[1]
        assert raw['settings']['thermal_validation_max']==96
        assert all(m['geometry']['spin_multiplicity']==task['spin'] for m in raw['meta']['thermal']['ensemble']['validated_minima'])
        component_values(raw)
        definition=dict(producer=raw['settings']['producer'],settings=raw['settings'])
        profile=('secondary1200_' if is_secondary else 'fresh_')+result['worker']+'_'+hashlib.sha256(json.dumps(definition,sort_keys=True).encode()).hexdigest()[:12]
        assert source_profiles.setdefault(profile,definition)==definition
        records[key]=dict(name=path.name,sha256=sha(path),profile=profile,G_kj=raw['G'],sigma_kj=raw['sigma'],
            cache_reconciliation=task['slot'] in reconciliations,numerical_extension=is_secondary)
        raws[key]=raw
    components={key:component_values(raw) for key,raw in raws.items()}
    class Backend:
        def __init__(self):
            self.settings=Settings(**read(HERE/'raw_settings.json'))
            self.model_name=self.settings.model
            self.producer=dict(cacheable=False,kind='authenticated-mixed-profile-boundary-reassembly',
                source_profiles=source_profiles,scientific_freeze_sha256=sha(HERE/'freeze.json'),
                catalog_sha256=sha(packet/'catalog596.json'))
        def species(self,q,smi,label,warnings,diagnostics):
            key=(q,Chem.MolToSmiles(Chem.MolFromSmiles(smi),isomericSmiles=True))
            if key not in records:raise MissingMolecule(str(q)+'|'+key[1])
            row=records[key]
            diagnostics.update(raw_record=row['name'],raw_sha256=row['sha256'],raw_profile=row['profile'])
            return row['G_kj'],row['sigma_kj']
        def liquid_water(self):return catalog['water_liquid_1atm_kj']
    requests=read(HERE/'requests.json');all_results={};invariances=[]
    for arm,cls in [('full',StateFunctionEstimator),('anchor14',AnchoredNicotinamideEstimator),('anchor12and14',RegioAnchoredEstimator)]:
        estimator=cls(Backend());rows={};signatures={}
        estimator.config['molecular_calculation_scope']='Authenticated raw-record reassembly; no molecular optimization in this assembly.'
        estimator.config['minimum_optimizer_fallback']=dict(scope='Read actual owning profiles per raw molecule',source_profiles=source_profiles)
        for rid,row in requests.items():
            rx=copy.deepcopy(row['request'])
            try:result=estimator.score_reaction(rx,key=rid)
            except MissingMolecule as error:
                rows[rid]=dict(status='missing_validated_molecular_prerequisite',missing=str(error),result=None);continue
            if result['dG'] is None:
                rows[rid]=dict(status='workflow_refusal',result=result);continue
            parts=dict(electronic=0.,solvation=0.,thermal=0.,conformer_mixing=0.,water_reference=0.,
                       standard_state=0.,protonation=0.,proton_reservoir=rx.get('n_Hplus',0)*G_HPLUS)
            for name,record in result['state_records'].items():
                assert signatures.setdefault(record['state_id'],record['record_sha256'])==record['record_sha256']
                nu=rx['species'][name][0];plan=record['plan'];q,smi=plan['reference_charge'],plan['reference_smiles']
                parts['standard_state']+=nu*STD_STATE_KJ
                parts['protonation']+=nu*record['protonation_kj']
                parts['proton_reservoir']+=nu*record['reference_proton_kj']
                if is_water(smi,q):parts['water_reference']+=nu*catalog['water_liquid_1atm_kj'];continue
                transfer=record['molecular_diagnostics'].get('anchored_transfer')
                terms=transfer['raw_terms'] if transfer else [dict(coefficient=1.,charge=q,smiles=smi)]
                for term in terms:
                    for kind,value in components[(term['charge'],term['smiles'])].items():parts[kind]+=nu*term['coefficient']*value
            residual=math.fsum(parts.values())-result['dG_unrounded'];assert abs(residual)<1e-7,(arm,rid,residual)
            rows[rid]=dict(status='estimated',result=result,components_kj=parts,component_sum_residual_kj=residual)
            for variant in ['reverse','double','atom_order','species_order']:
                other=copy.deepcopy(rx);factor=-1 if variant=='reverse' else 2 if variant=='double' else 1
                if variant in ['reverse','double']:
                    for values in other['species'].values():values[0]*=factor
                    other['n_Hplus']=factor*other.get('n_Hplus',0)
                if variant=='species_order':other['species']=dict(reversed(list(other['species'].items())))
                if variant=='atom_order':
                    for values in other['species'].values():
                        mol=Chem.MolFromSmiles(values[2]);mol=Chem.RenumberAtoms(mol,list(reversed(range(mol.GetNumAtoms()))))
                        values[2]=Chem.MolToSmiles(mol,canonical=False,isomericSmiles=True)
                check=estimator.score_reaction(other,key=rid+'_'+variant)
                assert check['dG'] is not None,(arm,rid,variant,check['suspect'])
                delta=check['dG_unrounded']-factor*result['dG_unrounded']
                assert abs(delta)<1e-7 and abs(check['U_samp']-abs(factor)*result['U_samp'])<1e-8
                invariances.append(dict(arm=arm,reaction=rid,variant=variant,residual_kj=delta))
        all_results[arm]=rows
        reverse_ledger=cls(Backend())
        for rid,row in reversed(list(requests.items())):
            if rows[rid]['status']!='estimated':continue
            repeated=reverse_ledger.score_reaction(copy.deepcopy(row['request']),key=rid)
            assert repeated['dG_unrounded']==rows[rid]['result']['dG_unrounded']
            for record in repeated['state_records'].values():assert record['record_sha256']==signatures[record['state_id']]
        write(output/(arm+'.json'),dict(results=rows,ledger=estimator.ledger()))
    cycles={}
    for arm,rows in all_results.items():
        ids=sorted(rid for rid,row in rows.items() if row['status']=='estimated');columns=[];keys=set()
        for rid in ids:
            rx=requests[rid]['request'];column={}
            for nu,q,smi in rx['species'].values():
                key=json.dumps([q,Chem.MolToSmiles(Chem.MolFromSmiles(smi),isomericSmiles=True)])
                column[key]=column.get(key,Fraction(0))+Fraction(str(nu));keys.add(key)
            if rx.get('n_Hplus',0):column['H+']=Fraction(str(rx['n_Hplus']));keys.add('H+')
            columns.append(column)
        matrix=sp.Matrix([[sp.Rational(c.get(k,0)) for c in columns] for k in sorted(keys)])
        basis=[]
        for vector in matrix.nullspace():
            scale=math.lcm(*(int(v.q) for v in vector));coefficients=[int(v*scale) for v in vector]
            divisor=math.gcd(*(abs(v) for v in coefficients));coefficients=[v//divisor for v in coefficients]
            residual=math.fsum(n*rows[rid]['result']['dG_unrounded'] for rid,n in zip(ids,coefficients))
            norm=sum(map(abs,coefficients));assert abs(residual)/norm<1e-7
            basis.append(dict(coefficients={rid:n for rid,n in zip(ids,coefficients) if n},residual_kj=residual,L1_normalized_residual_kj=residual/norm))
        cycles[arm]=basis
    comparisons={rid:{arm:(rows[rid]['result']['dG_unrounded'] if rows[rid]['status']=='estimated' else None)
                      for arm,rows in all_results.items()} for rid in requests}
    for rid,row in comparisons.items():
        row['sampling_only_sigma_kj']={arm:all_results[arm][rid]['result']['U_samp']
            for arm in all_results if all_results[arm][rid]['status']=='estimated'}
    report=dict(scope='Twelve source-curated ModelSEED boundary inputs; model estimates and sensitivities, not experimental accuracy or genome-scale coverage.',
        requested=12,task_status_counts=dict(Counter(task_outcomes.values())),
        cache_reconciliations=reconciliations,physical_record_count=sum(k in raws for k in [(t['charge'],t['smiles']) for t in tasks]),
        secondary_numerical_profile_included=args.include_numerical_extension,
        secondary_task_status_counts=dict(Counter(r['status'] for r in secondary.values())),
        assembly_status_counts={arm:dict(Counter(r['status'] for r in rows.values())) for arm,rows in all_results.items()},
        predictions_kj=comparisons,invariance_checks=len(invariances),cycles=cycles,
        primary_independent_experimental_labels=0,production_policy_adopted=False,
        numerical_profile_scope='Mixed retained64-ceiling records and new96-ceiling curvature-recovery records, exact provenance retained per molecule; no accepted old record relabelled.')
    write(output/'invariances.json',invariances);write(output/'report.json',report)
    write(output/'raw_catalog.json',dict(records=[dict(charge=q,smiles=smi,**row) for (q,smi),row in sorted(records.items())],source_profiles=source_profiles))
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
