"""Accelerator-assigned scientific-process windows; not reservation occupancy."""
from pathlib import Path
import argparse,datetime,hashlib,json,math
H=Path(__file__).resolve().parent;R=H/'resource_recovery'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
stamp=lambda value:datetime.datetime.fromisoformat(value).timestamp()

def main():
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--output',type=Path,required=True)
 parser.add_argument('--live',action='store_true');args=parser.parse_args()
 if args.output.exists():raise FileExistsError('Keep earlier accounting snapshots')
 proof_path=R/('live_process_audit.json' if args.live else 'terminal_process_audit.json');proof=read(proof_path)
 restored=read(R/'launch_manifest.json');initial=read(H/'launch_manifest.json')
 assert proof['run_id']==restored['run_id'] and proof['launch_manifest_sha256']==sha(R/'launch_manifest.json')
 if not args.live:
  assert proof['terminal'] and not proof['remaining_marked_predictors']
  assert len(proof['ownership_checks'])==6 and not any(r['same_live_process'] for r in proof['ownership_checks'])
 stopped=read(H/'post_stop_ownership_audit.json')
 assert not stopped['remaining_marked_predictors'] and not any(r['same_live_process'] for r in stopped['ownership_checks'])
 offset=proof['host_unix_epoch_minus_boottime'];hz=proof['clock_ticks_per_second'];windows=[]
 for phase,root,manifest,ended in [('initial',H,initial,stopped['utc']),('restored',R,restored,proof['utc'])]:
  for allocation in manifest['allocations']:
   owner=read(root/'workers'/(allocation['worker']+'.launcher.json'))
   assert owner['host']==proof['host']==allocation['host']
   begin=offset+int(owner['start_ticks'])/hz;end=stamp(ended)
   assert begin<end and begin>=stamp(initial['utc'])-10
   windows.append(dict(phase=phase,worker=allocation['worker'],host=owner['host'],gpu=allocation['gpu_index'],
    launcher_start_epoch=begin,scientific_processes_gone_audit_utc=ended if phase=='initial' or not args.live else None,
    live_observation_end_utc=ended if phase=='restored' and args.live else None,
    enclosing_walltime_seconds=end-begin))
 assert max(w['launcher_start_epoch'] for w in windows if w['phase']=='initial')<stamp(stopped['utc'])
 assert stamp(stopped['utc'])<min(w['launcher_start_epoch'] for w in windows if w['phase']=='restored')
 observed=sum(w['enclosing_walltime_seconds'] for w in windows)/3600
 deadline=stamp(restored['deadline_utc'])
 possible=sum((deadline-w['launcher_start_epoch'] if w['phase']=='restored' else w['enclosing_walltime_seconds']) for w in windows)/3600
 assert possible<=restored['maximum_GPU_hours']
 report=dict(schema='metag-operational-scientific-process-window-bounds-v1',status='live_snapshot_not_final_cost' if args.live else 'terminal_accounting',
  source_sha256=sha(Path(__file__)),audit_sha256=sha(proof_path),initial_stop_audit_sha256=sha(H/'post_stop_ownership_audit.json'),
  windows=windows,enclosing_assigned_worker_hours_observed=observed,
  enclosing_worker_hours_if_restored_scientific_trees_stop_by_common_deadline=possible,declared_shared_ceiling_hours=restored['maximum_GPU_hours'],
  no_overlap_between_scientific_execution_windows=True,reservation_occupancy_measured=False,
  interpretation='Launcher creation precedes scientific execution; first owned-controller/predictor/marked-descendant absence audit follows scientific execution. These enclosing windows bound the assigned scientific workload, including imports, waiting and observation gaps. Initial audit does not check gate-launcher exit, so reservation occupancy and release time are NOT measured. For live observations these are elapsed windows only, not final costs. Assumes the recorded same-host boot clock; tick quantization is 1/hz seconds.',
  excludes=['reservation occupancy or initial gate-release time','GPU utilization or energy consumption','provider billing or dollar cost','genome-scale throughput extrapolation','standalone per-reaction runtime'],
  cleanup_deadline_assumption='The possible-hours number is conditional on scientific execution stopping by the original deadline; final terminal proof must verify this. It does not infer future completion from a live observation.')
 args.output.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['status','enclosing_assigned_worker_hours_observed','enclosing_worker_hours_if_restored_scientific_trees_stop_by_common_deadline','declared_shared_ceiling_hours']},indent=2))

if __name__=='__main__':main()
