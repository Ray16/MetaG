"""Recompute all affected input gates with exact proton basis conversion."""
from pathlib import Path
from collections import Counter, defaultdict
from fractions import Fraction
import copy
import hashlib
import json
import os
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
sys.path[:0] = [str(ROOT/'src'), str(ROOT/'benchmark')]
from rdkit import Chem, RDLogger
from rdkit.Chem import rdMolDescriptors
from audit_modelseed_inputs import load_chunks, parse_equation
from verify_modelseed_inputs import balance
from modelseed_cofactor_curation import canonical, validate_registry, rebase_equation
from metag.state_function import plan_state
from metag.energetics.conformers import spin_multiplicity
from metag.reactions import validate_reaction
from anchored_nicotinamide import anchor_plan

read = lambda p: json.loads(Path(p).read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def records(path, key):
    result = {}
    for line in Path(path).open():
        row = json.loads(line)
        assert row[key] not in result
        result[row[key]] = row
    return result


def write(name, value):
    with (HERE/name).open('x') as stream:
        json.dump(value,stream,indent=2,allow_nan=False);stream.write('\n')


def main():
    started = time.monotonic()
    freeze = read(HERE/'counterfactual_freeze.json')
    for relative, digest in freeze['code_sha256'].items():
        assert sha(ROOT/relative) == digest, relative
    for relative,digest in freeze['input_sha256'].items():
        assert sha(ROOT/relative) == digest, relative
    assert sorted(os.sched_getaffinity(0)) == [79]
    RDLogger.DisableLog('rdApp.*')
    database = ROOT.parent.parent/'ModelSEEDDatabase'
    compounds,cf = load_chunks(database/'Biochemistry','compound')
    reactions,rf = load_chunks(database/'Biochemistry','reaction')
    old = ROOT/'analysis/modelseed_applicability_20261104_02/replay_public'
    old_protocol = read(old/'protocol.json')
    assert dict(cf,**rf) == old_protocol['source_files_sha256']
    states = records(old/'compounds.jsonl','compound')
    literal = records(old/'reactions.jsonl','reaction')
    assert set(literal) == {rid for rid,row in reactions.items()
        if row['is_obsolete']=='0' and row['is_transport']=='0'}
    registry = validate_registry(read(HERE/'registry.json'),compounds)
    curated = copy.deepcopy(compounds)
    target_states = copy.deepcopy(states)
    for cid,entry in registry.items():
        target = entry['target']
        curated[cid].update(smiles=target['smiles'],charge=str(target['charge']))
        smi,q = target['smiles'],target['charge']
        validate_reaction({'species':{'state':[1,q,smi]}})
        spin_multiplicity(smi,q)
        plan = plan_state(q,smi)
        molecule = Chem.MolFromSmiles(smi)
        target_states[cid] = dict(compound=cid,name=entry['name'],smiles=smi,
            source_charge=str(q),charge=q,status='passes_cpu_state_gates',category=None,
            canonical_input=plan['input_smiles'],reference_charge=plan['reference_charge'],
            reference_smiles=plan['reference_smiles'],proton_exchange=plan['proton_exchange'],
            protonation_issues=plan['protonation_admission']['issues'],
            n_reference_sites=len(plan['pka_sites']),n_atoms=Chem.AddHs(molecule).GetNumAtoms(),
            n_heavy_atoms=molecule.GetNumHeavyAtoms(),n_rotatable_bonds=rdMolDescriptors.CalcNumRotatableBonds(molecule),
            curation_profile='explicit-four-source-cross-referenced-cofactors-v1')
    # Establish exact molecular reference siblings, not just name-based couples.
    families={}
    for ox,red,name in [('cpd00003','cpd00004','NAD'),('cpd00006','cpd00005','NADP')]:
        plan=anchor_plan(target_states[red]['reference_charge'],target_states[red]['reference_smiles'])
        assert plan['oxidized_sibling_smiles']==target_states[ox]['reference_smiles']
        assert plan['oxidized_sibling_charge']==target_states[ox]['reference_charge']
        families[name]=dict(oxidized=ox,reduced=red,reference_smiles=plan['oxidized_sibling_smiles'])
    write('curated_compound_states.json',{cid:target_states[cid] for cid in registry})
    write('anchor_families.json',families)

    def classify(rid,terms):
        source=reactions[rid]
        item=dict(reaction=rid,source_status=source.get('status'),causes=[])
        if source.get('abstract_reaction')=='1':item['causes'].append(dict(category='abstract_reaction'))
        if len({comp for cid,comp in terms})>1:
            item['causes'].append(dict(category='multiple_compartments_need_conditions'))
        item['compounds']=sorted({cid for cid,comp in terms})
        complete=True; signature=defaultdict(Fraction)
        for (cid,compartment),nu in terms.items():
            if cid=='cpd00067':signature['H+']+=nu;continue
            if cid not in target_states:
                item['causes'].append(dict(category='missing_compound',compound=cid));complete=False;continue
            state=target_states[cid]
            if state['status']!='passes_cpu_state_gates':
                item['causes'].append(dict(category=state['category'],compound=cid));complete=False;continue
            signature[(state['charge'],state['canonical_input'])]+=nu
        if complete and terms:
            checked=balance(terms,curated)
            assert checked['all_formulas_known']
            if checked['element_residual']:
                item['causes'].append(dict(category='element_imbalance',residual=checked['element_residual']))
            if Fraction(checked['formal_charge_residual']):
                item['causes'].append(dict(category='charge_imbalance',residual=checked['formal_charge_residual']))
            if not any(signature.values()):item['causes'].append(dict(category='identity_or_graph_collapsed_reaction'))
        if not terms and not item['causes']:item['causes'].append(dict(category='empty_net_equation'))
        item['status']='passes_cpu_input_gates' if not item['causes'] else 'requires_curation_or_is_unsupported'
        return item

    outcomes=copy.deepcopy(literal);affected=[];rows=[];checked_count=0
    for rid,old_row in literal.items():
        if not set(registry).intersection(old_row['compounds']):continue
        terms=parse_equation(reactions[rid]['stoichiometry'])
        changed,proton_changes=rebase_equation(terms,registry)
        before,after=balance(terms,compounds),balance(changed,curated)
        assert before['all_formulas_known']==after['all_formulas_known']
        assert before['declared_charge_residual']==after['declared_charge_residual']
        if before['all_formulas_known']:
            assert before['element_residual']==after['element_residual'],rid
            assert before['formal_charge_residual']==after['formal_charge_residual'],rid
            checked_count+=1
        new=classify(rid,changed)
        outcomes[rid]=new;affected.append(rid)
        family_balance={name:str(sum(nu for (cid,comp),nu in changed.items()
            if cid in {family['oxidized'],family['reduced']})) for name,family in families.items()}
        rows.append(dict(reaction=rid,source_stoichiometry=reactions[rid]['stoichiometry'],
            original_terms=[[cid,comp,str(nu)] for (cid,comp),nu in sorted(terms.items())],
            curated_terms=[[cid,comp,str(nu)] for (cid,comp),nu in sorted(changed.items())],
            proton_adjustments_by_compartment=proton_changes,
            literal_outcome=old_row,curated_outcome=new,
            balance_before=before,balance_after=after,anchor_family_net_coefficients=family_balance))
    assert len(outcomes)==len(literal)==43650
    unaffected=sorted(set(literal)-set(affected))
    assert all(outcomes[rid]==literal[rid] for rid in unaffected)
    gained=[rid for rid in affected if outcomes[rid]['status']=='passes_cpu_input_gates'
            and literal[rid]['status']!='passes_cpu_input_gates']
    lost=[rid for rid in affected if outcomes[rid]['status']!='passes_cpu_input_gates'
          and literal[rid]['status']=='passes_cpu_input_gates']
    passing_affected=[r for r in rows if r['curated_outcome']['status']=='passes_cpu_input_gates']
    boundary=[r['reaction'] for r in passing_affected if any(Fraction(v) for v in r['anchor_family_net_coefficients'].values())]
    first=Counter(row['causes'][0]['category'] for row in outcomes.values() if row['causes'])
    warnings=Counter()
    for row in outcomes.values():
        if row['status']=='passes_cpu_input_gates':
            issues={issue for cid in row['compounds'] for issue in target_states[cid].get('protonation_issues',[])}
            warnings['with_protonation_warnings' if issues else 'without_recorded_protonation_warnings']+=1
    summary=dict(scope='Separate explicit four-cofactor curation profile; input admission only, no new energies or thermodynamic validation.',
        n_requested=43650,n_affected=len(affected),n_unaffected=len(unaffected),
        literal_status_counts=dict(Counter(row['status'] for row in literal.values())),
        curated_status_counts=dict(Counter(row['status'] for row in outcomes.values())),
        gained_inputs=gained,lost_inputs=lost,first_remaining_failure=dict(first),passing_warning_counts=dict(warnings),
        n_proton_adjusted_reactions=sum(bool(r['proton_adjustments_by_compartment']) for r in rows),
        n_known_formula_residuals_preserved=checked_count,
        n_declared_charge_residuals_preserved=len(rows),
        affected_passing=len(passing_affected),affected_passing_anchor_cancelling=len(passing_affected)-len(boundary),
        affected_passing_anchor_retaining=len(boundary),anchor_retaining_input_ids=boundary,
        physical_calculations_attempted=0,numerical_prediction_coverage=None,experimental_accuracy_assessed=False,
        literal_profile_unchanged=True,production_policy_adopted=False,elapsed_seconds=time.monotonic()-started,
        freeze_sha256=sha(HERE/'counterfactual_freeze.json'))
    write('affected_reactions.json',rows)
    write('curated_outcomes.json',outcomes)
    write('summary.json',summary)
    print(json.dumps({k:v for k,v in summary.items() if k not in ['gained_inputs','lost_inputs','anchor_retaining_input_ids']},indent=2),flush=True)


if __name__=='__main__':main()
