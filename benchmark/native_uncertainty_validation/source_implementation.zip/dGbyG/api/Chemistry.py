import time
from typing import Any, Dict, Tuple, Union
import rdkit
import numpy as np
import pandas as pd
from functools import lru_cache

import torch
from torch_geometric.loader import DataLoader

from dGbyG.config import *
from dGbyG.utils.constants import *
from dGbyG.utils.ChemFunc import *
from dGbyG.utils.CustomError import *
from dGbyG.Chemistry import _Compound, _Reaction
from dGbyG.db import db_Compound

from .utils import predict_standard_dGf_prime, predict_standard_dGr_prime


class Compound(_Compound, db_Compound):
    def __init__(self, mol: Union[rdkit.Chem.rdchem.Mol, str], mol_type:str=None, input_type:str=None) -> None:
        if mol_type is None:
            mol_type = input_type
        self.mol_type = mol_type.lower() if mol_type is not None else None
        if isinstance(mol, rdkit.Chem.rdchem.Mol) or mol is None:
            self.mol = mol
            _Compound.__init__(self, self.mol)
        elif isinstance(mol_type, str):
            self.mol = to_mol(mol, mol_type)
            _Compound.__init__(self, self.mol)
        else:
            raise InputValueError(f'mol_type must be a string, but got {type(mol_type)}')
        
        if self.mol_type == 'mol':
            db_Compound.__init__(self, self.Smiles, 'smiles')
        else:
            db_Compound.__init__(self, mol, self.mol_type)
        
        self.compartment = None
        
    @property
    @lru_cache(maxsize=None)
    def standard_dGf_prime_list(self) -> Union[np.ndarray, None]:
        if self.mol:
            if self.atom_bag == {'H': 1, 'charge': 1}:
                return predict_standard_dGf_prime(self.mol).squeeze()*0
            else:
                return predict_standard_dGf_prime(self.mol).squeeze()
        else:
            return None
    
    @property
    @lru_cache(maxsize=None)
    def standard_dGf_prime(self) -> Tuple[np.float32, np.float32]:
        if self.standard_dGf_prime_list is not None:
            return np.mean(self.standard_dGf_prime_list), np.std(self.standard_dGf_prime_list)
        else:
            return np.nan, np.nan
    '''
    @property
    def transformed_ddGf(self) -> Union[np.float32, None]:
        if self.can_be_transformed:
            return self.transformed_ddGf()
        else:
            return None'''
    
    @property
    def transformed_standard_dGf_prime(self) -> Tuple[np.float32, np.float32]:
        if self.condition == default_condition:
            return self.standard_dGf_prime
        elif self.can_be_transformed:
            transformed_standard_dg = (self.standard_dGf_prime[0] + self.transformed_ddGf)
            return transformed_standard_dg, self.standard_dGf_prime[1]
        else:
            return self.standard_dGf_prime
    




class Reaction(_Reaction):
    '''
    This class is used to represent a chemical reaction.
    '''
    def __init__(self, reaction, mol_type:str) -> None:
        """
        Parameters
        ----------
        reaction: dict or str
            reaction can be:
            (1) a dict of {rdkit.Chem.rdchem.Mol: coefficient}.
            (2) a dict of {Compound: coefficient}. 
            (3) a string of equation. e.g. 
        """
        if isinstance(reaction, str):
            reaction_dict = parse_equation(reaction)
        elif isinstance(reaction, dict):
            reaction_dict = reaction
        else:
            raise InputValueError(f'Cannot accept type{type(reaction)} as the input of reaction.')
        
        if not isinstance(mol_type, str):
            raise InputValueError(f'Type of mol_type should be str, but got type{mol_type}')
        
        self.reaction = {}
        for comp, coeff in reaction_dict.items():
            if isinstance(comp, Compound) or mol_type.lower()=='compound':
                if not (isinstance(comp, Compound) and mol_type.lower()=='compound'):
                    raise InputValueError(f"Key's of reaction is {type(comp)}, but mol_type is {mol_type}")
            elif isinstance(comp, rdkit.Chem.rdchem.Mol) or mol_type.lower()=='mol':
                if not (isinstance(comp, rdkit.Chem.rdchem.Mol) and mol_type.lower()=='mol'):
                    raise InputValueError(f"Key's of reaction is {type(comp)}, but mol_type is {mol_type}")
                else:
                    comp = Compound(comp)
            elif isinstance(comp, str):
                mol = to_mol(comp, mol_type)
                comp = Compound(mol)
            else:
                raise InputValueError('Cannot accept type{0}'.format(type(comp)))
            self.reaction.update({comp:coeff})
            
        super().__init__(self.reaction)

        for comp, coeff in self.reaction.copy().items():
            if type(comp) == _Compound:
                self.reaction.update({Compound(comp.Smiles, mol_type='smiles'):coeff})
                self.reaction.pop(comp)

        self.ignore_H2O = False
        self.ignore_H_ion = True
        self.ignore_charge = False
        self.ignore_H = True


    @property
    def balanced(self) -> bool:
        """
        Return whether the reaction is balanced.
        """
        return self.is_balanced(ignore_H2O=self.ignore_H2O, ignore_H_ion=self.ignore_H_ion, 
                                ignore_charge=self.ignore_charge, ignore_H=self.ignore_H)
        
    @property
    @lru_cache(maxsize=None)
    def standard_dGr_prime_list(self) -> Union[np.ndarray, None]:
        """
        Return the list of standard dG for the reaction.
        """
        if self.is_balanced(ignore_H2O=self.ignore_H2O, ignore_H_ion=self.ignore_H_ion, 
                            ignore_charge=self.ignore_charge, ignore_H=self.ignore_H) == True:
            standard_dGr_list = np.sum([comp.standard_dGf_prime_list * coeff for comp, coeff in self.reaction.items()], axis=0)
            return standard_dGr_list
        else:
            return None

    @property
    @lru_cache(maxsize=None)
    def standard_dGr_prime(self) -> Tuple[np.float32, np.float32]:
        """
        Returns
        -------
            The tuple of the mean and SD of the standard dG for the reaction.
        """
        if self.standard_dGr_prime_list is not None:
            return np.mean(self.standard_dGr_prime_list), np.std(self.standard_dGr_prime_list)
        else:
            return np.nan, np.nan
        
    @property
    def transformed_standard_dGr_prime(self) -> Tuple[np.float32, np.float32]:
        """
        Returns
        -------
            The tuple of the mean and SD of transformed standard dG for the reaction.
        """
        if (np.array(list(self.condition.values())) == default_condition).all():
            return self.standard_dGr_prime
        if self.can_be_transformed:
            transformed_ddGr = np.sum([comp.transformed_ddGf * coeff for comp, coeff in self.reaction.items()], axis=0)
            transformed_standard_dGr_prime = self.standard_dGr_prime[0] + transformed_ddGr
            return transformed_standard_dGr_prime, self.standard_dGr_prime[1]
        else:
            return self.standard_dGr_prime
            
    

