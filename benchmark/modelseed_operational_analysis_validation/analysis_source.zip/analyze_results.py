"""Reassemble the frozen operational study; default analysis requires terminal-process proof."""
from pathlib import Path
from collections import Counter,defaultdict
from fractions import Fraction
import argparse,copy,datetime,hashlib,importlib.util,json,math,sys
import sympy as sp

H=Path(__file__).resolve().parent;P=H.parents[1];R=H/'resource_recovery'
sys.path[:0]=[str(R/'owned_source/src'),str(R/'owned_source')]
from rdkit import Chem
from metag.settings import Settings
from metag.state_function import StateFunctionEstimator
from metag.constants import G_HPLUS
from metag.energetics.provenance import species_source_fingerprint
from benchmark.anchored_nicotinamide_regio import RegioAnchoredEstimator
from benchmark.modelseed_sampling import coverage
spec=importlib.util.spec_from_file_location('current_operational_record_audit',P/'benchmark/operational_records.py')
records_module=importlib.util.module_from_spec(spec);spec.loader.exec_module(records_module)
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
hash_value=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True,allow_nan=False).encode()).hexdigest()


def verify_startup():
    freeze=read(R/'freeze.json');reference=freeze['physical_model_identity'];rows=[]
    expected_source=species_source_fingerprint(R/'owned_source/src/metag')
    for worker in ['worker0','worker1']:
        row=read(R/'workers'/(worker+'.startup.json'));producer=row['producer'];runtime=row['runtime']
        assert row['status']=='passed' and max(map(abs,row['point_energy_differences_kj']))<=.001
        assert producer['source_sha256']==expected_source
        for field in ['checkpoint_sha256','references_sha256']:assert producer['model'][field]==reference[field]
        assert runtime['hardware_capability']==[9,0] and runtime['nitro_eligible_here'] is True
        assert runtime['requested_calculator']=='nitro' and runtime['final_energies']=='official_general_fp32'
        assert runtime['hessian']=='official_general_fp32_force_autograd'
        assert runtime['reference_settings']['tf32'] is False and runtime['reference_settings']['base_precision_dtype']=='torch.float32'
        assert producer['model']['inference_sha256']==hash_value(runtime)
        parent=copy.deepcopy(runtime);parent['hardware_capability']=[7,0];parent['nitro_eligible_here']=False
        assert hash_value(parent)==reference['inference_sha256']
        rows.append(row)
    assert rows[0]['producer']==rows[1]['producer']
    return rows[0]['producer']['model'],dict(checkpoint_and_references_match_parent=True,
        actual_H100_inference_sha256=rows[0]['producer']['model']['inference_sha256'],
        inherited_V100_reference_inference_sha256=reference['inference_sha256'],
        inference_hash_difference_exactly_reconstructed_by_hardware_capability_and_Nitro_eligibility=True,
        actual_runtime=rows[0]['runtime'],compatibility_points=[r['point_energy_differences_kj'] for r in rows],
        scope='Actual H100 settings recorded before target calculations; do not relabel them with the inherited V100 profile fingerprint.')


def terminal_proof():
    path=R/'terminal_process_audit.json'
    if not path.exists():raise RuntimeError('Terminal-process audit is required before final assembly')
    proof=read(path);manifest=read(R/'launch_manifest.json')
    assert proof['run_id']==manifest['run_id'] and proof['launch_manifest_sha256']==sha(R/'launch_manifest.json')
    assert proof['ownership_checks'] and not any(r['same_live_process'] for r in proof['ownership_checks'])
    assert not proof['remaining_marked_predictors']
    return proof


def check_sums(result,request):
    total=math.fsum([request.get('n_Hplus',0)*G_HPLUS]+[
        request['species'][name][0]*row['potential_kj'] for name,row in result['state_records'].items()])
    assert abs(total-result['dG_unrounded'])<1e-7
    combined={}
    for name,state in result['state_records'].items():
        nu=request['species'][name][0]
        for key,row in state['sampling_inputs'].items():
            value=combined.setdefault(key,[0.,row['sigma_kj']]);assert value[1]==row['sigma_kj']
            value[0]+=nu*row['sensitivity']
    sigma=math.sqrt(math.fsum((s*v)**2 for s,v in combined.values()))
    assert abs(sigma-result['U_samp'])<1e-8


def cycles(rows,requests):
    ids=sorted(rid for rid,r in rows.items() if r['status']=='estimated');columns=[];keys=set()
    for rid in ids:
        column=defaultdict(Fraction);source=requests[rid]
        for cid,compartment,coefficient in source['exact_curated_terms']:
            nu=Fraction(coefficient)
            if cid=='cpd00067':key='H+'
            else:
                _,q,smi=source['request']['species'][cid]
                assert abs(float(nu)-source['request']['species'][cid][0])<1e-12
                key=json.dumps([q,Chem.MolToSmiles(Chem.MolFromSmiles(smi),isomericSmiles=True)])
            column[key]+=nu;keys.add(key)
        columns.append(column)
    if not columns:return []
    matrix=sp.Matrix([[sp.Rational(column.get(k,0)) for column in columns] for k in sorted(keys)])
    basis=[]
    for vector in matrix.nullspace():
        scale=math.lcm(*(int(v.q) for v in vector));coefficients=[int(v*scale) for v in vector]
        divisor=math.gcd(*(abs(v) for v in coefficients));coefficients=[v//divisor for v in coefficients]
        residual=math.fsum(n*rows[rid]['result']['dG_unrounded'] for rid,n in zip(ids,coefficients))
        norm=sum(map(abs,coefficients));assert abs(residual)/norm<1e-7
        basis.append(dict(coefficients={rid:n for rid,n in zip(ids,coefficients) if n},residual_kj=residual,L1_normalized_residual_kj=residual/norm))
    return basis


def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--preview',action='store_true')
    parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    if args.output.exists():raise FileExistsError('Preserve earlier analysis; choose a new output directory')
    proof=None if args.preview else terminal_proof()
    frozen=read(R/'freeze.json')
    for relative,digest in frozen['files_sha256'].items():assert sha(R/relative)==digest,relative
    model,identity=verify_startup();settings=Settings(**read(R/'raw_settings.json'));tasks=read(R/'tasks.json')
    bank=records_module.collect(R,tasks,dict(settings.species_key(),model=settings.model),model)
    raw=bank['accepted'];requests=read(R/'requests.json');sample=read(R/'sample.json');discovery=read(R/'prerequisite_discovery.json')
    assert set(requests)=={r['reaction'] for r in sample['selected']}
    outcomes_digest=hash_value({slot:hash_value(r) for slot,r in sorted(bank['outcomes'].items())})
    class Backend:
        def __init__(self):
            self.settings=settings;self.model_name=settings.model
            self.producer=dict(cacheable=False,kind='authenticated-restored-operational-bank',outcomes_sha256=outcomes_digest,
                actual_model_identity=model,physics_source_sha256=identity['actual_runtime']['sdk_source_sha256'])
        def species(self,q,smi,label,warnings,diagnostics):
            key=str(q)+'|'+Chem.MolToSmiles(Chem.MolFromSmiles(smi),isomericSmiles=True)
            if key not in raw:raise ValueError('Missing validated primitive: '+key)
            row=raw[key];meta=next(r for r in bank['catalog'] if r['source_input_key']==key)
            diagnostics.update(source_record=Path(meta['cache_relative']).name,source_sha256=meta['cache_sha256'],
                operational_source_input_key=key)
            return row['G'],row['sigma']
        def liquid_water(self):
            if 'liquid_water' not in raw:raise ValueError('Missing validated liquid-water reference')
            return raw['liquid_water']['G']
    args.output.mkdir(parents=True);all_rows={};invariances=[];cycle_rows={};coverage_rows={}
    for arm,cls in [('full',StateFunctionEstimator),('regio',RegioAnchoredEstimator)]:
        estimator=cls(Backend());rows={};state_hashes={}
        for selected in sample['selected']:
            rid=selected['reaction'];need=discovery[rid][arm]
            if need['capacity_exceeded_primitives']:
                rows[rid]=dict(status='capacity_limit',primitives=need['capacity_exceeded_primitives'],result=None);continue
            if not need['static_discovery_complete']:
                rows[rid]=dict(status='static_reference_refusal',reason=need['planning_refusal'],result=None);continue
            missing=[k for k in need['prerequisites'] if k not in raw]
            if missing:
                task_for={t['source_input_key']:t['slot'] for t in tasks}
                rows[rid]=dict(status='missing_validated_molecular_prerequisite',missing=[dict(key=k,
                    opportunity=bank['opportunities'][task_for[k]]) for k in missing],result=None);continue
            rx=copy.deepcopy(requests[rid]['request']);result=estimator.score_reaction(rx,key=rid)
            if result['dG'] is None:rows[rid]=dict(status='assembly_refusal',result=result);continue
            check_sums(result,rx)
            for state in result['state_records'].values():
                assert state_hashes.setdefault(state['state_id'],state['record_sha256'])==state['record_sha256']
            rows[rid]=dict(status='estimated',result=result)
            for variant in ['reverse','double','species_order','atom_order']:
                changed=copy.deepcopy(rx);factor=-1 if variant=='reverse' else 2 if variant=='double' else 1
                if variant in ['reverse','double']:
                    for value in changed['species'].values():value[0]*=factor
                    changed['n_Hplus']=factor*changed.get('n_Hplus',0)
                if variant=='species_order':changed['species']=dict(reversed(list(changed['species'].items())))
                if variant=='atom_order':
                    for value in changed['species'].values():
                        mol=Chem.MolFromSmiles(value[2]);mol=Chem.RenumberAtoms(mol,list(reversed(range(mol.GetNumAtoms()))))
                        value[2]=Chem.MolToSmiles(mol,canonical=False,isomericSmiles=True)
                alternative=estimator.score_reaction(changed,key=rid+'_'+variant)
                assert alternative['dG'] is not None
                delta=alternative['dG_unrounded']-factor*result['dG_unrounded']
                assert abs(delta)<1e-7 and abs(alternative['U_samp']-abs(factor)*result['U_samp'])<1e-8
                invariances.append(dict(arm=arm,reaction=rid,variant=variant,residual_kj=delta))
        reverse=cls(Backend())
        for rid in reversed(list(rows)):
            if rows[rid]['status']!='estimated':continue
            result=reverse.score_reaction(copy.deepcopy(requests[rid]['request']),key=rid)
            assert result['dG_unrounded']==rows[rid]['result']['dG_unrounded']
            for state in result['state_records'].values():assert state['record_sha256']==state_hashes[state['state_id']]
        all_rows[arm]=rows;cycle_rows[arm]=cycles(rows,requests)
        coverage_rows[arm]=coverage(sample,{rid:r['status']=='estimated' for rid,r in rows.items()},43650,
            bank['all_declared_opportunities_complete'] and not args.preview)
        if args.preview:
            coverage_rows[arm].update(status='provisional_no_population_inference',reason='Preview while collection is unfinished; this is not a completed budget-censoring analysis.')
        (args.output/(arm+'.json')).write_text(json.dumps(dict(results=rows,ledger=estimator.ledger()),indent=2,allow_nan=False)+'\n')
    costs=dict(sum_controller_job_seconds=math.fsum(r.get('controller_elapsed_seconds',0.) for r in bank['outcomes'].values()),
        sum_backend_construction_seconds=math.fsum(r.get('model_initialization_seconds',0.) for r in bank['outcomes'].values()),
        backend_construction_scope='Imports/loader/backend construction only; first forward may perform additional initialization.',
        scope='Observed restored raw-job elapsed sums under shared batch caching; not GPU utilization, standalone reaction runtime or genome-scale walltime.')
    report=dict(status='provisional_preview' if args.preview else 'terminal_analysis',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        selected_source_IDs=32,raw_expected=len(tasks),raw_status_counts=bank['status_counts'],accepted_raw_records=len(raw),
        all_raw_opportunities_complete=bank['all_declared_opportunities_complete'],coverage=coverage_rows,
        assembly_status_counts={a:dict(Counter(r['status'] for r in rows.values())) for a,rows in all_rows.items()},
        invariance_checks=len(invariances),cycles=cycle_rows,actual_inference_identity=identity,costs=costs,
        original_phase_excluded_from_restored_bank=True,independent_experimental_labels=0,production_policy_adopted=False,
        terminal_process_audit_sha256=None if proof is None else sha(R/'terminal_process_audit.json'),
        estimator_source_freeze_sha256=sha(R/'freeze.json'),analysis_source_sha256=sha(Path(__file__)),
        raw_auditor_source_sha256=sha(P/'benchmark/operational_records.py'),predeclared_sample_sha256=sha(R/'sample.json'))
    for name,value in [('report.json',report),('invariances.json',invariances),('raw_catalog.json',bank['catalog']),('raw_opportunities.json',bank['opportunities'])]:
        (args.output/name).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['actual_inference_identity','cycles']},indent=2))


if __name__=='__main__':main()
