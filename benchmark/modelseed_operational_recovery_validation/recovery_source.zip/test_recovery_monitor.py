from pathlib import Path
import importlib.util,json,os,subprocess,sys
from types import SimpleNamespace
import pytest
H=Path(__file__).resolve().parent
sys.path.insert(0,str(H/'resource_recovery'))
spec=importlib.util.spec_from_file_location('recovery_worker_monitor',H/'resource_recovery/worker.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)


def setup(monkeypatch,tmp_path):
    (tmp_path/'launch_manifest.json').write_text(json.dumps(dict(run_id='fixture',allocations=[dict(worker='test',gpu_uuid='fixtureGPU')])) )
    monkeypatch.setattr(m,'HERE',tmp_path);monkeypatch.setattr(m,'worker','test')


def test_external_live_process_is_detected_without_signalling_it(monkeypatch,tmp_path):
    process=subprocess.Popen([sys.executable,'-c','import time;time.sleep(20)'],start_new_session=True)
    try:
        setup(monkeypatch,tmp_path)
        monkeypatch.setattr(m.subprocess,'run',lambda *a,**k:SimpleNamespace(returncode=0,stdout=f'fixtureGPU, {os.getpid()}\nfixtureGPU, {process.pid}\n',stderr=''))
        result=m.foreign_gpu_processes(SimpleNamespace(pid=os.getpid()))
        assert [r['pid'] for r in result]==[process.pid]
        assert process.poll() is None
    finally:process.terminate();process.wait(timeout=5)


def test_observation_timeout_is_not_reported_as_a_foreign_process(monkeypatch,tmp_path):
    setup(monkeypatch,tmp_path)
    def timeout(*a,**k):raise subprocess.TimeoutExpired('nvidia-smi',5)
    monkeypatch.setattr(m.subprocess,'run',timeout)
    with pytest.raises(subprocess.TimeoutExpired):m.foreign_gpu_processes(SimpleNamespace(pid=os.getpid()))
